> Error while running 'iptables-nft -L -v':  exit status 4

iptables v1.8.4 (nf_tables): Could not fetch rule set generation id: Invalid argument

