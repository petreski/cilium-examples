goroutine 42 [running]:
runtime/pprof.writeGoroutineStacks(0x2e7e160, 0xc0001ba020, 0x1f, 0x501cf1)
	/usr/local/go/src/runtime/pprof/pprof.go:693 +0x9f
runtime/pprof.writeGoroutine(0x2e7e160, 0xc0001ba020, 0x2, 0x40, 0x10)
	/usr/local/go/src/runtime/pprof/pprof.go:682 +0x45
runtime/pprof.(*Profile).WriteTo(0x41f9fe0, 0x2e7e160, 0xc0001ba020, 0x2, 0xc0001ba020, 0x1)
	/usr/local/go/src/runtime/pprof/pprof.go:331 +0x3f2
github.com/google/gops/agent.handle(0x7f5a4a0d1800, 0xc0001ba020, 0xc0003ac170, 0x1, 0x1, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:201 +0x1b8
github.com/google/gops/agent.listen()
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:145 +0x2f0
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:123 +0x3ad

goroutine 1 [select, 305 minutes]:
github.com/cilium/cilium/daemon/cmd.runDaemon()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1744 +0x1c65
github.com/cilium/cilium/daemon/cmd.glob..func1(0x4208840, 0xc00027a270, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:136 +0x4aa
github.com/spf13/cobra.(*Command).execute(0x4208840, 0xc0001c0010, 0x1, 0x1, 0x4208840, 0xc0001c0010)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:854 +0x2c2
github.com/spf13/cobra.(*Command).ExecuteC(0x4208840, 0xc000132540, 0x422f6a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:958 +0x375
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:895
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:161 +0x5f
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:22 +0x25

goroutine 18 [chan receive]:
k8s.io/klog/v2.(*loggingT).flushDaemon(0x422e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:1164 +0x8b
created by k8s.io/klog/v2.init.0
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:418 +0xdf

goroutine 33 [select, 306 minutes]:
io.(*pipe).Read(0xc0000bc120, 0xc000401000, 0x1000, 0x1000, 0x2526060, 0x1, 0xc000401000)
	/usr/local/go/src/io/pipe.go:57 +0xcb
io.(*PipeReader).Read(0xc0000c4008, 0xc000401000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/io/pipe.go:134 +0x4c
bufio.(*Scanner).Scan(0xc000197f38, 0x0)
	/usr/local/go/src/bufio/scan.go:214 +0xa9
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc0000be0e0, 0xc0000c4008, 0xc0000c8060)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xb7
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x1b7

goroutine 34 [select, 260 minutes]:
io.(*pipe).Read(0xc0000bc180, 0xc0004001fc, 0xe04, 0xe04, 0x0, 0x0, 0x0)
	/usr/local/go/src/io/pipe.go:57 +0xcb
io.(*PipeReader).Read(0xc0000c4018, 0xc0004001fc, 0xe04, 0xe04, 0x0, 0x7f5a00000003, 0xc0001f8300)
	/usr/local/go/src/io/pipe.go:134 +0x4c
bufio.(*Scanner).Scan(0xc001b83f38, 0x1)
	/usr/local/go/src/bufio/scan.go:214 +0xa9
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc0000be0e0, 0xc0000c4018, 0xc0000c8080)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xb7
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x1b7

goroutine 35 [select, 306 minutes]:
io.(*pipe).Read(0xc0000bc1e0, 0xc000404000, 0x1000, 0x1000, 0x2526060, 0x1, 0xc000404000)
	/usr/local/go/src/io/pipe.go:57 +0xcb
io.(*PipeReader).Read(0xc0000c4028, 0xc000404000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/io/pipe.go:134 +0x4c
bufio.(*Scanner).Scan(0xc000198f38, 0x0)
	/usr/local/go/src/bufio/scan.go:214 +0xa9
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc0000be0e0, 0xc0000c4028, 0xc0000c80a0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xb7
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x1b7

goroutine 36 [select, 306 minutes]:
io.(*pipe).Read(0xc0000bc240, 0xc000405000, 0x1000, 0x1000, 0x2526060, 0x1, 0xc000405000)
	/usr/local/go/src/io/pipe.go:57 +0xcb
io.(*PipeReader).Read(0xc0000c4038, 0xc000405000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/io/pipe.go:134 +0x4c
bufio.(*Scanner).Scan(0xc000199f38, 0x0)
	/usr/local/go/src/bufio/scan.go:214 +0xa9
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc0000be0e0, 0xc0000c4038, 0xc0000c80c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xb7
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x1b7

goroutine 7 [sleep]:
time.Sleep(0x37e11d600)
	/usr/local/go/src/runtime/time.go:193 +0xd2
github.com/cilium/cilium/pkg/datapath/link.init.0.func1()
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:39 +0x8e
created by github.com/cilium/cilium/pkg/datapath/link.init.0
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:32 +0x35

goroutine 26 [chan receive, 306 minutes]:
github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler.func1(0xc00043c1e0, 0x41f67a0, 0xc000132540)
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:75 +0x55
created by github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:74 +0x125

goroutine 65 [syscall, 306 minutes]:
os/signal.signal_recv(0x472481)
	/usr/local/go/src/runtime/sigqueue.go:168 +0xa5
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x25
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x45

goroutine 229 [select, 2 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc00013e000, 0xc02364b9de905094, 0x10b0f7552842, 0x422e340, 0x2e9bb40, 0xc0017e9c80, 0xc000193b90, 0xc0003dad80, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00013e000, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0000d46c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000193ec8, 0x2e7dcc0, 0xc000739360, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00013e000, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc000ca2c60, 0xc0005a74d0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 27 [chan receive, 306 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1(0x4788fd0, 0xc000194780, 0xc00000c1c8)
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:30 +0x65
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:28 +0x6a

goroutine 228 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0004a7e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 196 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:246 +0x7c
sync.(*Once).doSlow(0xc000c94498, 0xc0000d9fb8)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c94480)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:244 +0x65
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:240 +0x65

goroutine 78 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b10100)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 194 [select]:
github.com/cilium/cilium/pkg/node/manager.(*Manager).backgroundSync(0xc00074a140)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:313 +0x210
created by github.com/cilium/cilium/pkg/node/manager.NewManager
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:213 +0x690

goroutine 527 [select, 305 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1(0x2ed3970, 0xc00111a440, 0x422e340, 0x0)
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:663 +0xb9
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b6e200)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:208 +0xae9
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 365 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071bf0, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc00101c118, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc00101c100, 0xc0018e7000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc00101c100, 0xc0018e7000, 0x1000, 0x1000, 0x7f5a4a2d2c78, 0xc0, 0xc0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0010a8010, 0xc0018e7000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*connReader).Read(0xc000d77980, 0xc0018e7000, 0x1000, 0x1000, 0x100000016, 0x4190db, 0x7f5a4a264710)
	/usr/local/go/src/net/http/server.go:800 +0x1b9
bufio.(*Reader).fill(0xc000aae7e0)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).ReadSlice(0xc000aae7e0, 0x7f5a4a26470a, 0x0, 0x203000, 0x203000, 0x7f5a4a264710, 0xc001b29870)
	/usr/local/go/src/bufio/bufio.go:360 +0x3d
bufio.(*Reader).ReadLine(0xc000aae7e0, 0x203000, 0x203000, 0x30, 0xc00120a000, 0x110, 0xc000623400)
	/usr/local/go/src/bufio/bufio.go:389 +0x34
net/textproto.(*Reader).readLineSlice(0xc000d779b0, 0xc000490e00, 0xc001b299e8, 0x4e5593, 0xc00101c100, 0xc0019a6000)
	/usr/local/go/src/net/textproto/reader.go:57 +0xd6
net/textproto.(*Reader).ReadLine(...)
	/usr/local/go/src/net/textproto/reader.go:38
net/http.readRequest(0xc000aae7e0, 0x0, 0xc000490e00, 0x0, 0x0)
	/usr/local/go/src/net/http/request.go:1027 +0xaa
net/http.(*conn).readRequest(0xc000878640, 0x2ed3970, 0xc0003dc900, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:986 +0x19d
net/http.(*conn).serve(0xc000878640, 0x2ed3a18, 0xc0003dc900)
	/usr/local/go/src/net/http/server.go:1878 +0x705
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3013 +0x39b

goroutine 195 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:246 +0x7c
sync.(*Once).doSlow(0xc000c94378, 0xc0000d37b8)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c94360)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:244 +0x65
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:240 +0x65

goroutine 180 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b10700)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 197 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:246 +0x7c
sync.(*Once).doSlow(0xc000c94558, 0xc000074fb8)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000c94540)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:244 +0x65
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:240 +0x65

goroutine 201 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0007c7c00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 153 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000102000)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 202 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00074a1e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:217 +0x190
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:130 +0x130

goroutine 203 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00074a280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:217 +0x190
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:130 +0x130

goroutine 204 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc000416340)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:520 +0xe6
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:529 +0x3f

goroutine 205 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a30acb8, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b5398, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc0002b5380, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc0002b5380, 0xc000b01d88, 0xc0009f2fa0, 0xa40000c0001b20d8)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc000c14de0, 0x40e338, 0xc0009f2fa0, 0xc0009f3028)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).Accept(0xc000c14de0, 0xc000c14ff0, 0xc000b01d88, 0xc0009f3028, 0x4)
	/usr/local/go/src/net/unixsock.go:260 +0x65
google.golang.org/grpc.(*Server).Serve(0xc000416ea0, 0x2eca570, 0xc000c14de0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:621 +0x27f
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1(0x2eca570, 0xc000c14de0, 0xc000416ea0)
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:62 +0xe5
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:60 +0x2c5

goroutine 206 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a30a918, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b5598, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc0002b5580, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc0002b5580, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc000c153b0, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).AcceptUnix(0xc000c153b0, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/unixsock.go:247 +0x65
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1(0xc000c153b0, 0xc0005a7380)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:73 +0x45
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:69 +0x525

goroutine 156 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a748, 0x72, 0x2c)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000864218, 0x72, 0x200, 0x200, 0xc0007456e0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).ReadMsg(0xc000864200, 0xc00016e600, 0x200, 0x200, 0xc0007456e0, 0x2c, 0x2c, 0x0, 0x0, 0x0, ...)
	/usr/local/go/src/internal/poll/fd_unix.go:249 +0x252
net.(*netFD).readMsg(0xc000864200, 0xc00016e600, 0x200, 0x200, 0xc0007456e0, 0x2c, 0x2c, 0x45983c, 0x10e564d575a7, 0x7f5a4a30a778, ...)
	/usr/local/go/src/net/fd_posix.go:67 +0x90
net.(*UDPConn).readMsg(0xc00000e088, 0xc00016e600, 0x200, 0x200, 0xc0007456e0, 0x2c, 0x2c, 0x3, 0x7f5a4a30a828, 0x10bc19ca4f39, ...)
	/usr/local/go/src/net/udpsock_posix.go:59 +0x91
net.(*UDPConn).ReadMsgUDP(0xc00000e088, 0xc00016e600, 0x200, 0x200, 0xc0007456e0, 0x2c, 0x2c, 0xc001058730, 0xc000864200, 0xc000601400, ...)
	/usr/local/go/src/net/udpsock.go:139 +0x9d
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc000874690, 0xc00000e088, 0x10bc19ca4f39, 0x422e340, 0x0, 0x0, 0x422e340, 0xc000657c28, 0x40bb0a)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:174 +0xae
github.com/miekg/dns.(*Server).readUDP(0xc0003201e0, 0xc00000e088, 0x77359400, 0x47882e0, 0x2e7d901, 0x47882e0, 0x7f5a4a164308, 0x47882e0, 0x7f5a4a164201)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:632 +0xa9
github.com/miekg/dns.defaultReader.ReadUDP(0xc0003201e0, 0xc00000e088, 0x77359400, 0x7f5a4a1642d8, 0xc001f99a90, 0x1, 0xc001058720, 0x2e7e100, 0xc001f99a90)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:154 +0x45
github.com/miekg/dns.(*Server).serveUDP(0xc0003201e0, 0xc00000e088, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:460 +0x162
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0003201e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:329 +0x237
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0003201e0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:432 +0xbc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:427 +0x828

goroutine 157 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a30a830, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000864198, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc000864180, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc000864180, 0xc, 0x7f5a71191f18, 0x10)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*TCPListener).accept(0xc0001b2648, 0x40e338, 0xc, 0x278ada0)
	/usr/local/go/src/net/tcpsock_posix.go:139 +0x32
net.(*TCPListener).Accept(0xc0001b2648, 0xc000aca001, 0xc000982d08, 0x47d93a, 0xc000aca014)
	/usr/local/go/src/net/tcpsock.go:261 +0x65
github.com/miekg/dns.(*Server).serveTCP(0xc0003202d0, 0x2eca540, 0xc0001b2648, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:417 +0x118
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0003202d0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:335 +0x12b
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0003202d0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:432 +0xbc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:427 +0x828

goroutine 237 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc00013e000, 0xc0001321e0, 0xc000db6f00, 0xc0003dad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 283 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0006fc1b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 280 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00074a988, 0x40)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc00074a978)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00074a960, 0xc000734140, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0006fc120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000656f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000656f90, 0x2e7dce0, 0xc000cf5680, 0xc0009e2301, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000656f90, 0x3b9aca00, 0x0, 0xc000bdf901, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0006fc120, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).nodesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:71 +0x385

goroutine 274 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc000416340, 0x421d970, 0xc0009c1840)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:103 +0xcc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).EnableK8sWatcher
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:425 +0x335

goroutine 323 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc000194b40, 0xc000538000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 244 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0004a7dd0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 235 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a2c0, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000ce8018, 0x72, 0xbf00, 0xbf72, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000ce8000, 0xc000e54000, 0xbf72, 0xbf72, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000ce8000, 0xc000e54000, 0xbf72, 0xbf72, 0xc0007c1cc0, 0xc000e54005, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0000c41d8, 0xc000e54000, 0xbf72, 0xbf72, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc0009da678, 0xc000e54000, 0xbf72, 0xbf72, 0xbf6d, 0xc000601400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc00097b3f8, 0x2e70da0, 0xc0009da678, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc00097b180, 0x7f5a4a0ea088, 0xc0005a7560, 0x5, 0xc0005a7560, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc00097b180, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc00097b180, 0xc000cf9000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc0003daba0, 0xc00013e578, 0x9, 0x9, 0x14, 0x7f5a711915b8, 0xc0005ebc70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc0003daba0, 0xc00013e578, 0x9, 0x9, 0x9, 0xc00167bf38, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc00013e578, 0x9, 0x9, 0x2e70c00, 0xc0003daba0, 0x0, 0x0, 0xc000c87550, 0xc000cf4330)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc00013e540, 0xc001bdebe8, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc0005ebfa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000c87500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 694 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071dc0, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b4518, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc0002b4500, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc0002b4500, 0x37e11d600, 0x0, 0x0)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*TCPListener).accept(0xc0005c8630, 0xc000b21d28, 0xc000b21d30, 0x18)
	/usr/local/go/src/net/tcpsock_posix.go:139 +0x32
net.(*TCPListener).Accept(0xc0005c8630, 0x2c04bf0, 0xc000844000, 0x2ef3858, 0xc0010a8b10)
	/usr/local/go/src/net/tcpsock.go:261 +0x65
google.golang.org/grpc.(*Server).Serve(0xc000844000, 0x2eca540, 0xc0005c8630, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:621 +0x27f
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve.func1(0xc0002b4700, 0x2eca540, 0xc0005c8630)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:112 +0x59
created by github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:111 +0x7b

goroutine 281 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc00074aa28, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc00074aa18)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00074aa00, 0xc000734200, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0006fc1b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc00019dec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00019dec0, 0x2e7dce0, 0xc000cf5380, 0xc0009e2101, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00019dec0, 0x3b9aca00, 0x0, 0xc00020ef01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0006fc1b0, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit(0xc000416340, 0x2f1be78, 0x421d960, 0xc0009c1840)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:75 +0x34a
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).EnableK8sWatcher
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:453 +0x456

goroutine 189 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc000bdb4c8, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000bdb4b8)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000bdb4a0, 0xc0001bf5c0, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0004a7dd0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc00065bf90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00065bf90, 0x2e7dce0, 0xc000afc780, 0xc000db3f01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00065bf90, 0x3b9aca00, 0x0, 0xc000a9c401, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0004a7dd0, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:84 +0x399

goroutine 245 [select, 2 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000caa700, 0xc02364bb865e625c, 0x10b2805ec004, 0x422e340, 0x2e9bb40, 0xc001814c80, 0xc001c73b90, 0xc0003dbc20, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000caa700, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0005bbec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001c73ec8, 0x2e7dcc0, 0xc000044eb0, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000caa700, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc000db3ff0, 0xc0001b3e18)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 277 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc00074a8e8, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc00074a8d8)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00074a8c0, 0xc000734080, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0006fc090)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0009a2f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000e09f90, 0x2e7dce0, 0xc0005f4060, 0xc0009c1c01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0009a2f90, 0x3b9aca00, 0x0, 0xc000b58801, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0006fc090, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEgressNATPolicyInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_egress_gateway_policy.go:86 +0x365

goroutine 275 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit(0xc000416340, 0x421d970, 0xc0009c1840)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:100 +0xcb
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).EnableK8sWatcher
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:432 +0x528

goroutine 273 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc00074a848, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc00074a838)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00074a820, 0xc000cb9fc0, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0006fc000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc00029cf90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00029cf90, 0x2e7dce0, 0xc0004afd10, 0xc0009c1a01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00029cf90, 0x3b9aca00, 0x0, 0xc000b58501, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0006fc000, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideNetworkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_network_policy.go:104 +0x46a

goroutine 666 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a072330, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000f68018, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc000f68000, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc000f68000, 0xc0003399a8, 0x0, 0x0)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc000f482a0, 0xc000b20d28, 0xc000b20d30, 0x18)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).Accept(0xc000f482a0, 0x2c04bf0, 0xc000b96000, 0x2ef3908, 0xc0003399a8)
	/usr/local/go/src/net/unixsock.go:260 +0x65
google.golang.org/grpc.(*Server).Serve(0xc000b96000, 0x2eca570, 0xc000f482a0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:621 +0x27f
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve.func1(0xc000f68200, 0x2eca570, 0xc000f482a0)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:112 +0x59
created by github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:111 +0x7b

goroutine 239 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc00074a7a8, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc00074a798)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00074a780, 0xc000cb9f00, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007c9ef0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0002a0f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0002a0f90, 0x2e7dce0, 0xc000afdf50, 0xc0009ccf01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0002a0f90, 0x3b9aca00, 0x0, 0xc000b58201, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007c9ef0, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:165 +0x46a

goroutine 667 [chan receive, 305 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2(0xc000577680, 0xc000f68200)
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:210 +0x4a
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:209 +0xfe6

goroutine 184 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a490, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000479098, 0x72, 0x5000, 0x5087, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000479080, 0xc000161500, 0x5087, 0x5087, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000479080, 0xc000161500, 0x5087, 0x5087, 0xc000bd9180, 0xc000161505, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000616010, 0xc000161500, 0x5087, 0x5087, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc0005de300, 0xc000161500, 0x5087, 0x5087, 0x5082, 0xc000601400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc00004ecf8, 0x2e70da0, 0xc0005de300, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc00004ea80, 0x7f5a4a0ea088, 0xc0000dc510, 0x5, 0xc0000dc510, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc00004ea80, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc00004ea80, 0xc0008f8000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc000537f20, 0xc000a9c2d8, 0x9, 0x9, 0x14, 0x7f5a71191108, 0xc000adfc70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc000537f20, 0xc000a9c2d8, 0x9, 0x9, 0x9, 0xc00167b098, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc000a9c2d8, 0x9, 0x9, 0x2e70c00, 0xc000537f20, 0x0, 0x0, 0xc000d0a650, 0xc00061c7b0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000a9c2a0, 0xc000da4768, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000adffa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000d0a600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 340 [syscall, 305 minutes]:
syscall.Syscall6(0xe8, 0x22, 0xc000925c2c, 0x7, 0xffffffffffffffff, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/syscall/asm_linux_amd64.s:43 +0x5
golang.org/x/sys/unix.EpollWait(0x22, 0xc000925c2c, 0x7, 0x7, 0xffffffffffffffff, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:77 +0x72
github.com/fsnotify/fsnotify.(*fdPoller).wait(0xc000b7ae40, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify_poller.go:86 +0x91
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000876050)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify.go:192 +0x206
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify.go:59 +0x1ab

goroutine 191 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc000bdb568, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000bdb558)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000bdb540, 0xc0001bf740, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0004a7e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0002a1f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0005e9f90, 0x2e7dce0, 0xc000c15860, 0xc000ca2c01, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0002a1f90, 0x3b9aca00, 0x0, 0xc000d0b301, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0004a7e60, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:79 +0x339

goroutine 257 [sync.Cond.Wait, 260 minutes]:
sync.runtime_notifyListWait(0xc000bdb608, 0x2)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000bdb5f8)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000bdb5e0, 0xc0001bf800, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0004a7ef0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000addf90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000addf90, 0x2e7dce0, 0xc0004af8f0, 0xc0009c1801, 0xc000c45bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000addf90, 0x3b9aca00, 0x0, 0xc000b38801, 0xc000c45bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0004a7ef0, 0xc000c45bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointSlicesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoint_slice.go:152 +0x4f4

goroutine 367 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc0015ac000, 0x1, 0x0)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:283 +0x109
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1(0xc0010b1b30)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:97 +0x77
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:95 +0x22a

goroutine 528 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:246 +0x7c
sync.(*Once).doSlow(0xc001581398, 0xc000c257b8)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001581380)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:244 +0x65
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:240 +0x65

goroutine 263 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc000c45bc0, 0xc0004a7ef0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 264 [select, 6 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000a9c540, 0xc02364689e92f8a1, 0x10654bd55e54, 0x422e340, 0x2e9bb40, 0xc001bb2800, 0xc000ac5b90, 0xc00109eae0, 0xc000c45bc0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000a9c540, 0xc000c45bc0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc001147ec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ac5ec8, 0x2e7dcc0, 0xc000877540, 0x1, 0xc000c45bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000a9c540, 0xc000c45bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009c18a0, 0xc00000df08)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 16266 [select, 260 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000a9c540, 0xc000c45bc0, 0xc001a3b740, 0xc00109eae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 587 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1(0x2ed3970, 0xc000b5bb80, 0xc000b6a2b8)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:90 +0x48
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:89 +0x71

goroutine 594 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a30a008, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b4218, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc0002b4200, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc0002b4200, 0xc000da0900, 0xc0000d45c0, 0x40703a)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc000c6de00, 0xc0000d45e8, 0x2157b1e, 0x0)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).Accept(0xc000c6de00, 0xc000b5bb80, 0x2ed3900, 0xc000b5bb80, 0xc000b6a2b8)
	/usr/local/go/src/net/unixsock.go:260 +0x65
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc000b6a2b8, 0x2ed3970, 0xc000b5bb80)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:95 +0xb3
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:81 +0x13f

goroutine 647 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000e86c00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 290 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0007c9ef0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 269 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0006fc000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 284 [select, 2 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc00013e620, 0xc02364aa9f2c014b, 0x10a2c40eb703, 0x422e340, 0x2e9bb40, 0xc001c3ba40, 0xc001aadb90, 0xc00098cf00, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00013e620, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000987ec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001aadec8, 0x2e7dcc0, 0xc000739db0, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00013e620, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009e21a0, 0xc0005a7fc8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 695 [chan receive, 305 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3(0xc000577680, 0xc0002b4700, 0xc0005c8600)
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x4a
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:272 +0x16f2

goroutine 296 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc00013e620, 0xc0001321e0, 0xc000e842a0, 0xc00098cf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 101404 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0xc001f08ca0, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc001f08c90)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc001f08c88, 0xc001159a00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc001f08c60, 0xc001159a00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc001f094a0, 0x2ab12f4, 0x7f5a4a0c0228)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc001f094a0, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc001f094a0, 0x2674ce0, 0xc0017f13b0, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001d83e30, 0xc0007cb800, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001c06780, 0x0, 0x2e9b8c0, 0xc00115b3c0, 0x2, 0x2525c20, 0x2c07200, 0xc0006740d0, 0xc000075740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001cf2f80, 0x300000000203000, 0x203000, 0x203000, 0x203000, 0x203000, 0x4e45fc)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00115b0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 270 [select, 4 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000a9c620, 0xc0236484a5c0254b, 0x107f66baeb05, 0x422e340, 0x2e9bb40, 0xc001a4cec0, 0xc001c6db90, 0xc0003dbc80, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000a9c620, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000986ec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001c6dec8, 0x2e7dcc0, 0xc000877770, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000a9c620, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009c1a80, 0xc00066e000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 693 [select, 305 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2(0xc000f48900, 0xc001842c30, 0xc001842c60, 0xc0000c40a0, 0xc0000c40a8, 0xc0005c85e8)
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:149 +0x151
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:146 +0x206

goroutine 308 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc0000b22a8, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc0000b2298)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0000b2280, 0xc00079a180, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007be090)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000b23f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0009a5f90, 0x2e7dce0, 0xc00046e3f0, 0xc0009fa001, 0xc0008080c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000b23f90, 0x3b9aca00, 0x0, 0xc000818001, 0xc0008080c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007be090, 0xc0008080c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:98 +0xb8

goroutine 309 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:64
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc000808180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:107 +0x49
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:105 +0x58

goroutine 303 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000a9c620, 0xc0001321e0, 0xc001000cc0, 0xc0003dbc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 649 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000e86d00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 311 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc0000b23e8, 0x2)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc0000b23d8)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0000b23c0, 0xc00079a240, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007be120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc00099ef90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00099ef90, 0x2e7dce0, 0xc00046e6f0, 0xc0009fa201, 0xc0008082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00099ef90, 0x3b9aca00, 0x0, 0xc00081c001, 0xc0008082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007be120, 0xc0008082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0xb9

goroutine 312 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:64
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc000808360)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:107 +0x49
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:105 +0x58

goroutine 379 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b10c00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 315 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0008080c0, 0xc0007be090)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 322 [sync.Cond.Wait, 150 minutes]:
sync.runtime_notifyListWait(0xc000619568, 0x10)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000619558)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000619540, 0xc000b5a480, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000538000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0009a3f90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0009a2f90, 0x2e7dce0, 0xc000ab6870, 0xc000aca001, 0xc000194b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0009a3f90, 0x3b9aca00, 0x0, 0xc000c00e01, 0xc000194b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc000538000, 0xc000194b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:147 +0x37a

goroutine 102247 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0xc000ddb0c0, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000ddb0b0)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000ddb0a8, 0xc0015f8e00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000ddb080, 0xc0015f8e00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc000ddb4a0, 0x2ab12f4, 0x7f5a4a2641c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc000ddb4a0, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc000ddb4a0, 0x2674ce0, 0xc0003651b8, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000fd54a0, 0xc001f1e000, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001cc1b30, 0x0, 0x2e9b8c0, 0xc001b14940, 0x2, 0x2525c20, 0x2a89d00, 0xc0006740d0, 0xc000e3af40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001935f00, 0x30000c001d75110, 0x269cb40, 0xc0003ec330, 0xc001d74e00, 0x9, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001b14900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 288 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0006fc120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 316 [select, 6 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc0008f0000, 0xc023646926174355, 0x1065ca8f3d3e, 0x422e340, 0x2e9bb40, 0xc001bb3180, 0xc000cd9b90, 0xc0009a9740, 0xc0008080c0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008f0000, 0xc0008080c0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0009046c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000cd9ec8, 0x2e7dcc0, 0xc0000ac370, 0x1, 0xc0008080c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008f0000, 0xc0008080c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009fa070, 0xc0009da1b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 175 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc0008f0000, 0xc0008080c0, 0xc000f43bc0, 0xc0009a9740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 324 [select, 4 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000906000, 0xc0236481e5b26b44, 0x107cd70682fb, 0x422e340, 0x2e9bb40, 0xc001a5c640, 0xc001623b90, 0xc000e9cb40, 0xc000194b40, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000906000, 0xc000194b40, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000ae8ec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001623ec8, 0x2e7dcc0, 0xc0009ee3c0, 0x1, 0xc000194b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000906000, 0xc000194b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc000aca070, 0xc000aa61e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 337 [select, 2 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc00013e700, 0xc023648c1b79a0f3, 0x1086589812bf, 0x422e340, 0x2e9bb40, 0xc001c8cc40, 0xc001633b90, 0xc00098cd20, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00013e700, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0009826c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001633ec8, 0x2e7dcc0, 0xc000739ea0, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00013e700, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009e2350, 0xc000a82078)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 377 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000906000, 0xc000194b40, 0xc000db60c0, 0xc000e9cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 295 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc00013e700, 0xc0001321e0, 0xc000133f80, 0xc00098cd20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 669 [select, 305 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader/fswatcher.(*Watcher).loop(0xc000f48840)
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/fswatcher/fswatcher.go:221 +0xe7
created by github.com/cilium/cilium/pkg/crypto/certloader/fswatcher.New
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/fswatcher/fswatcher.go:109 +0x1cb

goroutine 668 [syscall, 305 minutes]:
syscall.Syscall6(0xe8, 0x3d, 0xc001acdc2c, 0x7, 0xffffffffffffffff, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/syscall/asm_linux_amd64.s:43 +0x5
golang.org/x/sys/unix.EpollWait(0x3d, 0xc001acdc2c, 0x7, 0x7, 0xffffffffffffffff, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:77 +0x72
github.com/fsnotify/fsnotify.(*fdPoller).wait(0xc0010c21c0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify_poller.go:86 +0x91
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000876140)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify.go:192 +0x206
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/inotify.go:59 +0x1ab

goroutine 356 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0001321e0, 0xc0006fc090)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 783 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1(0xc000c95860)
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:339 +0xb0
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:335 +0x50

goroutine 320 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc0008082a0, 0xc0007be120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 357 [select, 6 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000a9c700, 0xc023646fdd034ad8, 0x106c0ace92a5, 0x422e340, 0x2e9bb40, 0xc00115b0c0, 0xc000cddb90, 0xc000e9c900, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000a9c700, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000985ec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000cddec8, 0x2e7dcc0, 0xc000877950, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000a9c700, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009c1c00, 0xc00066e0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 369 [select, 4 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc0008f00e0, 0xc02364941cda6b42, 0x108dcd521cfc, 0x422e340, 0x2e9bb40, 0xc001b14900, 0xc0019d3b90, 0xc00109e120, 0xc0008082a0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008f00e0, 0xc0008082a0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0009056c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0019d3ec8, 0x2e7dcc0, 0xc0000ac8c0, 0x1, 0xc0008082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008f00e0, 0xc0008082a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009fa200, 0xc0009da270)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 691 [IO wait, 150 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071f90, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b4098, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc0002b4080, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc0002b4080, 0x0, 0x0, 0xc0009a4db8)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc001842090, 0x60acf84f, 0xc0009a4de0, 0x498546)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).Accept(0xc001842090, 0xc0009a4e30, 0x18, 0xc000da1b00, 0x6f9b7b)
	/usr/local/go/src/net/unixsock.go:260 +0x65
net/http.(*Server).Serve(0xc0009076c0, 0x2eca570, 0xc001842090, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:2981 +0x285
github.com/cilium/cilium/api/v1/server.(*Server).Serve.func1(0xc0011c2070, 0xc0009076c0, 0xc0003de000, 0x2eca570, 0xc001842090)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:199 +0x71
created by github.com/cilium/cilium/api/v1/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:197 +0x14e9

goroutine 451 [select, 2 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc000bb3340)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:856 +0x2d8
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:848 +0x3f

goroutine 380 [select, 305 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1(0xc000e9cf60, 0xc000c943f8)
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:151 +0xaf
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:143 +0x49

goroutine 926 [select, 66 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc001e75ef0, 0x1, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:395 +0xff
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001ce31a0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:513 +0x1dd
google.golang.org/grpc/internal/transport.newHTTP2Server.func2(0xc00048b380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:291 +0xd7
created by google.golang.org/grpc/internal/transport.newHTTP2Server
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:288 +0x1110

goroutine 648 [semacquire, 305 minutes]:
sync.runtime_Semacquire(0xc0011c2078)
	/usr/local/go/src/runtime/sema.go:56 +0x45
sync.(*WaitGroup).Wait(0xc0011c2070)
	/usr/local/go/src/sync/waitgroup.go:130 +0x65
github.com/cilium/cilium/api/v1/server.(*Server).Serve(0xc0003de000, 0xc00109ef00, 0xc000ae8fb0)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:335 +0x276
github.com/cilium/cilium/daemon/cmd.runDaemon.func3(0xc001985020, 0xc0003de000)
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1721 +0x2b
created by github.com/cilium/cilium/daemon/cmd.runDaemon
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1720 +0x17f1

goroutine 847 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a072248, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b5018, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc0002b5000, 0xc001846000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc0002b5000, 0xc001846000, 0x1000, 0x1000, 0x43afdc, 0xc001cb5c38, 0x469ba0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0000c4678, 0xc001846000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*persistConn).Read(0xc00167db00, 0xc001846000, 0x1000, 0x1000, 0xc0004993e0, 0xc001cb5d40, 0x405795)
	/usr/local/go/src/net/http/transport.go:1922 +0x77
bufio.(*Reader).fill(0xc0003aa420)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).Peek(0xc0003aa420, 0x1, 0x0, 0x1, 0x4, 0x1, 0x3)
	/usr/local/go/src/bufio/bufio.go:139 +0x4f
net/http.(*persistConn).readLoop(0xc00167db00)
	/usr/local/go/src/net/http/transport.go:2083 +0x1a8
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1743 +0xc77

goroutine 291 [select, 6 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000caab60, 0xc023646822e74d3f, 0x1064d8f41eed, 0x422e340, 0x2e9bb40, 0xc00182aac0, 0xc001117b90, 0xc000977f80, 0xc0001321e0, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000caab60, 0xc0001321e0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000ae26c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001117ec8, 0x2e7dcc0, 0xc000045810, 0x1, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000caab60, 0xc0001321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc0009ccfa0, 0xc0009c29d8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 174 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000caab60, 0xc0001321e0, 0xc000f439e0, 0xc000977f80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 434 [sync.Cond.Wait, 305 minutes]:
sync.runtime_notifyListWait(0xc000bdac08, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000bdabf8)
	/usr/local/go/src/sync/cond.go:56 +0x99
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000bdabe0, 0xc000f53880, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:530 +0x98
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007bf680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x42
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000ad8e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ad8e80, 0x2e7dce0, 0xc000bc1c80, 0xc000b61001, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000ad8e80, 0x3b9aca00, 0x0, 0xc000ba5801, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x98
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007bf680, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2e5
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc0001be880, 0x2ed39a8, 0xc0001a8008, 0x2ed3cf0, 0xc000bb33d8, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:336 +0x448
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1(0xc000bb33d8)
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:192 +0x73
created by github.com/cilium/cilium/pkg/allocator.(*cache).start
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:191 +0xee

goroutine 420 [select, 305 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc0001ca460, 0x2ed3970, 0xc000d1ea80, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:335 +0x1f1
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000a04d00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:208 +0xae9
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 301 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000a9c700, 0xc0001321e0, 0xc000e84ea0, 0xc000e9c900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 298 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a0f0, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0005fe098, 0x72, 0x900, 0x931, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc0005fe080, 0xc00062ca80, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc0005fe080, 0xc00062ca80, 0x931, 0x931, 0xc00099a3c0, 0xc00062ca85, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000616f08, 0xc00062ca80, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc0005c8e70, 0xc00062ca80, 0x931, 0x931, 0x92c, 0xc000623400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc000336978, 0x2e70da0, 0xc0005c8e70, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc000336700, 0x7f5a4a0ea088, 0xc00066e198, 0x5, 0xc00066e198, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc000336700, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc000336700, 0xc000e9f000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc000e9c720, 0xc000caaff8, 0x9, 0x9, 0x14, 0x7f5a71191a68, 0xc000d33c70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc000e9c720, 0xc000caaff8, 0x9, 0x9, 0x9, 0xc0019c95a8, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc000caaff8, 0x9, 0x9, 0x2e70c00, 0xc000e9c720, 0x0, 0x0, 0xc000678950, 0xc000c09650)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000caafc0, 0xc002101110, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000d33fa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000678900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 705 [semacquire, 305 minutes]:
sync.runtime_Semacquire(0xc001c3c898)
	/usr/local/go/src/runtime/sema.go:56 +0x45
sync.(*WaitGroup).Wait(0xc001c3c890)
	/usr/local/go/src/sync/waitgroup.go:130 +0x65
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc0015ac000, 0xc0006d7380, 0xc000c95860)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:335 +0x276
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc0015ac000, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:258 +0x105
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2(0xc000f42120, 0xc0015ac000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:279 +0x2b
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:278 +0xe9

goroutine 405 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc0008f00e0, 0xc0008082a0, 0xc00108e240, 0xc00109e120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 437 [chan receive, 305 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1(0xc000db6a20, 0xc0007bf680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x34
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0xa5

goroutine 438 [select, 6 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc00013e2a0, 0xc023646a71dc9c9a, 0x1067005a885a, 0x422e340, 0x2e9bb40, 0xc000da9fc0, 0xc000cdfb90, 0xc000c04a80, 0xc000db6a20, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:463 +0x165
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00013e2a0, 0xc000db6a20, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:427 +0x6f7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x38
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc0008feec8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x5f
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000cdfec8, 0x2e7dcc0, 0xc0000ad7c0, 0x1, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0x9b
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00013e2a0, 0xc000db6a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1ed
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x2e
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1(0xc000b61030, 0xc000bb1de8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x51
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x65

goroutine 441 [select, 305 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc00013e2a0, 0xc000db6a20, 0xc0000d0ba0, 0xc000c04a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 101487 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0xc000ea0ca0, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000ea0c90)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000ea0c88, 0xc0009e9800, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000ea0c60, 0xc0009e9800, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc000ea0f20, 0x442faa, 0x7f5a4a179670)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc000ea0f20, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc000ea0f20, 0x2674ce0, 0xc000aa7008, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0016eecc0, 0xc000e7e400, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001b938b0, 0x0, 0x2e9b8c0, 0xc001a4cf00, 0x10, 0x10, 0x2e7e6e0, 0xc000bc2240, 0x10)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000bc4e60, 0x203000, 0x203000, 0x2e7e6e0, 0xc000bc2240, 0x10, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001a4cec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 568 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b11b00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 595 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000e87600)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 597 [select, 60 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable.func1(0xc000ba22e0, 0xc000ba22e1, 0x2e75de0, 0xc0003e05b0, 0xc000ba22e2, 0x4788d70, 0x0, 0x0, 0xc000ba22e8, 0xc00108f0e0)
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:126 +0x505
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:50 +0x15a

goroutine 689 [syscall, 305 minutes]:
syscall.Syscall6(0xf7, 0x1, 0x1a6, 0xc0000d7488, 0x1000004, 0x0, 0x0, 0x25df520, 0x1, 0xc0000d7570)
	/usr/local/go/src/syscall/asm_linux_amd64.s:43 +0x5
os.(*Process).blockUntilWaitable(0xc000bf22d0, 0x6, 0x0, 0xc00040a680)
	/usr/local/go/src/os/wait_waitid.go:32 +0x9e
os.(*Process).wait(0xc000bf22d0, 0x2, 0x8, 0x47926a8)
	/usr/local/go/src/os/exec_unix.go:22 +0x39
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:129
os/exec.(*Cmd).Wait(0xc000134420, 0x418e2a8, 0x25225a0)
	/usr/local/go/src/os/exec/exec.go:507 +0x65
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1(0xc000134420, 0xc0002b0930, 0x69)
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:59 +0x45
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:58 +0x645

goroutine 664 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc0004b17c0)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:128 +0x366
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:165 +0x811

goroutine 954 [select, 66 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc001f2b090, 0x1, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:395 +0xff
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001f39260, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:513 +0x1dd
google.golang.org/grpc/internal/transport.newHTTP2Server.func2(0xc001b5a900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:291 +0xd7
created by google.golang.org/grpc/internal/transport.newHTTP2Server
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:288 +0x1110

goroutine 368 [IO wait, 240 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071a20, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc00101c618, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc00101c600, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc00101c600, 0xce0db1302113b62e, 0x0, 0x0)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*TCPListener).accept(0xc0005dfa70, 0x60ace339, 0xc001227de0, 0x498546)
	/usr/local/go/src/net/tcpsock_posix.go:139 +0x32
net.(*TCPListener).Accept(0xc0005dfa70, 0xc001227e30, 0x18, 0xc000679200, 0x6f9b7b)
	/usr/local/go/src/net/tcpsock.go:261 +0x65
net/http.(*Server).Serve(0xc000cab960, 0x2eca540, 0xc0005dfa70, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:2981 +0x285
net/http.(*Server).ListenAndServe(0xc000cab960, 0x2c07178, 0x0)
	/usr/local/go/src/net/http/server.go:2910 +0xba
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:46
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1(0xc000f42120, 0xc000cab960)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:274 +0x2d
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:273 +0x85

goroutine 665 [syscall]:
syscall.Syscall6(0xe8, 0x40, 0xc0002b0230, 0x9, 0xffffffffffffffff, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/syscall/asm_linux_amd64.s:43 +0x5
golang.org/x/sys/unix.EpollWait(0x40, 0xc0002b0230, 0x9, 0x9, 0xffffffffffffffff, 0x0, 0x2e70fe0, 0xc00019f140)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:77 +0x72
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:104
github.com/cilium/ebpf/perf.(*Reader).Read(0xc000114780, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:330 +0x276
github.com/cilium/cilium/pkg/monitor/agent.(*Agent).handleEvents(0xc0002c15e0, 0x2ed3970, 0xc000f52080)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:302 +0x50a
created by github.com/cilium/cilium/pkg/monitor/agent.(*Agent).startPerfReaderLocked
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:171 +0x92

goroutine 598 [syscall, 305 minutes]:
syscall.Syscall6(0xe8, 0x28, 0xc0000b8e00, 0x9, 0xffffffffffffffff, 0x0, 0x0, 0x0, 0xc000a49fb0, 0xc0002c1f10)
	/usr/local/go/src/syscall/asm_linux_amd64.s:43 +0x5
golang.org/x/sys/unix.EpollWait(0x28, 0xc0000b8e00, 0x9, 0x9, 0xffffffffffffffff, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:77 +0x72
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:104
github.com/cilium/ebpf/perf.(*Reader).Read(0xc000878320, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:330 +0x276
github.com/cilium/cilium/pkg/signal.SetupSignalListener.func1.1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:181 +0xb8
created by github.com/cilium/cilium/pkg/signal.SetupSignalListener.func1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:178 +0x3fd

goroutine 596 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:64
github.com/cilium/cilium/pkg/ipcache.InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:391 +0x8e
created by github.com/cilium/cilium/pkg/ipcache.InitIPIdentityWatcher.func1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:389 +0x35

goroutine 609 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b6e300)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 849 [IO wait, 150 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a072418, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000f25798, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc000f25780, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc000f25780, 0x0, 0x0, 0xc001226db8)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*UnixListener).accept(0xc000ab7b90, 0x60acf84f, 0xc001226de0, 0x498546)
	/usr/local/go/src/net/unixsock_posix.go:162 +0x32
net.(*UnixListener).Accept(0xc000ab7b90, 0xc001226e30, 0x18, 0xc00048aa80, 0x6f9b7b)
	/usr/local/go/src/net/unixsock.go:260 +0x65
net/http.(*Server).Serve(0xc000a9cb60, 0x2eca570, 0xc000ab7b90, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:2981 +0x285
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve.func1(0xc001c3c890, 0xc000a9cb60, 0xc0015ac000, 0x2eca570, 0xc000ab7b90)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:199 +0x71
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:197 +0x1449

goroutine 611 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b6e400)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 692 [chan receive, 305 minutes]:
github.com/cilium/cilium/api/v1/server.(*Server).handleShutdown(0xc0003de000, 0xc0011c2070, 0xc0005c8018)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:427 +0x89
created by github.com/cilium/cilium/api/v1/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:333 +0x265

goroutine 690 [chan receive, 305 minutes]:
github.com/cilium/cilium/api/v1/server.handleInterrupt.func1()
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:506 +0x5a
sync.(*Once).doSlow(0xc0011c2080, 0xc000c277b0)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/api/v1/server.handleInterrupt(0xc0011c2080, 0xc0003de000)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:505 +0x65
created by github.com/cilium/cilium/api/v1/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:174 +0x145

goroutine 614 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:193 +0xd2
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc0010b1b30)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:129 +0x698
created by github.com/cilium/cilium/cilium-health/launch.Launch
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:74 +0x278

goroutine 615 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000b6eb00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 616 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1(0x4788ea0, 0xc000498240, 0x2c02018)
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:30 +0x65
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:28 +0x6a

goroutine 617 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c480)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 618 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c4b0)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 619 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c4e0)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 620 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c510)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 621 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c540)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 622 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c570)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 623 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c5a0)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 624 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c5d0)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 625 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c600)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 626 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c630)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 627 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c660)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 628 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1(0xc0009eee60, 0xc00127c690)
	/go/src/github.com/cilium/cilium/pkg/status/status.go:154 +0x13c
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:144 +0x49

goroutine 629 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a071ea8, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000761c98, 0x72, 0x0, 0x0, 0x2a8d46b)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Accept(0xc000761c80, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:401 +0x212
net.(*netFD).accept(0xc000761c80, 0x6040456e84cd8f32, 0x0, 0x0)
	/usr/local/go/src/net/fd_unix.go:172 +0x45
net.(*TCPListener).accept(0xc000fa74a0, 0x60ad1b81, 0xc000adcc78, 0x498546)
	/usr/local/go/src/net/tcpsock_posix.go:139 +0x32
net.(*TCPListener).Accept(0xc000fa74a0, 0xc000adccc8, 0x18, 0xc000d26c00, 0x6f9b7b)
	/usr/local/go/src/net/tcpsock.go:261 +0x65
net/http.(*Server).Serve(0xc000b300e0, 0x2eca540, 0xc000fa74a0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:2981 +0x285
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2(0xc000f997c0, 0xc000c63fb0, 0xc00103cb60, 0xe, 0x2eca540, 0xc000fa74a0)
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:81 +0xb8
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:76 +0x4cf

goroutine 632 [select, 305 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1(0x2ed3970, 0xc000396280, 0x422e340, 0xc0002b4a00)
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:663 +0xb9
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000a04100)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:208 +0xae9
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 697 [IO wait, 305 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071cd8, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b4898, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc0002b4880, 0xc001808000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc0002b4880, 0xc001808000, 0x1000, 0x1000, 0x43afdc, 0xc000b22c38, 0x469ba0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0000c4120, 0xc001808000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*persistConn).Read(0xc00167c6c0, 0xc001808000, 0x1000, 0x1000, 0xc00108ed80, 0xc000b22d40, 0x405795)
	/usr/local/go/src/net/http/transport.go:1922 +0x77
bufio.(*Reader).fill(0xc0000bd5c0)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).Peek(0xc0000bd5c0, 0x1, 0x0, 0x1, 0x4, 0x1, 0x3)
	/usr/local/go/src/bufio/bufio.go:139 +0x4f
net/http.(*persistConn).readLoop(0xc00167c6c0)
	/usr/local/go/src/net/http/transport.go:2083 +0x1a8
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1743 +0xc77

goroutine 698 [select, 305 minutes]:
net/http.(*persistConn).writeLoop(0xc00167c6c0)
	/usr/local/go/src/net/http/transport.go:2382 +0xf7
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1744 +0xc9c

goroutine 709 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a071938, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc00101c718, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc00101c700, 0xc001b42000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc00101c700, 0xc001b42000, 0x1000, 0x1000, 0x0, 0xc0011496a0, 0x46f85b)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0010a88a8, 0xc001b42000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*connReader).Read(0xc00120ac60, 0xc001b42000, 0x1000, 0x1000, 0x2eba6a0, 0xc0000dd938, 0xc000491c00)
	/usr/local/go/src/net/http/server.go:800 +0x1b9
bufio.(*Reader).fill(0xc0003dbb60)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).ReadSlice(0xc0003dbb60, 0xa, 0xc000f57e80, 0xc001149868, 0xb13c18, 0xc000f57e60, 0x3)
	/usr/local/go/src/bufio/bufio.go:360 +0x3d
bufio.(*Reader).ReadLine(0xc0003dbb60, 0x203000, 0x203000, 0x3, 0x3, 0x2e97838, 0xc001b30900)
	/usr/local/go/src/bufio/bufio.go:389 +0x34
net/textproto.(*Reader).readLineSlice(0xc001cbb410, 0xc000491d00, 0xc0011499e8, 0x4e5593, 0xc00101c700, 0xc001b43000)
	/usr/local/go/src/net/textproto/reader.go:57 +0xd6
net/textproto.(*Reader).ReadLine(...)
	/usr/local/go/src/net/textproto/reader.go:38
net/http.readRequest(0xc0003dbb60, 0x0, 0xc000491d00, 0x0, 0x0)
	/usr/local/go/src/net/http/request.go:1027 +0xaa
net/http.(*conn).readRequest(0xc0008788c0, 0x2ed3970, 0xc000cb8000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:986 +0x19d
net/http.(*conn).serve(0xc0008788c0, 0x2ed3a18, 0xc000cb8000)
	/usr/local/go/src/net/http/server.go:1878 +0x705
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3013 +0x39b

goroutine 707 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a071b08, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc00101c418, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc00101c400, 0xc001b40000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc00101c400, 0xc001b40000, 0x1000, 0x1000, 0x43afdc, 0xc000e0cc38, 0x469ba0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0010a8898, 0xc001b40000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*persistConn).Read(0xc001b2f200, 0xc001b40000, 0x1000, 0x1000, 0xc000f423c0, 0xc000e0cd40, 0x405795)
	/usr/local/go/src/net/http/transport.go:1922 +0x77
bufio.(*Reader).fill(0xc0003db620)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).Peek(0xc0003db620, 0x1, 0x0, 0x1, 0x4, 0x1, 0x3)
	/usr/local/go/src/bufio/bufio.go:139 +0x4f
net/http.(*persistConn).readLoop(0xc001b2f200)
	/usr/local/go/src/net/http/transport.go:2083 +0x1a8
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1743 +0xc77

goroutine 708 [select]:
net/http.(*persistConn).writeLoop(0xc001b2f200)
	/usr/local/go/src/net/http/transport.go:2382 +0xf7
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1744 +0xc9c

goroutine 843 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a074728, 0x72, 0x0)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0002b4e98, 0x72, 0x200, 0x200, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).ReadFrom(0xc0002b4e80, 0xc000b28a00, 0x200, 0x200, 0x0, 0x0, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:222 +0x1e6
net.(*netFD).readFrom(0xc0002b4e80, 0xc000b28a00, 0x200, 0x200, 0x0, 0xffffffffffffffff, 0x0, 0x0, 0x7f5a4a074730)
	/usr/local/go/src/net/fd_posix.go:61 +0x5b
net.(*IPConn).readFrom(0xc0000c4510, 0xc000b28a00, 0x200, 0x200, 0x0, 0x5f5dcda, 0x2e7d901, 0xc02364c5d70c6de2)
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x6a
net.(*IPConn).ReadFrom(0xc0000c4510, 0xc000b28a00, 0x200, 0x200, 0x72, 0x0, 0x0, 0xc001a2b5b8, 0x2c07430)
	/usr/local/go/src/net/iprawsock.go:129 +0x5d
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc001018240, 0xc000b28a00, 0x200, 0x200, 0x0, 0x0, 0x422e340, 0x2e7e100, 0xc001d400f0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x9b
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc001a2b560, 0xc001018240, 0xc0001015c0, 0xc001018260, 0xc00182c130)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x1a8
created by github.com/servak/go-fastping.(*Pinger).run
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0xb72

goroutine 633 [chan receive, 305 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:246 +0x7c
sync.(*Once).doSlow(0xc0009a89d8, 0xc000902fb8)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0009a89c0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:244 +0x65
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:240 +0x65

goroutine 634 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000a04200)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 794 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a074558, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000c5ea98, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000c5ea80, 0xc0019fd000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000c5ea80, 0xc0019fd000, 0x1000, 0x1000, 0xc000caa620, 0x273e380, 0xc001d11040)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000339850, 0xc0019fd000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*connReader).Read(0xc00046e090, 0xc0019fd000, 0x1000, 0x1000, 0x7f5a711915b8, 0x8, 0xc000339b50)
	/usr/local/go/src/net/http/server.go:800 +0x1b9
bufio.(*Reader).fill(0xc000e9db00)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).ReadSlice(0xc000e9db00, 0x46ae0a, 0xc000eba3a0, 0x0, 0x0, 0xc000fb9818, 0x47e5a8)
	/usr/local/go/src/bufio/bufio.go:360 +0x3d
bufio.(*Reader).ReadLine(0xc000e9db00, 0x203000, 0x203000, 0xc0011cd818, 0xc001ca4f60, 0x0, 0xc000fb98b8)
	/usr/local/go/src/bufio/bufio.go:389 +0x34
net/textproto.(*Reader).readLineSlice(0xc001de6e70, 0xc001a92500, 0xc000fb99e8, 0x4e5593, 0xc000c5ea80, 0x43afdc)
	/usr/local/go/src/net/textproto/reader.go:57 +0xd6
net/textproto.(*Reader).ReadLine(...)
	/usr/local/go/src/net/textproto/reader.go:38
net/http.readRequest(0xc000e9db00, 0x0, 0xc001a92500, 0x0, 0x0)
	/usr/local/go/src/net/http/request.go:1027 +0xaa
net/http.(*conn).readRequest(0xc0000b2500, 0x2ed3970, 0xc0009c4480, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:986 +0x19d
net/http.(*conn).serve(0xc0000b2500, 0x2ed3a18, 0xc0009c4480)
	/usr/local/go/src/net/http/server.go:1878 +0x705
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3013 +0x39b

goroutine 636 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000a04300)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 789 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000a05200)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 961 [semacquire, 305 minutes]:
sync.runtime_Semacquire(0xc000ec6490)
	/usr/local/go/src/runtime/sema.go:56 +0x45
sync.(*WaitGroup).Wait(0xc000ec6488)
	/usr/local/go/src/sync/waitgroup.go:130 +0x65
golang.org/x/sync/errgroup.(*Group).Wait(0xc000ec6480, 0x2eecc08, 0xc000a4a438)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:40 +0x31
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc000f48270, 0xc000ec6210, 0x2eecac8, 0xc000efeda0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:118 +0x3df
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler(0x267b7e0, 0xc000f48270, 0x2ee6e40, 0xc00087ea80, 0x4788d70, 0xc0010a6a00)
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:95 +0x113
google.golang.org/grpc.(*Server).processStreamingRPC(0xc000b96000, 0x2ef6b38, 0xc00048b380, 0xc0010a6a00, 0xc000f486f0, 0x41f5500, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1329 +0xcd8
google.golang.org/grpc.(*Server).handleStream(0xc000b96000, 0x2ef6b38, 0xc00048b380, 0xc0010a6a00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1409 +0xc68
google.golang.org/grpc.(*Server).serveStreams.func1.1(0xc001e49010, 0xc000b96000, 0x2ef6b38, 0xc00048b380, 0xc0010a6a00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:746 +0xab
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:744 +0xa5

goroutine 784 [chan receive, 305 minutes]:
github.com/cilium/cilium/api/v1/health/server.handleInterrupt.func1()
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:506 +0x5a
sync.(*Once).doSlow(0xc001c3c8a0, 0xc0014d57b0)
	/usr/local/go/src/sync/once.go:68 +0xec
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/api/v1/health/server.handleInterrupt(0xc001c3c8a0, 0xc0015ac000)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:505 +0x65
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:174 +0x145

goroutine 963 [select, 305 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2(0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:84 +0x11f
golang.org/x/sync/errgroup.(*Group).Go.func1(0xc000ec6480, 0xc000ec64e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:57 +0x59
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:54 +0x66

goroutine 964 [select, 305 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc00097c300, 0xc001e72de0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:91 +0xd0
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3(0xc00048b380, 0xc0010a6a00)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:102 +0x4c
golang.org/x/sync/errgroup.(*Group).Go.func1(0xc000ec6480, 0xc000ec9720)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:57 +0x59
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:54 +0x66

goroutine 850 [chan receive, 305 minutes]:
github.com/cilium/cilium/api/v1/health/server.(*Server).handleShutdown(0xc0015ac000, 0xc001c3c890, 0xc0006d7398)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:427 +0x89
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:333 +0x265

goroutine 780 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000103900)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:264 +0x1fe
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:121 +0xbb0

goroutine 848 [select]:
net/http.(*persistConn).writeLoop(0xc00167db00)
	/usr/local/go/src/net/http/transport.go:2382 +0xf7
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1744 +0xc9c

goroutine 962 [select, 305 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1(0x0, 0x0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:70 +0xdd
golang.org/x/sync/errgroup.(*Group).Go.func1(0xc000ec6480, 0xc000ec64b0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:57 +0x59
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:54 +0x66

goroutine 927 [select, 66 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00048b380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:966 +0x265
created by google.golang.org/grpc/internal/transport.newHTTP2Server
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:297 +0x1135

goroutine 782 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc001a2b560, 0x2729400)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x3d7
created by github.com/servak/go-fastping.(*Pinger).RunLoop
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x105

goroutine 955 [select, 66 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc001b5a900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:966 +0x265
created by google.golang.org/grpc/internal/transport.newHTTP2Server
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:297 +0x1135

goroutine 928 [IO wait, 66 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a072160, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000c5f318, 0x72, 0x8000, 0x8000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000c5f300, 0xc001f80000, 0x8000, 0x8000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000c5f300, 0xc001f80000, 0x8000, 0x8000, 0xd78e9e, 0x800010601, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0003399a8, 0xc001f80000, 0x8000, 0x8000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
bufio.(*Reader).Read(0xc001e72c00, 0xc000388818, 0x9, 0x9, 0x14, 0x7f5a711915b8, 0x18)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc001e72c00, 0xc000388818, 0x9, 0x9, 0x9, 0xd5f225, 0xc001c2293c, 0xc0019e6500)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc000388818, 0x9, 0x9, 0x2e70c00, 0xc001e72c00, 0x0, 0x0, 0xc001c22930, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0003887e0, 0xc001c22930, 0x422e340, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00048b380, 0xc000f01f80, 0x2c04c28)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:453 +0x9b
google.golang.org/grpc.(*Server).serveStreams(0xc000b96000, 0x2ef6b38, 0xc00048b380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:742 +0xe2
google.golang.org/grpc.(*Server).handleRawConn.func1(0xc000b96000, 0x2ef6b38, 0xc00048b380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:703 +0x3f
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:702 +0x505

goroutine 956 [IO wait, 66 minutes]:
internal/poll.runtime_pollWait(0x7f5a4a071768, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000f37798, 0x72, 0x700, 0x784, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000f37780, 0xc0019a3000, 0x784, 0x784, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000f37780, 0xc0019a3000, 0x784, 0x784, 0x77f, 0xc0019a3000, 0x5)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0010a8b10, 0xc0019a3000, 0x784, 0x784, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc000bb1a40, 0xc0019a3000, 0x784, 0x784, 0x77f, 0xc00007a400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc000a5b778, 0x2e70da0, 0xc000bb1a40, 0x40b965, 0x26a7840, 0x29c95c0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc000a5b500, 0x2e7e140, 0xc0010a8b10, 0x5, 0xc0010a8b10, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc000a5b500, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc000a5b500, 0xc001f44000, 0x8000, 0x8000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc001f39200, 0xc00013f378, 0x9, 0x9, 0x14, 0x7f5a711915b8, 0x18)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc001f39200, 0xc00013f378, 0x9, 0x9, 0x9, 0xd5f225, 0xc001c22954, 0xc000e07800)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc00013f378, 0x9, 0x9, 0x2e70c00, 0xc001f39200, 0x0, 0x0, 0xc001c22948, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc00013f340, 0xc001c22948, 0x422e340, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc001b5a900, 0xc000ee6750, 0x2c04c28)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:453 +0x9b
google.golang.org/grpc.(*Server).serveStreams(0xc000844000, 0x2ef6b38, 0xc001b5a900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:742 +0xe2
google.golang.org/grpc.(*Server).handleRawConn.func1(0xc000844000, 0x2ef6b38, 0xc001b5a900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:703 +0x3f
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:702 +0x505

goroutine 16264 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a1d8, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc001008c98, 0x72, 0x1a00, 0x1a0c, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc001008c80, 0xc00033f500, 0x1a0c, 0x1a0c, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc001008c80, 0xc00033f500, 0x1a0c, 0x1a0c, 0xc0008612c0, 0xc00033f505, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000d36708, 0xc00033f500, 0x1a0c, 0x1a0c, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc001d132a8, 0xc00033f500, 0x1a0c, 0x1a0c, 0x1a07, 0xc000600400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc000871078, 0x2e70da0, 0xc001d132a8, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc000870e00, 0x7f5a4a0ea088, 0xc000a83338, 0x5, 0xc000a83338, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc000870e00, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc000870e00, 0xc0018dd000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc00109e8a0, 0xc0008f0b98, 0x9, 0x9, 0x14, 0x7f5a71191f18, 0xc000adbc70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc00109e8a0, 0xc0008f0b98, 0x9, 0x9, 0x9, 0xc001a00ca8, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc0008f0b98, 0x9, 0x9, 0x2e70c00, 0xc00109e8a0, 0x0, 0x0, 0xc001d88c50, 0xc000ee7650)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0008f0b60, 0xc0011fd230, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000adbfa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc001d88c00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 103085 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001ec4b40, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc001ec4b30)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc001ec4b28, 0xc0010c85f0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc001ec4b00, 0xc0010c85f0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc001ec4b00, 0xc0010c85f0, 0x4, 0x4, 0x4, 0x1a0, 0x280d700, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0005c8d20, 0xc000be9400, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001d29db0, 0x0, 0x2e9b8c0, 0xc001814cc0, 0x2, 0x2525c20, 0x0, 0xc000d3f2b0, 0xc000902740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00100af40, 0x30000c0003c2d20, 0x0, 0x0, 0x0, 0x9, 0x4e4695)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001814c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 101246 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0xc000bdc300, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000bdc2f0)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000bdc2e8, 0xc00080ca00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000bdc2c0, 0xc00080ca00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc000bdd8c0, 0x2ab12f4, 0x7f5a49feb9b8)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc000bdd8c0, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc000bdd8c0, 0x2674ce0, 0xc000a69a70, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00119b5c0, 0xc000a46800, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001e40f50, 0x0, 0x2e9b8c0, 0xc00182ab00, 0xc0014da618, 0x20e54bb, 0x2a89d9b, 0x6, 0xc00048c1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001934a20, 0x30000c0014da670, 0xc0014da670, 0xc0014da698, 0x210b789, 0x2a89d9b, 0x6)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00182aac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 22619 [select]:
net/http.(*persistConn).writeLoop(0xc0016bb560)
	/usr/local/go/src/net/http/transport.go:2382 +0xf7
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1744 +0xc9c

goroutine 16160 [select, 260 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2(0xc000caa700, 0xc0001321e0, 0xc001c752c0, 0xc0003dbc20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:373 +0x125
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:367 +0x2ed

goroutine 103040 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0019e9d20, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc0019e9d10)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc0019e9d08, 0xc000db3f90, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc0019e9ce0, 0xc000db3f90, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc0019e9ce0, 0xc000db3f90, 0x4, 0x4, 0x4, 0x1a0, 0x280d700, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0006d7e48, 0xc0005fc000, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001d6e000, 0x0, 0x2e9b8c0, 0xc0017e9cc0, 0x2, 0x2525c20, 0xc0001a8000, 0xc000d3f2b0, 0xc000901740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001119de0, 0xc0003c2d20, 0x0, 0x0, 0x0, 0x0, 0x2)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0017e9c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 102539 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a660, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc000d52a18, 0x72, 0x900, 0x931, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc000d52a00, 0xc00062d500, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc000d52a00, 0xc00062d500, 0x931, 0x931, 0xc00099aa00, 0xc00062d505, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0006172f8, 0xc00062d500, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc0005c8270, 0xc00062d500, 0x931, 0x931, 0x92c, 0xc00007a400, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc001d753f8, 0x2e70da0, 0xc0005c8270, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc001d75180, 0x7f5a4a0ea088, 0xc0011932f0, 0x5, 0xc0011932f0, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc001d75180, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc001d75180, 0xc001e7c000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc001d8b620, 0xc000a003b8, 0x9, 0x9, 0x14, 0x7f5a71191a68, 0xc001e1dc70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc001d8b620, 0xc000a003b8, 0x9, 0x9, 0x9, 0xc0019815a8, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc000a003b8, 0x9, 0x9, 0x2e70c00, 0xc001d8b620, 0x0, 0x0, 0xc001b64350, 0xc000f62b10)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000a00380, 0xc002100438, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc001e1dfa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc001b64300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 101229 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0xc000d221a0, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000d22190)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000d22188, 0xc000af0e00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000d22160, 0xc000af0e00, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc000d22dc0, 0x1a0, 0x7f5a4a265128)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc000d22dc0, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc000d22dc0, 0x2674ce0, 0xc0005d8558, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0019f8930, 0xc000be9000, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001cc40f0, 0x0, 0x2e9b8c0, 0xc001bb31c0, 0xc0000755d0, 0x4334bb, 0x2c07260, 0x7f5a4a074580, 0xc0011f1b02)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011198c0, 0x203000, 0x203000, 0x1, 0x0, 0xc000075698, 0x4e45fc)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001bb3180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 16158 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30a3a8, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc001002b98, 0x72, 0x900, 0x931, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc001002b80, 0xc000ceb500, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc001002b80, 0xc000ceb500, 0x931, 0x931, 0xc0002c72c0, 0xc000ceb505, 0x0)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000408cd8, 0xc000ceb500, 0x931, 0x931, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
crypto/tls.(*atLeastReader).Read(0xc0000dd0b0, 0xc000ceb500, 0x931, 0x931, 0x92c, 0xc000460000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:776 +0x63
bytes.(*Buffer).ReadFrom(0xc000ecf078, 0x2e70da0, 0xc0000dd0b0, 0x40b965, 0x26a7840, 0x28761a0)
	/usr/local/go/src/bytes/buffer.go:204 +0xbe
crypto/tls.(*Conn).readFromUntil(0xc000ecee00, 0x7f5a4a0ea088, 0xc001193cb0, 0x5, 0xc001193cb0, 0x11)
	/usr/local/go/src/crypto/tls/conn.go:798 +0xf3
crypto/tls.(*Conn).readRecordOrCCS(0xc000ecee00, 0x0, 0x0, 0xd78e9e)
	/usr/local/go/src/crypto/tls/conn.go:605 +0x115
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:573
crypto/tls.(*Conn).Read(0xc000ecee00, 0xc0011c5000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:1276 +0x165
bufio.(*Reader).Read(0xc0003db200, 0xc0006548f8, 0x9, 0x9, 0x14, 0x7f5a711915b8, 0xc0020dbc70)
	/usr/local/go/src/bufio/bufio.go:227 +0x222
io.ReadAtLeast(0x2e70c00, 0xc0003db200, 0xc0006548f8, 0x9, 0x9, 0x9, 0xc001a00708, 0x8, 0x8)
	/usr/local/go/src/io/io.go:328 +0x87
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader(0xc0006548f8, 0x9, 0x9, 0x2e70c00, 0xc0003db200, 0x0, 0x0, 0xc001b641d0, 0xc000f19fb0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x89
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0006548c0, 0xc001d47860, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:492 +0xa5
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc0020dbfa8, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1813 +0xd8
golang.org/x/net/http2.(*ClientConn).readLoop(0xc001b64180)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1735 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:699 +0x6c5

goroutine 22637 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a071680, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc00121f398, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc00121f380, 0xc001bb1000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc00121f380, 0xc001bb1000, 0x1000, 0x1000, 0x2eca630, 0xc0005c81c8, 0xc001cb9740)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc000d36830, 0xc001bb1000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*connReader).Read(0xc000d1d410, 0xc001bb1000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:800 +0x1b9
bufio.(*Reader).fill(0xc0020fd860)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).ReadSlice(0xc0020fd860, 0xc0005c810a, 0x0, 0x1, 0xc0005c81c8, 0x4afa16, 0xc0008f028b)
	/usr/local/go/src/bufio/bufio.go:360 +0x3d
bufio.(*Reader).ReadLine(0xc0020fd860, 0x203000, 0x203000, 0x2, 0x0, 0x0, 0xc001cb98f8)
	/usr/local/go/src/bufio/bufio.go:389 +0x34
net/textproto.(*Reader).readLineSlice(0xc001e910e0, 0xc001b94200, 0xc001cb99e8, 0x4e5593, 0xc00121f380, 0xc001be6000)
	/usr/local/go/src/net/textproto/reader.go:57 +0xd6
net/textproto.(*Reader).ReadLine(...)
	/usr/local/go/src/net/textproto/reader.go:38
net/http.readRequest(0xc0020fd860, 0x0, 0xc001b94200, 0x0, 0x0)
	/usr/local/go/src/net/http/request.go:1027 +0xaa
net/http.(*conn).readRequest(0xc0009990e0, 0x2ed3970, 0xc0019e2800, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/http/server.go:986 +0x19d
net/http.(*conn).serve(0xc0009990e0, 0x2ed3a18, 0xc0019e2800)
	/usr/local/go/src/net/http/server.go:1878 +0x705
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3013 +0x39b

goroutine 22607 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a074640, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0005fe618, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc0005fe600, 0xc0011d9000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc0005fe600, 0xc0011d9000, 0x1000, 0x1000, 0xc001b82e88, 0xc001b82d18, 0x2)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0010a88d8, 0xc0011d9000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*persistConn).Read(0xc0016bac60, 0xc0011d9000, 0x1000, 0x1000, 0xc001b82dc4, 0x2, 0x2)
	/usr/local/go/src/net/http/transport.go:1922 +0x77
bufio.(*Reader).fill(0xc001ce2f00)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).Peek(0xc001ce2f00, 0x1, 0x0, 0x1, 0x1, 0x1, 0x0)
	/usr/local/go/src/bufio/bufio.go:139 +0x4f
net/http.(*persistConn).readLoop(0xc0016bac60)
	/usr/local/go/src/net/http/transport.go:2083 +0x1a8
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1743 +0xc77

goroutine 22608 [select]:
net/http.(*persistConn).writeLoop(0xc0016bac60)
	/usr/local/go/src/net/http/transport.go:2382 +0xf7
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1744 +0xc9c

goroutine 22618 [IO wait]:
internal/poll.runtime_pollWait(0x7f5a4a30aa00, 0x72, 0xffffffffffffffff)
	/usr/local/go/src/runtime/netpoll.go:222 +0x55
internal/poll.(*pollDesc).wait(0xc0005fe798, 0x72, 0x1000, 0x1000, 0xffffffffffffffff)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:87 +0x45
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:92
internal/poll.(*FD).Read(0xc0005fe780, 0xc001d66000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_unix.go:166 +0x1d5
net.(*netFD).Read(0xc0005fe780, 0xc001d66000, 0x1000, 0x1000, 0xc0005e5e88, 0xc0005e5d18, 0x2)
	/usr/local/go/src/net/fd_posix.go:55 +0x4f
net.(*conn).Read(0xc0001bb090, 0xc001d66000, 0x1000, 0x1000, 0x0, 0x0, 0x0)
	/usr/local/go/src/net/net.go:183 +0x91
net/http.(*persistConn).Read(0xc0016bb560, 0xc001d66000, 0x1000, 0x1000, 0xc0005e5dc4, 0x2, 0x2)
	/usr/local/go/src/net/http/transport.go:1922 +0x77
bufio.(*Reader).fill(0xc001c9d0e0)
	/usr/local/go/src/bufio/bufio.go:101 +0x108
bufio.(*Reader).Peek(0xc001c9d0e0, 0x1, 0x0, 0x1, 0x1, 0x1, 0x0)
	/usr/local/go/src/bufio/bufio.go:139 +0x4f
net/http.(*persistConn).readLoop(0xc0016bb560)
	/usr/local/go/src/net/http/transport.go:2083 +0x1a8
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1743 +0xc77

goroutine 102052 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001f090c0, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc001f090b0)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc001f090a8, 0xc0010c82a0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc001f09080, 0xc0010c82a0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc001f09080, 0xc0010c82a0, 0x4, 0x4, 0x4, 0xc001a58c88, 0x46a6ba, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000a68ba0, 0xc002018000, 0x2000, 0x2600, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0017804b0, 0x0, 0x2e9b8c0, 0xc000b78480, 0x0, 0x0, 0x0, 0xc001a58e64, 0x2)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011181a0, 0xc001a58e60, 0x0, 0x1, 0x1, 0x1, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001c8cc40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 101299 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0xc000c13d20, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000c13d10)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000c13d08, 0xc000a3b600, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000c13ce0, 0xc000a3b600, 0x200, 0x200, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
encoding/json.(*Decoder).refill(0xc000ab22c0, 0x0, 0x7f5a4a0ef3d8)
	/usr/local/go/src/encoding/json/stream.go:165 +0xeb
encoding/json.(*Decoder).readValue(0xc000ab22c0, 0x0, 0x0, 0x2619f40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x1ff
encoding/json.(*Decoder).Decode(0xc000ab22c0, 0x2674ce0, 0xc000bcf3c8, 0x203000, 0x203000)
	/usr/local/go/src/encoding/json/stream.go:63 +0x7c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001015530, 0xc000e7e000, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a8
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001c33b30, 0x0, 0x2e9b8c0, 0xc001c8c500, 0x7000000026349a0, 0xffffffffffffffff, 0x1, 0x8, 0x26349a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000f5ee40, 0xc000a1a9a0, 0xc0001ad6a0, 0x0, 0xc0019966a8, 0x40dbdb, 0xc001cf5e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000da9fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 102747 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0000ff7a0, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc0000ff790)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc0000ff788, 0xc001bbdbb0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc0000ff760, 0xc001bbdbb0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc0000ff760, 0xc001bbdbb0, 0x4, 0x4, 0x4, 0x1a0, 0x280d700, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000a575c0, 0xc001f1f800, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001e3a690, 0x0, 0x2e9b8c0, 0xc001c3ba80, 0xc001d34618, 0x20e54bb, 0x2a89d9b, 0x6, 0xc00048c1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001cf35a0, 0xc001d74ea0, 0x269cb40, 0xc0003ec330, 0xc001d74e00, 0xc001d74e00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001c3ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 101227 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0xc000ea1900, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc000ea18f0)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc000ea18e8, 0xc0016b2580, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc000ea18c0, 0xc0016b2580, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc000ea18c0, 0xc0016b2580, 0x4, 0x4, 0x4, 0x47de05, 0x3, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000a4bc08, 0xc000151800, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0009889b0, 0x0, 0x2e9b8c0, 0xc001bb28c0, 0xc001b99618, 0x20e54bb, 0x2a89d9b, 0x6, 0xc00048c1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011193a0, 0x203000, 0x203000, 0x1, 0x0, 0xc001b99698, 0x4e4695)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001bb2800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea

goroutine 101841 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0xc001bcd220, 0xc000000000)
	/usr/local/go/src/runtime/sema.go:513 +0xf8
sync.(*Cond).Wait(0xc001bcd210)
	/usr/local/go/src/sync/cond.go:56 +0x99
golang.org/x/net/http2.(*pipe).Read(0xc001bcd208, 0xc0017298a0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:65 +0x97
golang.org/x/net/http2.transportResponseBody.Read(0xc001bcd1e0, 0xc0017298a0, 0x4, 0x4, 0x0, 0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2102 +0xaf
io.ReadAtLeast(0x7f5a4a0ee208, 0xc001bcd1e0, 0xc0017298a0, 0x4, 0x4, 0x4, 0x1a0, 0x280d700, 0x203000)
	/usr/local/go/src/io/io.go:328 +0x87
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00066edb0, 0xc001b03400, 0x400, 0x400, 0x40, 0x38, 0x277d9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x2b7
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc001d16280, 0x0, 0x2e9b8c0, 0xc001a5c680, 0xc00142e5d0, 0x4334bb, 0x2c07260, 0x7f5a4a074580, 0xc000b61b02)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x89
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00075c400, 0x203000, 0x203000, 0x1, 0x0, 0xc00142e698, 0x4e45fc)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x6e
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001a5c640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xe5
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0xea
