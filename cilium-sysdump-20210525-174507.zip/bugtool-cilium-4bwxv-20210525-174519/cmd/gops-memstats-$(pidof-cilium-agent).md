alloc: 21.44MB (22478504 bytes)
total-alloc: 1.01GB (1084366632 bytes)
sys: 73.16MB (76718034 bytes)
lookups: 0
mallocs: 11323934
frees: 11155675
heap-alloc: 21.44MB (22478504 bytes)
heap-sys: 60.75MB (63700992 bytes)
heap-idle: 33.09MB (34693120 bytes)
heap-in-use: 27.66MB (29007872 bytes)
heap-released: 29.17MB (30588928 bytes)
heap-objects: 168259
stack-in-use: 3.25MB (3407872 bytes)
stack-sys: 3.25MB (3407872 bytes)
stack-mspan-inuse: 417.30KB (427312 bytes)
stack-mspan-sys: 464.00KB (475136 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 16.00KB (16384 bytes)
other-sys: 1.37MB (1440918 bytes)
gc-sys: 5.71MB (5992528 bytes)
next-gc: when heap-alloc >= 36.63MB (38412720 bytes)
last-gc: 2021-05-25 15:44:47.931396638 +0000 UTC
gc-pause-total: 603.061754ms
gc-pause: 93684
gc-pause-end: 1621957487931396638
num-gc: 164
num-forced-gc: 0
gc-cpu-fraction: 5.6275479810642314e-05
enable-gc: true
debug-gc: false
