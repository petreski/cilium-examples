> Error while running 'ip6tables-nft -S':  exit status 4

ip6tables v1.8.4 (nf_tables): Could not fetch rule set generation id: Invalid argument

