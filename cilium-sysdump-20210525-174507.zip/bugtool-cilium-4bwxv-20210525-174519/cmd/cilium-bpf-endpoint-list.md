> Error while running 'cilium bpf endpoint list':  exec timeout

