> Error while running 'cilium bpf ct list global':  exec timeout

