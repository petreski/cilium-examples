> Error while running 'cilium bpf tunnel list':  exec timeout

