Metric                                                Labels                                                                                            Value
cilium_agent_api_process_time_seconds                 method="DELETE" path="/v1/endpoint" return_code="404"                                             0.000319
cilium_agent_api_process_time_seconds                 method="GET" path="/v1/cluster" return_code="200"                                                 0.035211
cilium_agent_api_process_time_seconds                 method="GET" path="/v1/config" return_code="200"                                                  0.000380
cilium_agent_api_process_time_seconds                 method="GET" path="/v1/fqdn" return_code="404"                                                    0.000061
cilium_agent_api_process_time_seconds                 method="GET" path="/v1/healthz" return_code="200"                                                 1.796284
cilium_agent_api_process_time_seconds                 path="/v1/ip" return_code="200" method="GET"                                                      0.000210
cilium_agent_api_process_time_seconds                 method="GET" path="/v1/map" return_code="200"                                                     0.226306
cilium_agent_bootstrap_seconds                        outcome="success" scope="bpfBase"                                                                 14.172723
cilium_agent_bootstrap_seconds                        outcome="success" scope="cleanup"                                                                 0.000643
cilium_agent_bootstrap_seconds                        outcome="success" scope="clusterMeshInit"                                                         0.000008
cilium_agent_bootstrap_seconds                        scope="daemonInit" outcome="success"                                                              0.006173
cilium_agent_bootstrap_seconds                        outcome="success" scope="earlyInit"                                                               23.149263
cilium_agent_bootstrap_seconds                        outcome="success" scope="enableConntrack"                                                         0.001450
cilium_agent_bootstrap_seconds                        outcome="success" scope="fqdn"                                                                    0.005534
cilium_agent_bootstrap_seconds                        outcome="success" scope="healthCheck"                                                             0.018933
cilium_agent_bootstrap_seconds                        outcome="success" scope="initAPI"                                                                 1.563731
cilium_agent_bootstrap_seconds                        outcome="success" scope="ipam"                                                                    0.000233
cilium_agent_bootstrap_seconds                        outcome="success" scope="k8sInit"                                                                 2.124570
cilium_agent_bootstrap_seconds                        outcome="success" scope="mapsInit"                                                                0.092637
cilium_agent_bootstrap_seconds                        outcome="success" scope="overall"                                                                 44.250027
cilium_agent_bootstrap_seconds                        outcome="success" scope="proxyStart"                                                              0.000135
cilium_agent_bootstrap_seconds                        outcome="success" scope="restore"                                                                 0.004822
cilium_api_limiter_adjustment_factor                  api_call="endpoint-delete"                                                                        0.000000
cilium_api_limiter_processed_requests_total           api_call="endpoint-delete" outcome="fail"                                                         2.000000
cilium_api_limiter_processing_duration_seconds        api_call="endpoint-delete" value="estimated"                                                      0.200000
cilium_api_limiter_processing_duration_seconds        api_call="endpoint-delete" value="mean"                                                           0.000000
cilium_api_limiter_rate_limit                         api_call="endpoint-delete" value="burst"                                                          0.000000
cilium_api_limiter_rate_limit                         api_call="endpoint-delete" value="limit"                                                          0.000000
cilium_api_limiter_requests_in_flight                 api_call="endpoint-delete" value="in-flight"                                                      0.000000
cilium_api_limiter_requests_in_flight                 api_call="endpoint-delete" value="limit"                                                          4.000000
cilium_api_limiter_wait_duration_seconds              api_call="endpoint-delete" value="max"                                                            0.000000
cilium_api_limiter_wait_duration_seconds              api_call="endpoint-delete" value="mean"                                                           0.000000
cilium_api_limiter_wait_duration_seconds              api_call="endpoint-delete" value="min"                                                            0.000000
cilium_bpf_map_ops_total                              map_name="ct4_global" operation="delete" outcome="success"                                        2.000000
cilium_bpf_map_ops_total                              map_name="ct_any4_global" operation="delete" outcome="success"                                    246.000000
cilium_bpf_map_ops_total                              map_name="egress_v4" operation="update" outcome="success"                                         1.000000
cilium_bpf_map_ops_total                              map_name="ipcache" operation="delete" outcome="success"                                           3.000000
cilium_bpf_map_ops_total                              map_name="ipcache" operation="update" outcome="success"                                           1888.000000
cilium_bpf_map_ops_total                              map_name="lb4_backends" operation="update" outcome="success"                                      6.000000
cilium_bpf_map_ops_total                              outcome="success" map_name="lb4_reverse_nat" operation="update"                                   8.000000
cilium_bpf_map_ops_total                              map_name="lb4_services_v2" operation="update" outcome="success"                                   16.000000
cilium_bpf_map_ops_total                              outcome="success" map_name="lxc" operation="delete"                                               3.000000
cilium_bpf_map_ops_total                              map_name="lxc" operation="update" outcome="success"                                               9.000000
cilium_bpf_map_ops_total                              operation="update" outcome="success" map_name="policy"                                            5.000000
cilium_bpf_maps_virtual_memory_max_bytes                                                                                                                149000192.000000
cilium_bpf_progs_virtual_memory_max_bytes                                                                                                               589824.000000
cilium_controllers_failing                                                                                                                              0.000000
cilium_controllers_runs_duration_seconds              status="success"                                                                                  8.728410
cilium_controllers_runs_total                         status="success"                                                                                  9737.000000
cilium_datapath_conntrack_dump_resets_total           area="conntrack" family="ipv4" name="dump_interrupts"                                             0.000000
cilium_datapath_conntrack_gc_duration_seconds         family="ipv4" protocol="TCP" status="completed"                                                   0.006346
cilium_datapath_conntrack_gc_duration_seconds         family="ipv4" protocol="non-TCP" status="completed"                                               0.004328
cilium_datapath_conntrack_gc_entries                  family="ipv4" protocol="TCP" status="alive"                                                       1.000000
cilium_datapath_conntrack_gc_entries                  family="ipv4" protocol="TCP" status="deleted"                                                     0.000000
cilium_datapath_conntrack_gc_entries                  status="alive" family="ipv4" protocol="non-TCP"                                                   2.000000
cilium_datapath_conntrack_gc_entries                  family="ipv4" protocol="non-TCP" status="deleted"                                                 86.000000
cilium_datapath_conntrack_gc_key_fallbacks_total      family="ipv4" protocol="TCP"                                                                      0.000000
cilium_datapath_conntrack_gc_key_fallbacks_total      family="ipv4" protocol="non-TCP"                                                                  0.000000
cilium_datapath_conntrack_gc_runs_total               family="ipv4" protocol="TCP" status="completed"                                                   11.000000
cilium_datapath_conntrack_gc_runs_total               family="ipv4" protocol="non-TCP" status="completed"                                               11.000000
cilium_endpoint                                                                                                                                         2.000000
cilium_endpoint_regeneration_time_stats_seconds       scope="bpfCompilation" status="success"                                                           15.475357
cilium_endpoint_regeneration_time_stats_seconds       scope="bpfLoadProg" status="success"                                                              1.522696
cilium_endpoint_regeneration_time_stats_seconds       scope="bpfWaitForELF" status="success"                                                            15.475862
cilium_endpoint_regeneration_time_stats_seconds       scope="bpfWriteELF" status="success"                                                              0.000869
cilium_endpoint_regeneration_time_stats_seconds       scope="mapSync" status="success"                                                                  0.000170
cilium_endpoint_regeneration_time_stats_seconds       scope="policyCalculation" status="success"                                                        0.000104
cilium_endpoint_regeneration_time_stats_seconds       scope="prepareBuild" status="success"                                                             0.000991
cilium_endpoint_regeneration_time_stats_seconds       status="success" scope="proxyConfiguration"                                                       0.000021
cilium_endpoint_regeneration_time_stats_seconds       scope="proxyPolicyCalculation" status="success"                                                   0.000678
cilium_endpoint_regeneration_time_stats_seconds       scope="proxyWaitForAck" status="success"                                                          0.000003
cilium_endpoint_regeneration_time_stats_seconds       scope="total" status="success"                                                                    17.006142
cilium_endpoint_regeneration_time_stats_seconds       scope="waitingForCTClean" status="success"                                                        0.001153
cilium_endpoint_regeneration_time_stats_seconds       scope="waitingForLock" status="success"                                                           0.000604
cilium_endpoint_regenerations_total                   outcome="success"                                                                                 2.000000
cilium_endpoint_state                                 endpoint_state="ready"                                                                            2.000000
cilium_endpoint_state                                 endpoint_state="regenerating"                                                                     0.000000
cilium_endpoint_state                                 endpoint_state="waiting-for-identity"                                                             0.000000
cilium_endpoint_state                                 endpoint_state="waiting-to-regenerate"                                                            0.000000
cilium_errors_warnings_total                          level="warning" subsystem="bandwidth-manager"                                                     1.000000
cilium_errors_warnings_total                          level="warning" subsystem="daemon"                                                                1.000000
cilium_errors_warnings_total                          level="warning" subsystem="elf"                                                                   4.000000
cilium_errors_warnings_total                          level="warning" subsystem="klog"                                                                  2.000000
cilium_errors_warnings_total                          level="warning" subsystem="probes"                                                                1.000000
cilium_event_ts                                       source="api"                                                                                      1621957536.259633
cilium_event_ts                                       source="docker"                                                                                   0.000000
cilium_event_ts                                       source="k8s"                                                                                      1621957483.770483
cilium_forward_bytes_total                            direction="EGRESS"                                                                                186303.000000
cilium_forward_bytes_total                            direction="INGRESS"                                                                               736949.000000
cilium_forward_count_total                            direction="EGRESS"                                                                                2231.000000
cilium_forward_count_total                            direction="INGRESS"                                                                               6383.000000
cilium_fqdn_gc_deletions_total                                                                                                                          0.000000
cilium_identity                                                                                                                                         6.000000
cilium_ip_addresses                                   family="ipv4"                                                                                     2.000000
cilium_ip_addresses                                   family="ipv6"                                                                                     0.000000
cilium_ipam_events_total                              action="allocate" family="ipv4"                                                                   2.000000
cilium_k8s_client_api_calls_total                     method="GET" return_code="200" host="10.96.0.1:443"                                               801.000000
cilium_k8s_client_api_calls_total                     host="10.96.0.1:443" method="PATCH" return_code="200"                                             2.000000
cilium_k8s_client_api_calls_total                     host="10.96.0.1:443" method="PUT" return_code="200"                                               2.000000
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/namespaces"                                                            0.007980
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/namespaces/{name}"                                                     0.295168
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/nodes"                                                                 0.005754
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/nodes/{name}"                                                          0.009499
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/pods"                                                                  0.114566
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/api/v1/services"                                                              0.006552
cilium_k8s_client_api_latency_time_seconds            path="/apis/apiextensions.k8s.io/v1/customresourcedefinitions" method="GET"                       0.236259
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2/ciliumclusterwidenetworkpolicies"                           0.012537
cilium_k8s_client_api_latency_time_seconds            path="/apis/cilium.io/v2/ciliumendpoints" method="GET"                                            0.012031
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2/ciliumidentities"                                           0.074518
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2/ciliumnetworkpolicies"                                      0.006966
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2/ciliumnodes"                                                0.005192
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2/ciliumnodes/{name}"                                         0.022158
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/cilium.io/v2alpha1/ciliumegressnatpolicies"                              0.011399
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/discovery.k8s.io/v1beta1/endpointslices"                                 0.015216
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/discovery.k8s.io/v1beta1/namespaces/{namespace}/endpointslices/{name}"   0.010008
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/apis/networking.k8s.io/v1/networkpolicies"                                    0.026174
cilium_k8s_client_api_latency_time_seconds            path="/healthz" method="GET"                                                                      2.902426
cilium_k8s_client_api_latency_time_seconds            method="GET" path="/version"                                                                      0.262779
cilium_k8s_client_api_latency_time_seconds            method="PATCH" path="/api/v1/nodes/{name}"                                                        0.269053
cilium_k8s_client_api_latency_time_seconds            path="/api/v1/nodes/{name}/status" method="PATCH"                                                 0.146261
cilium_k8s_client_api_latency_time_seconds            method="PUT" path="/apis/cilium.io/v2/ciliumnodes/{name}"                                         0.285648
cilium_k8s_event_lag_seconds                          source="k8s"                                                                                      0.000000
cilium_kubernetes_events_received_total               action="create" equal="false" scope="CiliumEgressNATPolicy" valid="true"                          1.000000
cilium_kubernetes_events_received_total               action="create" equal="false" scope="CiliumEndpoint" valid="true"                                 7.000000
cilium_kubernetes_events_received_total               valid="true" action="create" equal="false" scope="CiliumNode"                                     1.000000
cilium_kubernetes_events_received_total               action="create" equal="false" scope="EndpointSlice" valid="true"                                  5.000000
cilium_kubernetes_events_received_total               equal="false" scope="Node" valid="true" action="create"                                           1.000000
cilium_kubernetes_events_received_total               action="create" equal="false" scope="Pod" valid="true"                                            17.000000
cilium_kubernetes_events_received_total               action="create" equal="false" scope="Service" valid="true"                                        5.000000
cilium_kubernetes_events_received_total               action="delete" equal="false" scope="Pod" valid="true"                                            2.000000
cilium_kubernetes_events_received_total               action="update" equal="false" scope="CiliumNode" valid="true"                                     1.000000
cilium_kubernetes_events_received_total               scope="Pod" valid="true" action="update" equal="false"                                            7.000000
cilium_kubernetes_events_received_total               action="update" equal="true" scope="EndpointSlice" valid="true"                                   5.000000
cilium_kubernetes_events_received_total               action="update" equal="true" scope="Node" valid="true"                                            63.000000
cilium_kubernetes_events_received_total               action="update" equal="true" scope="Pod" valid="true"                                             5.000000
cilium_kubernetes_events_total                        action="create" scope="CiliumEgressNATPolicy" status="success"                                    1.000000
cilium_kubernetes_events_total                        scope="CiliumEndpoint" status="success" action="create"                                           7.000000
cilium_kubernetes_events_total                        action="create" scope="EndpointSlice" status="success"                                            5.000000
cilium_kubernetes_events_total                        action="create" scope="Node" status="success"                                                     1.000000
cilium_kubernetes_events_total                        action="create" scope="Pod" status="success"                                                      17.000000
cilium_kubernetes_events_total                        action="create" scope="Service" status="success"                                                  5.000000
cilium_kubernetes_events_total                        action="delete" scope="Pod" status="failed"                                                       2.000000
cilium_kubernetes_events_total                        action="update" scope="Pod" status="success"                                                      7.000000
cilium_nodes_all_datapath_validations_total                                                                                                             441.000000
cilium_nodes_all_events_received_total                event_type="add" source="local"                                                                   1.000000
cilium_nodes_all_num                                                                                                                                    1.000000
cilium_policy                                                                                                                                           0.000000
cilium_policy_endpoint_enforcement_status             enforcement="audit-both"                                                                          0.000000
cilium_policy_endpoint_enforcement_status             enforcement="audit-egress"                                                                        0.000000
cilium_policy_endpoint_enforcement_status             enforcement="audit-ingress"                                                                       0.000000
cilium_policy_endpoint_enforcement_status             enforcement="both"                                                                                0.000000
cilium_policy_endpoint_enforcement_status             enforcement="egress"                                                                              0.000000
cilium_policy_endpoint_enforcement_status             enforcement="ingress"                                                                             0.000000
cilium_policy_endpoint_enforcement_status             enforcement="none"                                                                                2.000000
cilium_policy_import_errors_total                                                                                                                       0.000000
cilium_policy_l7_denied_total                                                                                                                           0.000000
cilium_policy_l7_forwarded_total                                                                                                                        0.000000
cilium_policy_l7_parse_errors_total                                                                                                                     0.000000
cilium_policy_l7_received_total                                                                                                                         0.000000
cilium_policy_max_revision                                                                                                                              0.000000
cilium_policy_regeneration_time_stats_seconds         scope="policyCalculation" status="success"                                                        0.000056
cilium_policy_regeneration_time_stats_seconds         scope="total" status="success"                                                                    0.000079
cilium_policy_regeneration_time_stats_seconds         scope="waitingForPolicyRepository" status="success"                                               0.000001
cilium_policy_regeneration_total                                                                                                                        2.000000
cilium_process_cpu_seconds_total                                                                                                                        241.660000
cilium_process_max_fds                                                                                                                                  1048576.000000
cilium_process_open_fds                                                                                                                                 86.000000
cilium_process_resident_memory_bytes                                                                                                                    101457920.000000
cilium_process_start_time_seconds                                                                                                                       1621939120.320000
cilium_process_virtual_memory_bytes                                                                                                                     798990336.000000
cilium_process_virtual_memory_max_bytes                                                                                                                 -1.000000
cilium_subprocess_start_total                         subsystem="cilium-health"                                                                         1.000000
cilium_triggers_policy_update_call_duration_seconds   type="duration"                                                                                   0.000054
cilium_triggers_policy_update_call_duration_seconds   type="latency"                                                                                    0.000009
cilium_triggers_policy_update_folds                                                                                                                     1.000000
cilium_triggers_policy_update_total                   reason="one or more identities created or deleted"                                                1.000000
cilium_unreachable_health_endpoints                                                                                                                     0.000000
cilium_unreachable_nodes                                                                                                                                0.000000
cilium_version                                        version="1.10.0"                                                                                  0.000000
