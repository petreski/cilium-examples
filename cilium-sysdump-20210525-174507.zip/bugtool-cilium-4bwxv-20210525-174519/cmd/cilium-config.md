Conntrack                Enabled
ConntrackAccounting      Enabled
ConntrackLocal           Disabled
Debug                    Disabled
DebugLB                  Disabled
DropNotification         Enabled
MonitorAggregationLevel  Medium
PolicyAuditMode          Disabled
PolicyTracing            Disabled
PolicyVerdictNotification Enabled
TraceNotification        Enabled
k8s-configuration        
k8s-endpoint             
PolicyEnforcement        default
MonitorNumPages          64
