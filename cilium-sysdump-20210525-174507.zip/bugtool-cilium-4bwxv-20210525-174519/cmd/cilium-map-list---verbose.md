## Map: cilium_lxc
Key                Value                                                                               State   Error
10.0.0.42:0        (localhost)                                                                         sync    
10.0.0.43:0        id=1419  flags=0x0000 ifindex=19  mac=EA:93:89:20:4A:49 nodemac=F2:9E:1B:4B:2B:5A   sync    
10.0.2.15:0        (localhost)                                                                         sync    
192.168.99.102:0   (localhost)                                                                         sync    
192.168.100.59:0   (localhost)                                                                         sync    
10.88.0.1:0        (localhost)                                                                         sync    

## Map: cilium_lb4_services_v2
Key                    Value                 State   Error
10.99.4.23:80          0 (2) [FLAGS: 0x40]   sync    
10.96.0.10:9153        0 (3) [FLAGS: 0x40]   sync    
10.96.0.10:53          0 (4) [FLAGS: 0x40]   sync    
10.106.212.81:8080     0 (5) [FLAGS: 0x40]   sync    
192.168.99.102:32662   0 (6) [FLAGS: 0x42]   sync    
0.0.0.0:32662          0 (7) [FLAGS: 0x2]    sync    
10.96.0.1:443          0 (8) [FLAGS: 0x40]   sync    
10.104.146.183:80      0 (1) [FLAGS: 0x40]   sync    

## Map: cilium_policy_01419
Cache is disabled


## Map: cilium_lb4_reverse_nat
Key   Value                  State   Error
3     10.96.0.10:9153        sync    
4     10.96.0.10:53          sync    
5     10.106.212.81:8080     sync    
6     192.168.99.102:32662   sync    
7     0.0.0.0:32662          sync    
8     10.96.0.1:443          sync    
1     10.104.146.183:80      sync    
2     10.99.4.23:80          sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_lb4_backends
Key   Value                       State   Error
4     ANY://10.88.0.7:53          sync    
5     ANY://10.88.0.9:8080        sync    
6     ANY://192.168.99.102:8443   sync    
1     ANY://10.88.0.12:4245       sync    
2     ANY://10.88.0.6:8081        sync    
3     ANY://10.88.0.7:9153        sync    

## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_lb4_affinity
Cache is disabled


## Map: cilium_ipcache
Key                 Value             State   Error
10.0.0.224/32       29112 0 0.0.0.0   sync    
192.168.100.59/32   1 0 0.0.0.0       sync    
192.168.99.102/32   1 0 0.0.0.0       sync    
10.0.0.43/32        4 0 0.0.0.0       sync    
10.0.0.86/32        14156 0 0.0.0.0   sync    
10.88.0.10/32       3 0 0.0.0.0       sync    
10.0.0.110/32       28328 0 0.0.0.0   sync    
10.0.0.88/32        24690 0 0.0.0.0   sync    
10.88.0.11/32       3 0 0.0.0.0       sync    
10.0.2.15/32        1 0 0.0.0.0       sync    
10.88.0.9/32        3 0 0.0.0.0       sync    
10.88.0.8/32        3 0 0.0.0.0       sync    
10.0.0.111/32       8723 0 0.0.0.0    sync    
0.0.0.0/0           2 0 0.0.0.0       sync    
10.88.0.1/32        1 0 0.0.0.0       sync    
10.0.0.42/32        1 0 0.0.0.0       sync    
10.88.0.6/32        3 0 0.0.0.0       sync    
10.88.0.12/32       3 0 0.0.0.0       sync    
10.0.0.61/32        52646 0 0.0.0.0   sync    
10.88.0.7/32        3 0 0.0.0.0       sync    
10.0.0.213/32       6416 0 0.0.0.0    sync    

## Map: cilium_egress_v4
Key                            Value                             State   Error
10.0.0.110 192.168.100.57/32   192.168.100.130 192.168.100.130   sync    

## Map: cilium_tunnel_map
Cache is empty


## Map: cilium_policy_00158
Cache is disabled


## Map: cilium_metrics
Cache is disabled


