> Error while running 'cilium bpf policy get --all --numeric':  exec timeout

