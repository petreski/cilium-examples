Module                  Size  Used by
xt_TPROXY              16384  2
nf_tproxy_ipv6         16384  1 xt_TPROXY
nf_tproxy_ipv4         16384  1 xt_TPROXY
xt_CT                  16384  3
cls_bpf                20480  8
sch_ingress            16384  5
xt_socket              16384  1
nf_socket_ipv4         16384  1 xt_socket
nf_socket_ipv6         16384  1 xt_socket
iptable_raw            16384  1
xt_nat                 16384  7
ip_vs_sh               16384  0
ip_vs_wrr              16384  0
ip_vs_rr               16384  0
ip_vs                 200704  6 ip_vs_rr,ip_vs_sh,ip_vs_wrr
xt_comment             16384  98
xt_mark                16384  18
xt_conntrack           16384  16
ipt_MASQUERADE         16384  9
nf_conntrack_netlink    40960  0
xt_addrtype            16384  3
br_netfilter           24576  0
bridge                143360  1 br_netfilter
stp                    16384  1 bridge
llc                    16384  2 bridge,stp
iptable_nat            16384  1
nf_nat_ipv4            16384  2 ipt_MASQUERADE,iptable_nat
nf_nat                 32768  2 nf_nat_ipv4,xt_nat
nf_conntrack          131072  8 xt_conntrack,nf_nat,ipt_MASQUERADE,nf_nat_ipv4,xt_nat,nf_conntrack_netlink,xt_CT,ip_vs
nf_defrag_ipv6         16384  4 nf_conntrack,xt_socket,xt_TPROXY,ip_vs
nf_defrag_ipv4         16384  3 nf_conntrack,xt_socket,xt_TPROXY
overlay               118784  32
vboxsf                 49152  1
vboxguest             266240  2 vboxsf
