1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:6a:c4:4d brd ff:ff:ff:ff:ff:ff
    inet 10.0.2.15/24 brd 10.0.2.255 scope global dynamic eth0
       valid_lft 67841sec preferred_lft 67841sec
3: eth1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:38:b5:35 brd ff:ff:ff:ff:ff:ff
    inet 192.168.99.102/24 brd 192.168.99.255 scope global dynamic eth1
       valid_lft 321sec preferred_lft 321sec
4: eth2: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:ad:c9:29 brd ff:ff:ff:ff:ff:ff
    inet 192.168.100.59/24 brd 192.168.100.255 scope global dynamic eth2
       valid_lft 14355sec preferred_lft 14355sec
5: sit0@NONE: <NOARP> mtu 1480 qdisc noop state DOWN group default qlen 1000
    link/sit 0.0.0.0 brd 0.0.0.0
6: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:8c:08:0a:75 brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
7: cni-podman0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:d0:40:ba:4a:47 brd ff:ff:ff:ff:ff:ff
    inet 10.88.0.1/16 brd 10.88.255.255 scope global cni-podman0
       valid_lft forever preferred_lft forever
8: veth5845ca7f@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 5a:b4:69:59:07:10 brd ff:ff:ff:ff:ff:ff link-netnsid 0
9: vethec687082@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 1a:c7:60:e2:11:55 brd ff:ff:ff:ff:ff:ff link-netnsid 1
10: veth3e6b7280@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 5e:b8:29:f1:57:5f brd ff:ff:ff:ff:ff:ff link-netnsid 2
11: vethd5a33540@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 9a:4a:34:5d:45:06 brd ff:ff:ff:ff:ff:ff link-netnsid 3
12: veth9897ded0@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 5a:25:c2:90:b1:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
13: veth5b5fed33@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether c2:37:28:af:5b:77 brd ff:ff:ff:ff:ff:ff link-netnsid 5
14: veth5a33e95e@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master cni-podman0 state UP group default 
    link/ether 16:2d:b7:f3:da:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
15: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:3d:0a:dc:31:ba brd ff:ff:ff:ff:ff:ff
16: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ce:a1:57:2b:cd:7a brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.42/32 scope link cilium_host
       valid_lft forever preferred_lft forever
17: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1e:8b:d0:31:d7:97 brd ff:ff:ff:ff:ff:ff
19: lxc_health@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f2:9e:1b:4b:2b:5a brd ff:ff:ff:ff:ff:ff link-netns cilium-health
