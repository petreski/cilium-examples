nameserver 192.168.100.1
nameserver 10.0.2.3
