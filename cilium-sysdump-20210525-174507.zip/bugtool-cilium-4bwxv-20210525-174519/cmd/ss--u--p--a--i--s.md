Total: 576
TCP:   356 (estab 219, closed 97, orphaned 0, timewait 77)

Transport Total     IP        IPv6
RAW	  2         2         0        
UDP	  22        13        9        
TCP	  259       217       42       
INET	  283       232       51       
FRAG	  0         0         0        

State    Recv-Q   Send-Q        Local Address:Port          Peer Address:Port                                                                                   
UNCONN   0        0                   0.0.0.0:36298              0.0.0.0:*                                                                                      
UNCONN   0        0                127.0.0.53:domain             0.0.0.0:*                                                                                      
UNCONN   0        0            192.168.100.59:bootpc             0.0.0.0:*                                                                                      
UNCONN   0        0            192.168.99.102:bootpc             0.0.0.0:*                                                                                      
UNCONN   0        0                 10.0.2.15:bootpc             0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:sunrpc             0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:8472               0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:33224              0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:45530              0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:58090              0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:41741              0.0.0.0:*                                                                                      
UNCONN   0        0                 127.0.0.1:930                0.0.0.0:*                                                                                      
UNCONN   0        0                   0.0.0.0:hostmon            0.0.0.0:*                                                                                      
UNCONN   0        0                         *:56562                    *:*                                                                                      
UNCONN   0        0                         *:40402                    *:*                                                                                      
UNCONN   0        0                         *:sunrpc                   *:*                                                                                      
UNCONN   0        0                         *:32969                    *:*       users:(("cilium-agent",pid=1,fd=25))                                           
UNCONN   0        0                         *:8472                     *:*                                                                                      
UNCONN   0        0                         *:37248                    *:*                                                                                      
UNCONN   0        0                         *:49688                    *:*                                                                                      
UNCONN   0        0                         *:45645                    *:*                                                                                      
UNCONN   0        0                         *:hostmon                  *:*                                                                                      
