top - 15:45:25 up  5:09,  0 users,  load average: 7.39, 2.10, 1.14
Tasks:   7 total,   4 running,   3 sleeping,   0 stopped,   0 zombie
%Cpu(s): 18.6 us, 44.2 sy,  0.0 ni,  4.7 id,  0.0 wa,  0.0 hi, 32.6 si,  0.0 st
MiB Mem :   7969.8 total,   4993.5 free,   1180.1 used,   1796.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   5926.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    829 root      20   0    2760    872    772 R  87.5   0.0   0:00.30 dmesg
    782 root      20   0  711964  10204   6008 S  81.2   0.1   0:02.35 cilium-+
    822 root      20   0       0      0      0 R  81.2   0.0   0:00.57 sysctl
    832 root      20   0    3516   2492   2232 R  12.5   0.0   0:00.09 iptables
      1 root      20   0  780264  99080  53404 S   0.0   1.2   4:00.28 cilium-+
    422 root      20   0  708292   5920   3856 S   0.0   0.1   0:02.07 cilium-+
    830 root      20   0    5972   3056   2632 R   0.0   0.0   0:00.08 top
