Chain INPUT (policy ACCEPT 56142 packets, 14M bytes)
 pkts bytes target     prot opt in     out     source               destination         
2634K  544M CILIUM_INPUT  all  --  any    any     anywhere             anywhere             /* cilium-feeder: CILIUM_INPUT */
30782 1919K KUBE-EXTERNAL-SERVICES  all  --  any    any     anywhere             anywhere             ctstate NEW /* kubernetes externally-visible service portals */
2673K  563M KUBE-FIREWALL  all  --  any    any     anywhere             anywhere            

Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)
 pkts bytes target     prot opt in     out     source               destination         
 4853  268K CILIUM_FORWARD  all  --  any    any     anywhere             anywhere             /* cilium-feeder: CILIUM_FORWARD */
 4899  272K KUBE-FORWARD  all  --  any    any     anywhere             anywhere             /* kubernetes forwarding rules */
   34  2225 KUBE-SERVICES  all  --  any    any     anywhere             anywhere             ctstate NEW /* kubernetes service portals */
   23  1405 KUBE-EXTERNAL-SERVICES  all  --  any    any     anywhere             anywhere             ctstate NEW /* kubernetes externally-visible service portals */
   23  1405 CNI-FORWARD  all  --  any    any     anywhere             anywhere             /* CNI firewall plugin rules */
    0     0 DOCKER-USER  all  --  any    any     anywhere             anywhere            
    0     0 DOCKER-ISOLATION-STAGE-1  all  --  any    any     anywhere             anywhere            
    0     0 ACCEPT     all  --  any    docker0  anywhere             anywhere             ctstate RELATED,ESTABLISHED
    0     0 DOCKER     all  --  any    docker0  anywhere             anywhere            
    0     0 ACCEPT     all  --  docker0 !docker0  anywhere             anywhere            
    0     0 ACCEPT     all  --  docker0 docker0  anywhere             anywhere            

Chain OUTPUT (policy ACCEPT 55658 packets, 15M bytes)
 pkts bytes target     prot opt in     out     source               destination         
2666K  516M CILIUM_OUTPUT  all  --  any    any     anywhere             anywhere             /* cilium-feeder: CILIUM_OUTPUT */
55976 3359K KUBE-SERVICES  all  --  any    any     anywhere             anywhere             ctstate NEW /* kubernetes service portals */
2705K  535M KUBE-FIREWALL  all  --  any    any     anywhere             anywhere            

Chain CILIUM_FORWARD (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 ACCEPT     all  --  any    cilium_host  anywhere             anywhere             /* cilium: any->cluster on cilium_host forward accept */
    0     0 ACCEPT     all  --  cilium_host any     anywhere             anywhere             /* cilium: cluster->any on cilium_host forward accept (nodeport) */
    0     0 ACCEPT     all  --  lxc+   any     anywhere             anywhere             /* cilium: cluster->any on lxc+ forward accept */
    0     0 ACCEPT     all  --  cilium_net any     anywhere             anywhere             /* cilium: cluster->any on cilium_net forward accept (nodeport) */

Chain CILIUM_INPUT (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 ACCEPT     all  --  any    any     anywhere             anywhere             mark match 0x200/0xf00 /* cilium: ACCEPT for proxy traffic */

Chain CILIUM_OUTPUT (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 ACCEPT     all  --  any    any     anywhere             anywhere             mark match 0xa00/0xfffffeff /* cilium: ACCEPT for proxy return traffic */
2666K  516M MARK       all  --  any    any     anywhere             anywhere             mark match ! 0xe00/0xf00 mark match ! 0xd00/0xf00 mark match ! 0xa00/0xe00 /* cilium: host->any mark as from host */ MARK xset 0xc00/0xf00

Chain CNI-ADMIN (1 references)
 pkts bytes target     prot opt in     out     source               destination         

Chain CNI-FORWARD (1 references)
 pkts bytes target     prot opt in     out     source               destination         
   23  1405 CNI-ADMIN  all  --  any    any     anywhere             anywhere             /* CNI firewall plugin rules */
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.6            ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     10.88.0.6            anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.7            ctstate RELATED,ESTABLISHED
    1    85 ACCEPT     all  --  any    any     10.88.0.7            anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.8            ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     10.88.0.8            anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.9            ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     10.88.0.9            anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.10           ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     10.88.0.10           anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.11           ctstate RELATED,ESTABLISHED
   22  1320 ACCEPT     all  --  any    any     10.88.0.11           anywhere            
    0     0 ACCEPT     all  --  any    any     anywhere             10.88.0.12           ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     10.88.0.12           anywhere            

Chain DOCKER (1 references)
 pkts bytes target     prot opt in     out     source               destination         

Chain DOCKER-ISOLATION-STAGE-1 (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 DOCKER-ISOLATION-STAGE-2  all  --  docker0 !docker0  anywhere             anywhere            
    0     0 RETURN     all  --  any    any     anywhere             anywhere            

Chain DOCKER-ISOLATION-STAGE-2 (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 DROP       all  --  any    docker0  anywhere             anywhere            
    0     0 RETURN     all  --  any    any     anywhere             anywhere            

Chain DOCKER-USER (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 RETURN     all  --  any    any     anywhere             anywhere            

Chain KUBE-EXTERNAL-SERVICES (2 references)
 pkts bytes target     prot opt in     out     source               destination         

Chain KUBE-FIREWALL (2 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 DROP       all  --  any    any     anywhere             anywhere             /* kubernetes firewall for dropping marked packets */ mark match 0x8000/0x8000
    0     0 DROP       all  --  any    any    !127.0.0.0/8          127.0.0.0/8          /* block incoming localnet connections */ ! ctstate RELATED,ESTABLISHED,DNAT

Chain KUBE-FORWARD (1 references)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 DROP       all  --  any    any     anywhere             anywhere             ctstate INVALID
    0     0 ACCEPT     all  --  any    any     anywhere             anywhere             /* kubernetes forwarding rules */ mark match 0x4000/0x4000
   92  4784 ACCEPT     all  --  any    any     anywhere             anywhere             /* kubernetes forwarding conntrack pod source rule */ ctstate RELATED,ESTABLISHED
    0     0 ACCEPT     all  --  any    any     anywhere             anywhere             /* kubernetes forwarding conntrack pod destination rule */ ctstate RELATED,ESTABLISHED

Chain KUBE-KUBELET-CANARY (0 references)
 pkts bytes target     prot opt in     out     source               destination         

Chain KUBE-PROXY-CANARY (0 references)
 pkts bytes target     prot opt in     out     source               destination         

Chain KUBE-SERVICES (2 references)
 pkts bytes target     prot opt in     out     source               destination         
