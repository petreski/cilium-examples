> Error while running 'iptables-nft-save -c':  exit status 4

iptables-nft-save v1.8.4 (nf_tables): Could not fetch rule set generation id: Invalid argument

