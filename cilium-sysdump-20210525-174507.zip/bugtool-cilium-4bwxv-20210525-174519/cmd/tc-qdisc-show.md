qdisc noqueue 0: dev lo root refcnt 2 
qdisc pfifo_fast 0: dev eth0 root refcnt 2 bands 3 priomap  1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
qdisc pfifo_fast 0: dev eth1 root refcnt 2 bands 3 priomap  1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
qdisc clsact ffff: dev eth1 parent ffff:fff1 
qdisc pfifo_fast 0: dev eth2 root refcnt 2 bands 3 priomap  1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
qdisc noqueue 0: dev docker0 root refcnt 2 
qdisc noqueue 0: dev cni-podman0 root refcnt 2 
qdisc noqueue 0: dev veth5845ca7f root refcnt 2 
qdisc noqueue 0: dev vethec687082 root refcnt 2 
qdisc noqueue 0: dev veth3e6b7280 root refcnt 2 
qdisc noqueue 0: dev vethd5a33540 root refcnt 2 
qdisc noqueue 0: dev veth9897ded0 root refcnt 2 
qdisc noqueue 0: dev veth5b5fed33 root refcnt 2 
qdisc noqueue 0: dev veth5a33e95e root refcnt 2 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
