xdp:

tc:
eth1(3) clsact/ingress bpf_netdev_eth1.o:[from-netdev] id 431
eth1(3) clsact/egress bpf_netdev_eth1.o:[to-netdev] id 438
cilium_net(15) clsact/ingress bpf_host_cilium_net.o:[to-host] id 424
cilium_host(16) clsact/ingress bpf_host.o:[to-host] id 410
cilium_host(16) clsact/egress bpf_host.o:[from-host] id 417
cilium_vxlan(17) clsact/ingress bpf_overlay.o:[from-overlay] id 390
cilium_vxlan(17) clsact/egress bpf_overlay.o:[to-overlay] id 396
lxc_health(19) clsact/ingress bpf_lxc.o:[from-container] id 445

flow_dissector:

