Linux minikube 4.19.182 #1 SMP Wed May 5 21:20:39 UTC 2021 x86_64 x86_64 x86_64 GNU/Linux
