[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.0.0.42/32",
    "identity": 1
  },
  {
    "cidr": "10.0.0.43/32",
    "hostIP": "192.168.99.102",
    "identity": 4
  },
  {
    "cidr": "10.0.0.61/32",
    "hostIP": "192.168.99.102",
    "identity": 52646,
    "metadata": {
      "name": "client2-657df6649d-qkgqs",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.86/32",
    "hostIP": "192.168.99.102",
    "identity": 14156,
    "metadata": {
      "name": "client-8655c47fd7-q7pvv",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.88/32",
    "hostIP": "192.168.99.102",
    "identity": 24690,
    "metadata": {
      "name": "coredns-74ff55c5b-k6hvp",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.110/32",
    "hostIP": "192.168.99.102",
    "identity": 28328,
    "metadata": {
      "name": "mediabot",
      "namespace": "default",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.111/32",
    "hostIP": "192.168.99.102",
    "identity": 8723,
    "metadata": {
      "name": "echo-same-node-d7dcc498d-zx787",
      "namespace": "cilium-test",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.213/32",
    "hostIP": "192.168.99.102",
    "identity": 6416,
    "metadata": {
      "name": "hubble-relay-66d494c4d4-dxzts",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.224/32",
    "hostIP": "192.168.99.102",
    "identity": 29112,
    "metadata": {
      "name": "hubble-ui-95d74d44c-ncvgq",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.2.15/32",
    "identity": 1
  },
  {
    "cidr": "10.88.0.1/32",
    "identity": 1
  },
  {
    "cidr": "10.88.0.6/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "hubble-ui-95d74d44c-ncvgq",
      "namespace": "kube-system",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.7/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "coredns-74ff55c5b-k6hvp",
      "namespace": "kube-system",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.8/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "client-8655c47fd7-q7pvv",
      "namespace": "cilium-test",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.9/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "echo-same-node-d7dcc498d-zx787",
      "namespace": "cilium-test",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.10/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "client2-657df6649d-qkgqs",
      "namespace": "cilium-test",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.11/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "mediabot",
      "namespace": "default",
      "source": "k8s"
    }
  },
  {
    "cidr": "10.88.0.12/32",
    "hostIP": "192.168.99.102",
    "identity": 3,
    "metadata": {
      "name": "hubble-relay-66d494c4d4-dxzts",
      "namespace": "kube-system",
      "source": "k8s"
    }
  },
  {
    "cidr": "192.168.99.102/32",
    "identity": 1
  },
  {
    "cidr": "192.168.100.59/32",
    "identity": 1
  }
]

