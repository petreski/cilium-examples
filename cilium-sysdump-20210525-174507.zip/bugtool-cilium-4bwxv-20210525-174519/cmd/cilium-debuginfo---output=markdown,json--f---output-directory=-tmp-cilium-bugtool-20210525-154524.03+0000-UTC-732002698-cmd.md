> Error while running 'cilium debuginfo --output=markdown,json -f --output-directory=/tmp/cilium-bugtool-20210525-154524.03+0000-UTC-732002698/cmd':  exec timeout

