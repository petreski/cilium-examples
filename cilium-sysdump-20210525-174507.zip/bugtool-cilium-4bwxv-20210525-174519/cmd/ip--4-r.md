default via 10.0.2.2 dev eth0 proto dhcp src 10.0.2.15 metric 1024 
default via 192.168.100.1 dev eth2 proto dhcp src 192.168.100.59 metric 1024 
10.0.0.0/24 via 10.0.0.42 dev cilium_host src 10.0.0.42 
10.0.0.42 dev cilium_host scope link 
10.0.2.0/24 dev eth0 proto kernel scope link src 10.0.2.15 
10.0.2.2 dev eth0 proto dhcp scope link src 10.0.2.15 metric 1024 
10.88.0.0/16 dev cni-podman0 proto kernel scope link src 10.88.0.1 
172.17.0.0/16 dev docker0 proto kernel scope link src 172.17.0.1 linkdown 
192.168.99.0/24 dev eth1 proto kernel scope link src 192.168.99.102 
192.168.100.0/24 dev eth2 proto kernel scope link src 192.168.100.59 
192.168.100.1 dev eth2 proto dhcp scope link src 192.168.100.59 metric 1024 
