Name       IPv4 Address     Endpoint CIDR   IPv6 Address   Endpoint CIDR
minikube   192.168.99.102   10.0.0.0/24                    
