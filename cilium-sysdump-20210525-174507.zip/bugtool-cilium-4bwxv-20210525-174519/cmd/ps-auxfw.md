USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         782 68.3  0.1 711132  8224 ?        Rsl  15:45   0:02 cilium-bugtool
root         816 12.0  0.0   5900  2924 ?        R    15:45   0:00  \_ ps auxfw
root         820 14.0  0.0   6884  2056 ?        R    15:45   0:00  \_ ss -t -p -a -i -s
root         822 23.0  0.0   2708  1644 ?        R    15:45   0:00  \_ sysctl -a
root         826  8.0  0.0   5168  1040 ?        R    15:45   0:00  \_ uptime
root         828  7.0  0.0   3776   484 ?        R    15:45   0:00  \_ bash -c bpftool prog show
root         829  0.0  0.0   3980  3072 ?        R    15:45   0:00  \_ bash -c dmesg --time-format=iso
root           1  1.3  1.2 780264 99080 ?        Ssl  10:38   4:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         422  0.0  0.0 708292  5920 ?        Sl   10:39   0:02 cilium-health-responder --pidfile /var/run/cilium/state/health-endpoint.pid
