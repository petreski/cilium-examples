192.168.99.15 dev eth1 lladdr 08:00:27:8a:58:d6 STALE
10.88.0.12 dev cni-podman0 lladdr 32:8c:a1:45:bd:9d REACHABLE
10.88.0.7 dev cni-podman0 lladdr e2:40:12:ee:16:5b REACHABLE
10.88.0.11 dev cni-podman0 lladdr 22:cf:5e:1f:df:4b STALE
10.88.0.6 dev cni-podman0 lladdr 5a:0f:b7:bf:ca:3a REACHABLE
10.0.2.2 dev eth0 lladdr 52:54:00:12:35:02 STALE
192.168.99.1 dev eth1 lladdr 0a:00:27:00:00:00 REACHABLE
10.88.0.9 dev cni-podman0 lladdr ea:07:1b:c5:93:47 REACHABLE
