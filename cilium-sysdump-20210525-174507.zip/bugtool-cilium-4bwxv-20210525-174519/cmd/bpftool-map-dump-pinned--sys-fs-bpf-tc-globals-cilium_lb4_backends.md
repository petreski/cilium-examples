key: 05 00  value: 0a 58 00 09 1f 90 00 00
key: 04 00  value: 0a 58 00 07 00 35 00 00
key: 06 00  value: c0 a8 63 66 20 fb 00 00
key: 03 00  value: 0a 58 00 07 23 c1 00 00
key: 01 00  value: 0a 58 00 0c 10 95 00 00
key: 02 00  value: 0a 58 00 06 1f 91 00 00
Found 6 elements
