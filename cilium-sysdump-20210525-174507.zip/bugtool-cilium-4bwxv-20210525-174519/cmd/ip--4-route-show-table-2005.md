default via 10.0.0.42 dev cilium_host 
10.0.0.42 dev cilium_host scope link 
