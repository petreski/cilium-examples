Probe time:   2021-05-25T15:43:57Z
Nodes:
  minikube (localhost):
    Host connectivity to 192.168.99.102:
      ICMP to stack:   OK, RTT=466.168µs
      HTTP to agent:   OK, RTT=183.341µs
    Endpoint connectivity to 10.0.0.43:
      ICMP to stack:   OK, RTT=1.048688ms
      HTTP to agent:   OK, RTT=874.633µs
