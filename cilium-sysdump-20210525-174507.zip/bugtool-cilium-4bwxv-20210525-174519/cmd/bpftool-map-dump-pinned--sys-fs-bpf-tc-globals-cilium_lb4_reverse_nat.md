key: 00 08  value: 0a 60 00 01 01 bb
key: 00 05  value: 0a 6a d4 51 1f 90
key: 00 04  value: 0a 60 00 0a 00 35
key: 00 03  value: 0a 60 00 0a 23 c1
key: 00 02  value: 0a 63 04 17 00 50
key: 00 01  value: 0a 68 92 b7 00 50
key: 00 06  value: c0 a8 63 66 7f 96
key: 00 07  value: 00 00 00 00 7f 96
Found 8 elements
