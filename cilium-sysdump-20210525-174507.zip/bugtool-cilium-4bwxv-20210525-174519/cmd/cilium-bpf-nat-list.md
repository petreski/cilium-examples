> Error while running 'cilium bpf nat list':  exec timeout

