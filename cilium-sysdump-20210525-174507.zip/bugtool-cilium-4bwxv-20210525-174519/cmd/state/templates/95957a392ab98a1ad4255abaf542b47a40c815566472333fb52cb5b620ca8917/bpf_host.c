# 1 "/var/lib/cilium/bpf/bpf_host.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 306 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/var/lib/cilium/bpf/bpf_host.c" 2



# 1 "/var/lib/cilium/bpf/include/bpf/ctx/skb.h" 1
# 10 "/var/lib/cilium/bpf/include/bpf/ctx/skb.h"
# 1 "/var/lib/cilium/bpf/include/bpf/ctx/common.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/types.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/../bpf/types_mapper.h" 1






typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;

typedef __signed__ long long __s64;
typedef unsigned long long __u64;

typedef __u16 __le16;
typedef __u16 __be16;

typedef __u32 __le32;
typedef __u32 __be32;

typedef __u64 __le64;
typedef __u64 __be64;

typedef __u16 __sum16;
typedef __u32 __wsum;

typedef __u64 __aligned_u64;

typedef __u64 __net_cookie;
typedef __u64 __sock_cookie;
# 8 "/var/lib/cilium/bpf/include/linux/types.h" 2
# 8 "/var/lib/cilium/bpf/include/bpf/ctx/common.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/bpf.h" 1
# 12 "/var/lib/cilium/bpf/include/linux/bpf.h"
# 1 "/var/lib/cilium/bpf/include/linux/bpf_common.h" 1
# 13 "/var/lib/cilium/bpf/include/linux/bpf.h" 2
# 47 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum {
 BPF_REG_0 = 0,
 BPF_REG_1,
 BPF_REG_2,
 BPF_REG_3,
 BPF_REG_4,
 BPF_REG_5,
 BPF_REG_6,
 BPF_REG_7,
 BPF_REG_8,
 BPF_REG_9,
 BPF_REG_10,
 __MAX_BPF_REG,
};




struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};


struct bpf_lpm_trie_key {
 __u32 prefixlen;
 __u8 data[0];
};

struct bpf_cgroup_storage_key {
 __u64 cgroup_inode_id;
 __u32 attach_type;
};

union bpf_iter_link_info {
 struct {
  __u32 map_fd;
 } map;
};


enum bpf_cmd {
 BPF_MAP_CREATE,
 BPF_MAP_LOOKUP_ELEM,
 BPF_MAP_UPDATE_ELEM,
 BPF_MAP_DELETE_ELEM,
 BPF_MAP_GET_NEXT_KEY,
 BPF_PROG_LOAD,
 BPF_OBJ_PIN,
 BPF_OBJ_GET,
 BPF_PROG_ATTACH,
 BPF_PROG_DETACH,
 BPF_PROG_TEST_RUN,
 BPF_PROG_GET_NEXT_ID,
 BPF_MAP_GET_NEXT_ID,
 BPF_PROG_GET_FD_BY_ID,
 BPF_MAP_GET_FD_BY_ID,
 BPF_OBJ_GET_INFO_BY_FD,
 BPF_PROG_QUERY,
 BPF_RAW_TRACEPOINT_OPEN,
 BPF_BTF_LOAD,
 BPF_BTF_GET_FD_BY_ID,
 BPF_TASK_FD_QUERY,
 BPF_MAP_LOOKUP_AND_DELETE_ELEM,
 BPF_MAP_FREEZE,
 BPF_BTF_GET_NEXT_ID,
 BPF_MAP_LOOKUP_BATCH,
 BPF_MAP_LOOKUP_AND_DELETE_BATCH,
 BPF_MAP_UPDATE_BATCH,
 BPF_MAP_DELETE_BATCH,
 BPF_LINK_CREATE,
 BPF_LINK_UPDATE,
 BPF_LINK_GET_FD_BY_ID,
 BPF_LINK_GET_NEXT_ID,
 BPF_ENABLE_STATS,
 BPF_ITER_CREATE,
 BPF_LINK_DETACH,
 BPF_PROG_BIND_MAP,
};

enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
};
# 171 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
};

enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 __MAX_BPF_ATTACH_TYPE
};



enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,

 MAX_BPF_LINK_TYPE,
};
# 397 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum {
 BPF_ANY = 0,
 BPF_NOEXIST = 1,
 BPF_EXIST = 2,
 BPF_F_LOCK = 4,
};


enum {
 BPF_F_NO_PREALLOC = (1U << 0),






 BPF_F_NO_COMMON_LRU = (1U << 1),

 BPF_F_NUMA_NODE = (1U << 2),


 BPF_F_RDONLY = (1U << 3),
 BPF_F_WRONLY = (1U << 4),


 BPF_F_STACK_BUILD_ID = (1U << 5),


 BPF_F_ZERO_SEED = (1U << 6),


 BPF_F_RDONLY_PROG = (1U << 7),
 BPF_F_WRONLY_PROG = (1U << 8),


 BPF_F_CLONE = (1U << 9),


 BPF_F_MMAPABLE = (1U << 10),


 BPF_F_PRESERVE_ELEMS = (1U << 11),


 BPF_F_INNER_MAP = (1U << 12),
};
# 458 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum bpf_stats_type {

 BPF_STATS_RUN_TIME = 0,
};

enum bpf_stack_build_id_status {

 BPF_STACK_BUILD_ID_EMPTY = 0,

 BPF_STACK_BUILD_ID_VALID = 1,

 BPF_STACK_BUILD_ID_IP = 2,
};


struct bpf_stack_build_id {
 __s32 status;
 unsigned char build_id[20];
 union {
  __u64 offset;
  __u64 ip;
 };
};



union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;



 };

 struct {
  __u32 map_fd;
  __aligned_u64 key;
  union {
   __aligned_u64 value;
   __aligned_u64 next_key;
  };
  __u64 flags;
 };

 struct {
  __aligned_u64 in_batch;


  __aligned_u64 out_batch;
  __aligned_u64 keys;
  __aligned_u64 values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __aligned_u64 insns;
  __aligned_u64 license;
  __u32 log_level;
  __u32 log_size;
  __aligned_u64 log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __aligned_u64 func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __aligned_u64 line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
 };

 struct {
  __aligned_u64 pathname;
  __u32 bpf_fd;
  __u32 file_flags;
 };

 struct {
  __u32 target_fd;
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;



 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __aligned_u64 data_in;
  __aligned_u64 data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __aligned_u64 ctx_in;
  __aligned_u64 ctx_out;
  __u32 flags;
  __u32 cpu;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __aligned_u64 info;
 } info;

 struct {
  __u32 target_fd;
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __aligned_u64 prog_ids;
  __u32 prog_cnt;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
 } raw_tracepoint;

 struct {
  __aligned_u64 btf;
  __aligned_u64 btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __aligned_u64 buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  __u32 prog_fd;
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __aligned_u64 iter_info;
    __u32 iter_info_len;
   };
  };
 } link_create;

 struct {
  __u32 link_fd;

  __u32 new_prog_fd;
  __u32 flags;


  __u32 old_prog_fd;
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

} __attribute__((aligned(8)));
# 4004 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum bpf_func_id {
 BPF_FUNC_unspec, BPF_FUNC_map_lookup_elem, BPF_FUNC_map_update_elem, BPF_FUNC_map_delete_elem, BPF_FUNC_probe_read, BPF_FUNC_ktime_get_ns, BPF_FUNC_trace_printk, BPF_FUNC_get_prandom_u32, BPF_FUNC_get_smp_processor_id, BPF_FUNC_skb_store_bytes, BPF_FUNC_l3_csum_replace, BPF_FUNC_l4_csum_replace, BPF_FUNC_tail_call, BPF_FUNC_clone_redirect, BPF_FUNC_get_current_pid_tgid, BPF_FUNC_get_current_uid_gid, BPF_FUNC_get_current_comm, BPF_FUNC_get_cgroup_classid, BPF_FUNC_skb_vlan_push, BPF_FUNC_skb_vlan_pop, BPF_FUNC_skb_get_tunnel_key, BPF_FUNC_skb_set_tunnel_key, BPF_FUNC_perf_event_read, BPF_FUNC_redirect, BPF_FUNC_get_route_realm, BPF_FUNC_perf_event_output, BPF_FUNC_skb_load_bytes, BPF_FUNC_get_stackid, BPF_FUNC_csum_diff, BPF_FUNC_skb_get_tunnel_opt, BPF_FUNC_skb_set_tunnel_opt, BPF_FUNC_skb_change_proto, BPF_FUNC_skb_change_type, BPF_FUNC_skb_under_cgroup, BPF_FUNC_get_hash_recalc, BPF_FUNC_get_current_task, BPF_FUNC_probe_write_user, BPF_FUNC_current_task_under_cgroup, BPF_FUNC_skb_change_tail, BPF_FUNC_skb_pull_data, BPF_FUNC_csum_update, BPF_FUNC_set_hash_invalid, BPF_FUNC_get_numa_node_id, BPF_FUNC_skb_change_head, BPF_FUNC_xdp_adjust_head, BPF_FUNC_probe_read_str, BPF_FUNC_get_socket_cookie, BPF_FUNC_get_socket_uid, BPF_FUNC_set_hash, BPF_FUNC_setsockopt, BPF_FUNC_skb_adjust_room, BPF_FUNC_redirect_map, BPF_FUNC_sk_redirect_map, BPF_FUNC_sock_map_update, BPF_FUNC_xdp_adjust_meta, BPF_FUNC_perf_event_read_value, BPF_FUNC_perf_prog_read_value, BPF_FUNC_getsockopt, BPF_FUNC_override_return, BPF_FUNC_sock_ops_cb_flags_set, BPF_FUNC_msg_redirect_map, BPF_FUNC_msg_apply_bytes, BPF_FUNC_msg_cork_bytes, BPF_FUNC_msg_pull_data, BPF_FUNC_bind, BPF_FUNC_xdp_adjust_tail, BPF_FUNC_skb_get_xfrm_state, BPF_FUNC_get_stack, BPF_FUNC_skb_load_bytes_relative, BPF_FUNC_fib_lookup, BPF_FUNC_sock_hash_update, BPF_FUNC_msg_redirect_hash, BPF_FUNC_sk_redirect_hash, BPF_FUNC_lwt_push_encap, BPF_FUNC_lwt_seg6_store_bytes, BPF_FUNC_lwt_seg6_adjust_srh, BPF_FUNC_lwt_seg6_action, BPF_FUNC_rc_repeat, BPF_FUNC_rc_keydown, BPF_FUNC_skb_cgroup_id, BPF_FUNC_get_current_cgroup_id, BPF_FUNC_get_local_storage, BPF_FUNC_sk_select_reuseport, BPF_FUNC_skb_ancestor_cgroup_id, BPF_FUNC_sk_lookup_tcp, BPF_FUNC_sk_lookup_udp, BPF_FUNC_sk_release, BPF_FUNC_map_push_elem, BPF_FUNC_map_pop_elem, BPF_FUNC_map_peek_elem, BPF_FUNC_msg_push_data, BPF_FUNC_msg_pop_data, BPF_FUNC_rc_pointer_rel, BPF_FUNC_spin_lock, BPF_FUNC_spin_unlock, BPF_FUNC_sk_fullsock, BPF_FUNC_tcp_sock, BPF_FUNC_skb_ecn_set_ce, BPF_FUNC_get_listener_sock, BPF_FUNC_skc_lookup_tcp, BPF_FUNC_tcp_check_syncookie, BPF_FUNC_sysctl_get_name, BPF_FUNC_sysctl_get_current_value, BPF_FUNC_sysctl_get_new_value, BPF_FUNC_sysctl_set_new_value, BPF_FUNC_strtol, BPF_FUNC_strtoul, BPF_FUNC_sk_storage_get, BPF_FUNC_sk_storage_delete, BPF_FUNC_send_signal, BPF_FUNC_tcp_gen_syncookie, BPF_FUNC_skb_output, BPF_FUNC_probe_read_user, BPF_FUNC_probe_read_kernel, BPF_FUNC_probe_read_user_str, BPF_FUNC_probe_read_kernel_str, BPF_FUNC_tcp_send_ack, BPF_FUNC_send_signal_thread, BPF_FUNC_jiffies64, BPF_FUNC_read_branch_records, BPF_FUNC_get_ns_current_pid_tgid, BPF_FUNC_xdp_output, BPF_FUNC_get_netns_cookie, BPF_FUNC_get_current_ancestor_cgroup_id, BPF_FUNC_sk_assign, BPF_FUNC_ktime_get_boot_ns, BPF_FUNC_seq_printf, BPF_FUNC_seq_write, BPF_FUNC_sk_cgroup_id, BPF_FUNC_sk_ancestor_cgroup_id, BPF_FUNC_ringbuf_output, BPF_FUNC_ringbuf_reserve, BPF_FUNC_ringbuf_submit, BPF_FUNC_ringbuf_discard, BPF_FUNC_ringbuf_query, BPF_FUNC_csum_level, BPF_FUNC_skc_to_tcp6_sock, BPF_FUNC_skc_to_tcp_sock, BPF_FUNC_skc_to_tcp_timewait_sock, BPF_FUNC_skc_to_tcp_request_sock, BPF_FUNC_skc_to_udp6_sock, BPF_FUNC_get_task_stack, BPF_FUNC_load_hdr_opt, BPF_FUNC_store_hdr_opt, BPF_FUNC_reserve_hdr_opt, BPF_FUNC_inode_storage_get, BPF_FUNC_inode_storage_delete, BPF_FUNC_d_path, BPF_FUNC_copy_from_user, BPF_FUNC_snprintf_btf, BPF_FUNC_seq_printf_btf, BPF_FUNC_skb_cgroup_classid, BPF_FUNC_redirect_neigh, BPF_FUNC_per_cpu_ptr, BPF_FUNC_this_cpu_ptr, BPF_FUNC_redirect_peer, BPF_FUNC_task_storage_get, BPF_FUNC_task_storage_delete, BPF_FUNC_get_current_task_btf, BPF_FUNC_bprm_opts_set, BPF_FUNC_ktime_get_coarse_ns, BPF_FUNC_ima_inode_hash, BPF_FUNC_sock_from_file,
 __BPF_FUNC_MAX_ID,
};





enum {
 BPF_F_RECOMPUTE_CSUM = (1ULL << 0),
 BPF_F_INVALIDATE_HASH = (1ULL << 1),
};




enum {
 BPF_F_HDR_FIELD_MASK = 0xfULL,
};


enum {
 BPF_F_PSEUDO_HDR = (1ULL << 4),
 BPF_F_MARK_MANGLED_0 = (1ULL << 5),
 BPF_F_MARK_ENFORCE = (1ULL << 6),
};


enum {
 BPF_F_INGRESS = (1ULL << 0),
};


enum {
 BPF_F_TUNINFO_IPV6 = (1ULL << 0),
};


enum {
 BPF_F_SKIP_FIELD_MASK = 0xffULL,
 BPF_F_USER_STACK = (1ULL << 8),

 BPF_F_FAST_STACK_CMP = (1ULL << 9),
 BPF_F_REUSE_STACKID = (1ULL << 10),

 BPF_F_USER_BUILD_ID = (1ULL << 11),
};


enum {
 BPF_F_ZERO_CSUM_TX = (1ULL << 1),
 BPF_F_DONT_FRAGMENT = (1ULL << 2),
 BPF_F_SEQ_NUMBER = (1ULL << 3),
};




enum {
 BPF_F_INDEX_MASK = 0xffffffffULL,
 BPF_F_CURRENT_CPU = BPF_F_INDEX_MASK,

 BPF_F_CTXLEN_MASK = (0xfffffULL << 32),
};


enum {
 BPF_F_CURRENT_NETNS = (-1L),
};


enum {
 BPF_CSUM_LEVEL_QUERY,
 BPF_CSUM_LEVEL_INC,
 BPF_CSUM_LEVEL_DEC,
 BPF_CSUM_LEVEL_RESET,
};


enum {
 BPF_F_ADJ_ROOM_FIXED_GSO = (1ULL << 0),
 BPF_F_ADJ_ROOM_ENCAP_L3_IPV4 = (1ULL << 1),
 BPF_F_ADJ_ROOM_ENCAP_L3_IPV6 = (1ULL << 2),
 BPF_F_ADJ_ROOM_ENCAP_L4_GRE = (1ULL << 3),
 BPF_F_ADJ_ROOM_ENCAP_L4_UDP = (1ULL << 4),
 BPF_F_ADJ_ROOM_NO_CSUM_RESET = (1ULL << 5),
};

enum {
 BPF_ADJ_ROOM_ENCAP_L2_MASK = 0xff,
 BPF_ADJ_ROOM_ENCAP_L2_SHIFT = 56,
};






enum {
 BPF_F_SYSCTL_BASE_NAME = (1ULL << 0),
};


enum {
 BPF_LOCAL_STORAGE_GET_F_CREATE = (1ULL << 0),



 BPF_SK_STORAGE_GET_F_CREATE = BPF_LOCAL_STORAGE_GET_F_CREATE,
};


enum {
 BPF_F_GET_BRANCH_RECORDS_SIZE = (1ULL << 0),
};




enum {
 BPF_RB_NO_WAKEUP = (1ULL << 0),
 BPF_RB_FORCE_WAKEUP = (1ULL << 1),
};


enum {
 BPF_RB_AVAIL_DATA = 0,
 BPF_RB_RING_SIZE = 1,
 BPF_RB_CONS_POS = 2,
 BPF_RB_PROD_POS = 3,
};


enum {
 BPF_RINGBUF_BUSY_BIT = (1U << 31),
 BPF_RINGBUF_DISCARD_BIT = (1U << 30),
 BPF_RINGBUF_HDR_SZ = 8,
};


enum {
 BPF_SK_LOOKUP_F_REPLACE = (1ULL << 0),
 BPF_SK_LOOKUP_F_NO_REUSEPORT = (1ULL << 1),
};


enum bpf_adj_room_mode {
 BPF_ADJ_ROOM_NET,
 BPF_ADJ_ROOM_MAC,
};


enum bpf_hdr_start_off {
 BPF_HDR_START_MAC,
 BPF_HDR_START_NET,
};


enum bpf_lwt_encap_mode {
 BPF_LWT_ENCAP_SEG6,
 BPF_LWT_ENCAP_SEG6_INLINE,
 BPF_LWT_ENCAP_IP,
};


enum {
 BPF_F_BPRM_SECUREEXEC = (1ULL << 0),
};
# 4183 "/var/lib/cilium/bpf/include/linux/bpf.h"
struct __sk_buff {
 __u32 len;
 __u32 pkt_type;
 __u32 mark;
 __u32 queue_mapping;
 __u32 protocol;
 __u32 vlan_present;
 __u32 vlan_tci;
 __u32 vlan_proto;
 __u32 priority;
 __u32 ingress_ifindex;
 __u32 ifindex;
 __u32 tc_index;
 __u32 cb[5];
 __u32 hash;
 __u32 tc_classid;
 __u32 data;
 __u32 data_end;
 __u32 napi_id;


 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;


 __u32 data_meta;
 union { struct bpf_flow_keys * flow_keys; __u64 :64; } __attribute__((aligned(8)));
 __u64 tstamp;
 __u32 wire_len;
 __u32 gso_segs;
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
 __u32 gso_size;
};

struct bpf_tunnel_key {
 __u32 tunnel_id;
 union {
  __u32 remote_ipv4;
  __u32 remote_ipv6[4];
 };
 __u8 tunnel_tos;
 __u8 tunnel_ttl;
 __u16 tunnel_ext;
 __u32 tunnel_label;
};




struct bpf_xfrm_state {
 __u32 reqid;
 __u32 spi;
 __u16 family;
 __u16 ext;
 union {
  __u32 remote_ipv4;
  __u32 remote_ipv6[4];
 };
};
# 4255 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum bpf_ret_code {
 BPF_OK = 0,

 BPF_DROP = 2,

 BPF_REDIRECT = 7,
# 4269 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_LWT_REROUTE = 128,
};

struct bpf_sock {
 __u32 bound_dev_if;
 __u32 family;
 __u32 type;
 __u32 protocol;
 __u32 mark;
 __u32 priority;

 __u32 src_ip4;
 __u32 src_ip6[4];
 __u32 src_port;
 __u32 dst_port;
 __u32 dst_ip4;
 __u32 dst_ip6[4];
 __u32 state;
 __s32 rx_queue_mapping;
};

struct bpf_tcp_sock {
 __u32 snd_cwnd;
 __u32 srtt_us;
 __u32 rtt_min;
 __u32 snd_ssthresh;
 __u32 rcv_nxt;
 __u32 snd_nxt;
 __u32 snd_una;
 __u32 mss_cache;
 __u32 ecn_flags;
 __u32 rate_delivered;
 __u32 rate_interval_us;
 __u32 packets_out;
 __u32 retrans_out;
 __u32 total_retrans;
 __u32 segs_in;


 __u32 data_segs_in;


 __u32 segs_out;


 __u32 data_segs_out;


 __u32 lost_out;
 __u32 sacked_out;
 __u64 bytes_received;



 __u64 bytes_acked;



 __u32 dsack_dups;


 __u32 delivered;
 __u32 delivered_ce;
 __u32 icsk_retransmits;
};

struct bpf_sock_tuple {
 union {
  struct {
   __be32 saddr;
   __be32 daddr;
   __be16 sport;
   __be16 dport;
  } ipv4;
  struct {
   __be32 saddr[4];
   __be32 daddr[4];
   __be16 sport;
   __be16 dport;
  } ipv6;
 };
};

struct bpf_xdp_sock {
 __u32 queue_id;
};
# 4363 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum xdp_action {
 XDP_ABORTED = 0,
 XDP_DROP,
 XDP_PASS,
 XDP_TX,
 XDP_REDIRECT,
};




struct xdp_md {
 __u32 data;
 __u32 data_end;
 __u32 data_meta;

 __u32 ingress_ifindex;
 __u32 rx_queue_index;

 __u32 egress_ifindex;
};






struct bpf_devmap_val {
 __u32 ifindex;
 union {
  int fd;
  __u32 id;
 } bpf_prog;
};






struct bpf_cpumap_val {
 __u32 qsize;
 union {
  int fd;
  __u32 id;
 } bpf_prog;
};

enum sk_action {
 SK_DROP = 0,
 SK_PASS,
};




struct sk_msg_md {
 union { void * data; __u64 :64; } __attribute__((aligned(8)));
 union { void * data_end; __u64 :64; } __attribute__((aligned(8)));

 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;
 __u32 size;

 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
};

struct sk_reuseport_md {




 union { void * data; __u64 :64; } __attribute__((aligned(8)));

 union { void * data_end; __u64 :64; } __attribute__((aligned(8)));






 __u32 len;




 __u32 eth_protocol;
 __u32 ip_protocol;
 __u32 bind_inany;
 __u32 hash;
};



struct bpf_prog_info {
 __u32 type;
 __u32 id;
 __u8 tag[8];
 __u32 jited_prog_len;
 __u32 xlated_prog_len;
 __aligned_u64 jited_prog_insns;
 __aligned_u64 xlated_prog_insns;
 __u64 load_time;
 __u32 created_by_uid;
 __u32 nr_map_ids;
 __aligned_u64 map_ids;
 char name[16U];
 __u32 ifindex;
 __u32 gpl_compatible:1;
 __u32 :31;
 __u64 netns_dev;
 __u64 netns_ino;
 __u32 nr_jited_ksyms;
 __u32 nr_jited_func_lens;
 __aligned_u64 jited_ksyms;
 __aligned_u64 jited_func_lens;
 __u32 btf_id;
 __u32 func_info_rec_size;
 __aligned_u64 func_info;
 __u32 nr_func_info;
 __u32 nr_line_info;
 __aligned_u64 line_info;
 __aligned_u64 jited_line_info;
 __u32 nr_jited_line_info;
 __u32 line_info_rec_size;
 __u32 jited_line_info_rec_size;
 __u32 nr_prog_tags;
 __aligned_u64 prog_tags;
 __u64 run_time_ns;
 __u64 run_cnt;
} __attribute__((aligned(8)));

struct bpf_map_info {
 __u32 type;
 __u32 id;
 __u32 key_size;
 __u32 value_size;
 __u32 max_entries;
 __u32 map_flags;
 char name[16U];
 __u32 ifindex;
 __u32 btf_vmlinux_value_type_id;
 __u64 netns_dev;
 __u64 netns_ino;
 __u32 btf_id;
 __u32 btf_key_type_id;
 __u32 btf_value_type_id;
} __attribute__((aligned(8)));

struct bpf_btf_info {
 __aligned_u64 btf;
 __u32 btf_size;
 __u32 id;
 __aligned_u64 name;
 __u32 name_len;
 __u32 kernel_btf;
} __attribute__((aligned(8)));

struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __aligned_u64 tp_name;
   __u32 tp_name_len;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __aligned_u64 target_name;
   __u32 target_name_len;
   union {
    struct {
     __u32 map_id;
    } map;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
 };
} __attribute__((aligned(8)));





struct bpf_sock_addr {
 __u32 user_family;
 __u32 user_ip4;


 __u32 user_ip6[4];


 __u32 user_port;


 __u32 family;
 __u32 type;
 __u32 protocol;
 __u32 msg_src_ip4;


 __u32 msg_src_ip6[4];


 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
};







struct bpf_sock_ops {
 __u32 op;
 union {
  __u32 args[4];
  __u32 reply;
  __u32 replylong[4];
 };
 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;
 __u32 is_fullsock;



 __u32 snd_cwnd;
 __u32 srtt_us;
 __u32 bpf_sock_ops_cb_flags;
 __u32 state;
 __u32 rtt_min;
 __u32 snd_ssthresh;
 __u32 rcv_nxt;
 __u32 snd_nxt;
 __u32 snd_una;
 __u32 mss_cache;
 __u32 ecn_flags;
 __u32 rate_delivered;
 __u32 rate_interval_us;
 __u32 packets_out;
 __u32 retrans_out;
 __u32 total_retrans;
 __u32 segs_in;
 __u32 data_segs_in;
 __u32 segs_out;
 __u32 data_segs_out;
 __u32 lost_out;
 __u32 sacked_out;
 __u32 sk_txhash;
 __u64 bytes_received;
 __u64 bytes_acked;
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
# 4652 "/var/lib/cilium/bpf/include/linux/bpf.h"
 union { void * skb_data; __u64 :64; } __attribute__((aligned(8)));
 union { void * skb_data_end; __u64 :64; } __attribute__((aligned(8)));
 __u32 skb_len;



 __u32 skb_tcp_flags;
# 4668 "/var/lib/cilium/bpf/include/linux/bpf.h"
};


enum {
 BPF_SOCK_OPS_RTO_CB_FLAG = (1<<0),
 BPF_SOCK_OPS_RETRANS_CB_FLAG = (1<<1),
 BPF_SOCK_OPS_STATE_CB_FLAG = (1<<2),
 BPF_SOCK_OPS_RTT_CB_FLAG = (1<<3),
# 4694 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_SOCK_OPS_PARSE_ALL_HDR_OPT_CB_FLAG = (1<<4),
# 4703 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_SOCK_OPS_PARSE_UNKNOWN_HDR_OPT_CB_FLAG = (1<<5),
# 4718 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_SOCK_OPS_WRITE_HDR_OPT_CB_FLAG = (1<<6),

 BPF_SOCK_OPS_ALL_CB_FLAGS = 0x7F,
};




enum {
 BPF_SOCK_OPS_VOID,
 BPF_SOCK_OPS_TIMEOUT_INIT,


 BPF_SOCK_OPS_RWND_INIT,



 BPF_SOCK_OPS_TCP_CONNECT_CB,


 BPF_SOCK_OPS_ACTIVE_ESTABLISHED_CB,



 BPF_SOCK_OPS_PASSIVE_ESTABLISHED_CB,



 BPF_SOCK_OPS_NEEDS_ECN,


 BPF_SOCK_OPS_BASE_RTT,






 BPF_SOCK_OPS_RTO_CB,




 BPF_SOCK_OPS_RETRANS_CB,





 BPF_SOCK_OPS_STATE_CB,



 BPF_SOCK_OPS_TCP_LISTEN_CB,


 BPF_SOCK_OPS_RTT_CB,

 BPF_SOCK_OPS_PARSE_HDR_OPT_CB,
# 4790 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_SOCK_OPS_HDR_OPT_LEN_CB,
# 4807 "/var/lib/cilium/bpf/include/linux/bpf.h"
 BPF_SOCK_OPS_WRITE_HDR_OPT_CB,
# 4833 "/var/lib/cilium/bpf/include/linux/bpf.h"
};






enum {
 BPF_TCP_ESTABLISHED = 1,
 BPF_TCP_SYN_SENT,
 BPF_TCP_SYN_RECV,
 BPF_TCP_FIN_WAIT1,
 BPF_TCP_FIN_WAIT2,
 BPF_TCP_TIME_WAIT,
 BPF_TCP_CLOSE,
 BPF_TCP_CLOSE_WAIT,
 BPF_TCP_LAST_ACK,
 BPF_TCP_LISTEN,
 BPF_TCP_CLOSING,
 BPF_TCP_NEW_SYN_RECV,

 BPF_TCP_MAX_STATES
};

enum {
 TCP_BPF_IW = 1001,
 TCP_BPF_SNDCWND_CLAMP = 1002,
 TCP_BPF_DELACK_MAX = 1003,
 TCP_BPF_RTO_MIN = 1004,
# 4894 "/var/lib/cilium/bpf/include/linux/bpf.h"
 TCP_BPF_SYN = 1005,
 TCP_BPF_SYN_IP = 1006,
 TCP_BPF_SYN_MAC = 1007,
};

enum {
 BPF_LOAD_HDR_OPT_TCP_SYN = (1ULL << 0),
};




enum {
 BPF_WRITE_HDR_TCP_CURRENT_MSS = 1,






 BPF_WRITE_HDR_TCP_SYNACK_COOKIE = 2,


};

struct bpf_perf_event_value {
 __u64 counter;
 __u64 enabled;
 __u64 running;
};

enum {
 BPF_DEVCG_ACC_MKNOD = (1ULL << 0),
 BPF_DEVCG_ACC_READ = (1ULL << 1),
 BPF_DEVCG_ACC_WRITE = (1ULL << 2),
};

enum {
 BPF_DEVCG_DEV_BLOCK = (1ULL << 0),
 BPF_DEVCG_DEV_CHAR = (1ULL << 1),
};

struct bpf_cgroup_dev_ctx {

 __u32 access_type;
 __u32 major;
 __u32 minor;
};

struct bpf_raw_tracepoint_args {
 __u64 args[0];
};




enum {
 BPF_FIB_LOOKUP_DIRECT = (1U << 0),
 BPF_FIB_LOOKUP_OUTPUT = (1U << 1),
};

enum {
 BPF_FIB_LKUP_RET_SUCCESS,
 BPF_FIB_LKUP_RET_BLACKHOLE,
 BPF_FIB_LKUP_RET_UNREACHABLE,
 BPF_FIB_LKUP_RET_PROHIBIT,
 BPF_FIB_LKUP_RET_NOT_FWDED,
 BPF_FIB_LKUP_RET_FWD_DISABLED,
 BPF_FIB_LKUP_RET_UNSUPP_LWT,
 BPF_FIB_LKUP_RET_NO_NEIGH,
 BPF_FIB_LKUP_RET_FRAG_NEEDED,
};

struct bpf_fib_lookup {



 __u8 family;


 __u8 l4_protocol;
 __be16 sport;
 __be16 dport;


 __u16 tot_len;




 __u32 ifindex;

 union {

  __u8 tos;
  __be32 flowinfo;


  __u32 rt_metric;
 };

 union {
  __be32 ipv4_src;
  __u32 ipv6_src[4];
 };





 union {
  __be32 ipv4_dst;
  __u32 ipv6_dst[4];
 };


 __be16 h_vlan_proto;
 __be16 h_vlan_TCI;
 __u8 smac[6];
 __u8 dmac[6];
};

struct bpf_redir_neigh {

 __u32 nh_family;

 union {
  __be32 ipv4_nh;
  __u32 ipv6_nh[4];
 };
};

enum bpf_task_fd_type {
 BPF_FD_TYPE_RAW_TRACEPOINT,
 BPF_FD_TYPE_TRACEPOINT,
 BPF_FD_TYPE_KPROBE,
 BPF_FD_TYPE_KRETPROBE,
 BPF_FD_TYPE_UPROBE,
 BPF_FD_TYPE_URETPROBE,
};

enum {
 BPF_FLOW_DISSECTOR_F_PARSE_1ST_FRAG = (1U << 0),
 BPF_FLOW_DISSECTOR_F_STOP_AT_FLOW_LABEL = (1U << 1),
 BPF_FLOW_DISSECTOR_F_STOP_AT_ENCAP = (1U << 2),
};

struct bpf_flow_keys {
 __u16 nhoff;
 __u16 thoff;
 __u16 addr_proto;
 __u8 is_frag;
 __u8 is_first_frag;
 __u8 is_encap;
 __u8 ip_proto;
 __be16 n_proto;
 __be16 sport;
 __be16 dport;
 union {
  struct {
   __be32 ipv4_src;
   __be32 ipv4_dst;
  };
  struct {
   __u32 ipv6_src[4];
   __u32 ipv6_dst[4];
  };
 };
 __u32 flags;
 __be32 flow_label;
};

struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};




struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};

struct bpf_spin_lock {
 __u32 val;
};

struct bpf_sysctl {
 __u32 write;


 __u32 file_pos;


};

struct bpf_sockopt {
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
 union { void * optval; __u64 :64; } __attribute__((aligned(8)));
 union { void * optval_end; __u64 :64; } __attribute__((aligned(8)));

 __s32 level;
 __s32 optname;
 __s32 optlen;
 __s32 retval;
};

struct bpf_pidns_info {
 __u32 pid;
 __u32 tgid;
};


struct bpf_sk_lookup {
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));

 __u32 family;
 __u32 protocol;
 __u32 remote_ip4;
 __u32 remote_ip6[4];
 __u32 remote_port;
 __u32 local_ip4;
 __u32 local_ip6[4];
 __u32 local_port;
};
# 5132 "/var/lib/cilium/bpf/include/linux/bpf.h"
struct btf_ptr {
 void *ptr;
 __u32 type_id;
 __u32 flags;
};
# 5147 "/var/lib/cilium/bpf/include/linux/bpf.h"
enum {
 BTF_F_COMPACT = (1ULL << 0),
 BTF_F_NONAME = (1ULL << 1),
 BTF_F_PTR_RAW = (1ULL << 2),
 BTF_F_ZERO = (1ULL << 3),
};
# 9 "/var/lib/cilium/bpf/include/bpf/ctx/common.h" 2

# 1 "/var/lib/cilium/bpf/include/bpf/ctx/../compiler.h" 1







# 1 "/var/lib/cilium/bpf/include/linux/../bpf/stddef.h" 1
# 11 "/var/lib/cilium/bpf/include/linux/../bpf/stddef.h"
enum {
 false = 0,
 true = 1,
};
# 9 "/var/lib/cilium/bpf/include/bpf/ctx/../compiler.h" 2
# 86 "/var/lib/cilium/bpf/include/bpf/ctx/../compiler.h"
static inline __attribute__((always_inline)) void bpf_barrier(void)
{




 asm volatile("": : :"memory");
}
# 11 "/var/lib/cilium/bpf/include/bpf/ctx/common.h" 2
# 1 "/var/lib/cilium/bpf/include/bpf/ctx/../errno.h" 1
# 12 "/var/lib/cilium/bpf/include/bpf/ctx/common.h" 2




static inline __attribute__((always_inline)) void *ctx_data(const struct __sk_buff *ctx)
{
 return (void *)(unsigned long)ctx->data;
}

static inline __attribute__((always_inline)) void *ctx_data_meta(const struct __sk_buff *ctx)
{
 return (void *)(unsigned long)ctx->data_meta;
}

static inline __attribute__((always_inline)) void *ctx_data_end(const struct __sk_buff *ctx)
{
 return (void *)(unsigned long)ctx->data_end;
}

static inline __attribute__((always_inline)) _Bool ctx_no_room(const void *needed, const void *limit)
{
 return __builtin_expect(!!(needed > limit), 0);
}
# 11 "/var/lib/cilium/bpf/include/bpf/ctx/skb.h" 2
# 1 "/var/lib/cilium/bpf/include/bpf/ctx/../helpers_skb.h" 1
# 10 "/var/lib/cilium/bpf/include/bpf/ctx/../helpers_skb.h"
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/helpers.h" 1








# 1 "/var/lib/cilium/bpf/include/linux/../bpf/ctx/ctx.h" 1
# 10 "/var/lib/cilium/bpf/include/linux/../bpf/helpers.h" 2
# 28 "/var/lib/cilium/bpf/include/linux/../bpf/helpers.h"
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/helpers_skb.h" 1
# 29 "/var/lib/cilium/bpf/include/linux/../bpf/helpers.h" 2





static void *(* map_lookup_elem)(const void *map, const void *key) __attribute__((__unused__)) = (void *)BPF_FUNC_map_lookup_elem;
static int (* map_update_elem)(const void *map, const void *key, const void *value, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_map_update_elem;

static int (* map_delete_elem)(const void *map, const void *key) __attribute__((__unused__)) = (void *)BPF_FUNC_map_delete_elem;


static __u64 (* ktime_get_ns)() __attribute__((__unused__)) = (void *)BPF_FUNC_ktime_get_ns;
static __u64 (* ktime_get_boot_ns)() __attribute__((__unused__)) = (void *)BPF_FUNC_ktime_get_boot_ns;
static __u64 (* jiffies64)() __attribute__((__unused__)) = (void *)BPF_FUNC_jiffies64;



static __sock_cookie (* get_socket_cookie)(void *ctx) __attribute__((__unused__)) = (void *)BPF_FUNC_get_socket_cookie;
static __net_cookie (* get_netns_cookie)(void *ctx) __attribute__((__unused__)) = (void *)BPF_FUNC_get_netns_cookie;


static __attribute__((__format__(printf, 1, 3))) void
(* trace_printk)(const char *fmt, int fmt_size, ...) __attribute__((__unused__)) = (void *)BPF_FUNC_trace_printk;


static __u32 (* get_prandom_u32)() __attribute__((__unused__)) = (void *)BPF_FUNC_get_prandom_u32;


static int (* csum_diff_external)(const void *from, __u32 size_from, const void *to, __u32 size_to, __u32 seed) __attribute__((__unused__)) =

 (void *)BPF_FUNC_csum_diff;


static void (* tail_call)(void *ctx, const void *map, __u32 index) __attribute__((__unused__)) = (void *)BPF_FUNC_tail_call;


static __u32 (* get_smp_processor_id)() __attribute__((__unused__)) = (void *)BPF_FUNC_get_smp_processor_id;





struct bpf_fib_lookup_padded {
 struct bpf_fib_lookup l;
 __u8 pad[2];
};


static int (* fib_lookup)(void *ctx, struct bpf_fib_lookup *params, __u32 plen, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_fib_lookup;



static int (* sock_map_update)(struct bpf_sock_ops *skops, void *map, __u32 key, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_sock_map_update;

static int (* sock_hash_update)(struct bpf_sock_ops *skops, void *map, void *key, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_sock_hash_update;

static int (* msg_redirect_hash)(struct sk_msg_md *md, void *map, void *key, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_msg_redirect_hash;



static struct bpf_sock *(* sk_lookup_tcp)(void *ctx, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_sk_lookup_tcp;


static struct bpf_sock *(* sk_lookup_udp)(void *ctx, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_sk_lookup_udp;







static int (* get_socket_opt)(void *ctx, int level, int optname, void *optval, int optlen) __attribute__((__unused__)) =

 (void *)BPF_FUNC_getsockopt;
# 11 "/var/lib/cilium/bpf/include/linux/../bpf/helpers_skb.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/features_skb.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/../bpf/features.h" 1






# 1 "/var/run/cilium/state/globals/bpf_features.h" 1
# 8 "/var/lib/cilium/bpf/include/linux/../bpf/features.h" 2
# 8 "/var/lib/cilium/bpf/include/linux/../bpf/features_skb.h" 2
# 12 "/var/lib/cilium/bpf/include/linux/../bpf/helpers_skb.h" 2




static int (* redirect)(int ifindex, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_redirect;
static int (* redirect_neigh)(int ifindex, struct bpf_redir_neigh *params, int plen, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_redirect_neigh;

static int (* redirect_peer)(int ifindex, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_redirect_peer;


static int (* skb_load_bytes)(struct __sk_buff *skb, __u32 off, void *to, __u32 len) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_load_bytes;

static int (* skb_store_bytes)(struct __sk_buff *skb, __u32 off, const void *from, __u32 len, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_store_bytes;


static int (* l3_csum_replace)(struct __sk_buff *skb, __u32 off, __u32 from, __u32 to, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_l3_csum_replace;

static int (* l4_csum_replace)(struct __sk_buff *skb, __u32 off, __u32 from, __u32 to, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_l4_csum_replace;


static int (* skb_adjust_room)(struct __sk_buff *skb, __s32 len_diff, __u32 mode, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_adjust_room;


static int (* skb_change_type)(struct __sk_buff *skb, __u32 type) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_change_type;
static int (* skb_change_proto)(struct __sk_buff *skb, __u32 proto, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_change_proto;

static int (* skb_change_tail)(struct __sk_buff *skb, __u32 nlen, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_change_tail;

static int (* skb_change_head)(struct __sk_buff *skb, __u32 head_room, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_change_head;


static int (* skb_pull_data)(struct __sk_buff *skb, __u32 len) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_pull_data;


static int (* skb_get_tunnel_key)(struct __sk_buff *skb, struct bpf_tunnel_key *to, __u32 size, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_get_tunnel_key;

static int (* skb_set_tunnel_key)(struct __sk_buff *skb, const struct bpf_tunnel_key *from, __u32 size, __u32 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skb_set_tunnel_key;




static int (* skb_event_output)(struct __sk_buff *skb, void *map, __u64 index, const void *data, __u32 size) __attribute__((__unused__)) =

    (void *)BPF_FUNC_perf_event_output;


static struct bpf_sock *(* skc_lookup_tcp)(struct __sk_buff *skb, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_skc_lookup_tcp;


static int (* sk_release)(struct bpf_sock *sk) __attribute__((__unused__)) = (void *)BPF_FUNC_sk_release;
static int (* sk_assign)(struct __sk_buff *skb, struct bpf_sock *sk, __u64 flags) __attribute__((__unused__)) = (void *)BPF_FUNC_sk_assign;
# 12 "/var/lib/cilium/bpf/include/bpf/ctx/skb.h" 2
# 59 "/var/lib/cilium/bpf/include/bpf/ctx/skb.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) int
ctx_redirect(struct __sk_buff *ctx __attribute__((__unused__)), int ifindex, __u32 flags)
{
 return redirect(ifindex, flags);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int
ctx_adjust_troom(struct __sk_buff *ctx, const __s32 len_diff)
{
 return skb_change_tail(ctx, ctx->len + len_diff, 0);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u64
ctx_full_len(const struct __sk_buff *ctx)
{
 return ctx->len;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u32
ctx_wire_len(const struct __sk_buff *ctx)
{
 return ctx->wire_len;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ctx_store_meta(struct __sk_buff *ctx, const __u32 off, __u32 data)
{
 ctx->cb[off] = data;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u32
ctx_load_meta(const struct __sk_buff *ctx, const __u32 off)
{
 return ctx->cb[off];
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u32
ctx_get_protocol(const struct __sk_buff *ctx)
{
 return ctx->protocol;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u32
ctx_get_ifindex(const struct __sk_buff *ctx)
{
 return ctx->ifindex;
}
# 5 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/include/bpf/api.h" 1







# 1 "/var/lib/cilium/bpf/include/linux/byteorder.h" 1




# 1 "/var/lib/cilium/bpf/include/linux/byteorder/little_endian.h" 1
# 12 "/var/lib/cilium/bpf/include/linux/byteorder/little_endian.h"
# 1 "/var/lib/cilium/bpf/include/linux/swab.h" 1
# 44 "/var/lib/cilium/bpf/include/linux/swab.h"
static __inline__ __u16 __fswab16(__u16 val)
{





 return ((__u16)( (((__u16)(val) & (__u16)0x00ffU) << 8) | (((__u16)(val) & (__u16)0xff00U) >> 8)));

}

static __inline__ __u32 __fswab32(__u32 val)
{





 return ((__u32)( (((__u32)(val) & (__u32)0x000000ffUL) << 24) | (((__u32)(val) & (__u32)0x0000ff00UL) << 8) | (((__u32)(val) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(val) & (__u32)0xff000000UL) >> 24)));

}

static __inline__ __u64 __fswab64(__u64 val)
{
# 77 "/var/lib/cilium/bpf/include/linux/swab.h"
 return ((__u64)( (((__u64)(val) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(val) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(val) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(val) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(val) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(val) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(val) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(val) & (__u64)0xff00000000000000ULL) >> 56)));

}

static __inline__ __u32 __fswahw32(__u32 val)
{



 return ((__u32)( (((__u32)(val) & (__u32)0x0000ffffUL) << 16) | (((__u32)(val) & (__u32)0xffff0000UL) >> 16)));

}

static __inline__ __u32 __fswahb32(__u32 val)
{



 return ((__u32)( (((__u32)(val) & (__u32)0x00ff00ffUL) << 8) | (((__u32)(val) & (__u32)0xff00ff00UL) >> 8)));

}
# 152 "/var/lib/cilium/bpf/include/linux/swab.h"
static __inline__ __u16 __swab16p(const __u16 *p)
{



 return (__builtin_constant_p((__u16)(*p)) ? ((__u16)( (((__u16)(*p) & (__u16)0x00ffU) << 8) | (((__u16)(*p) & (__u16)0xff00U) >> 8))) : __fswab16(*p));

}





static __inline__ __u32 __swab32p(const __u32 *p)
{



 return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x000000ffUL) << 24) | (((__u32)(*p) & (__u32)0x0000ff00UL) << 8) | (((__u32)(*p) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(*p) & (__u32)0xff000000UL) >> 24))) : __fswab32(*p));

}





static __inline__ __u64 __swab64p(const __u64 *p)
{



 return (__builtin_constant_p((__u64)(*p)) ? ((__u64)( (((__u64)(*p) & (__u64)0x00000000000000ffULL) << 56) | (((__u64)(*p) & (__u64)0x000000000000ff00ULL) << 40) | (((__u64)(*p) & (__u64)0x0000000000ff0000ULL) << 24) | (((__u64)(*p) & (__u64)0x00000000ff000000ULL) << 8) | (((__u64)(*p) & (__u64)0x000000ff00000000ULL) >> 8) | (((__u64)(*p) & (__u64)0x0000ff0000000000ULL) >> 24) | (((__u64)(*p) & (__u64)0x00ff000000000000ULL) >> 40) | (((__u64)(*p) & (__u64)0xff00000000000000ULL) >> 56))) : __fswab64(*p));

}







static __inline__ __u32 __swahw32p(const __u32 *p)
{



 return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x0000ffffUL) << 16) | (((__u32)(*p) & (__u32)0xffff0000UL) >> 16))) : __fswahw32(*p));

}







static __inline__ __u32 __swahb32p(const __u32 *p)
{



 return (__builtin_constant_p((__u32)(*p)) ? ((__u32)( (((__u32)(*p) & (__u32)0x00ff00ffUL) << 8) | (((__u32)(*p) & (__u32)0xff00ff00UL) >> 8))) : __fswahb32(*p));

}





static __inline__ void __swab16s(__u16 *p)
{



 *p = __swab16p(p);

}




static __inline__ void __swab32s(__u32 *p)
{



 *p = __swab32p(p);

}





static __inline__ void __swab64s(__u64 *p)
{



 *p = __swab64p(p);

}







static __inline__ void __swahw32s(__u32 *p)
{



 *p = __swahw32p(p);

}







static __inline__ void __swahb32s(__u32 *p)
{



 *p = __swahb32p(p);

}
# 13 "/var/lib/cilium/bpf/include/linux/byteorder/little_endian.h" 2
# 43 "/var/lib/cilium/bpf/include/linux/byteorder/little_endian.h"
static __inline__ __le64 __cpu_to_le64p(const __u64 *p)
{
 return (__le64)*p;
}
static __inline__ __u64 __le64_to_cpup(const __le64 *p)
{
 return (__u64)*p;
}
static __inline__ __le32 __cpu_to_le32p(const __u32 *p)
{
 return (__le32)*p;
}
static __inline__ __u32 __le32_to_cpup(const __le32 *p)
{
 return (__u32)*p;
}
static __inline__ __le16 __cpu_to_le16p(const __u16 *p)
{
 return (__le16)*p;
}
static __inline__ __u16 __le16_to_cpup(const __le16 *p)
{
 return (__u16)*p;
}
static __inline__ __be64 __cpu_to_be64p(const __u64 *p)
{
 return (__be64)__swab64p(p);
}
static __inline__ __u64 __be64_to_cpup(const __be64 *p)
{
 return __swab64p((__u64 *)p);
}
static __inline__ __be32 __cpu_to_be32p(const __u32 *p)
{
 return (__be32)__swab32p(p);
}
static __inline__ __u32 __be32_to_cpup(const __be32 *p)
{
 return __swab32p((__u32 *)p);
}
static __inline__ __be16 __cpu_to_be16p(const __u16 *p)
{
 return (__be16)__swab16p(p);
}
static __inline__ __u16 __be16_to_cpup(const __be16 *p)
{
 return __swab16p((__u16 *)p);
}
# 6 "/var/lib/cilium/bpf/include/linux/byteorder.h" 2
# 9 "/var/lib/cilium/bpf/include/bpf/api.h" 2

# 1 "/var/lib/cilium/bpf/include/linux/if_packet.h" 1
# 11 "/var/lib/cilium/bpf/include/bpf/api.h" 2


# 1 "/var/lib/cilium/bpf/include/linux/../bpf/section.h" 1
# 14 "/var/lib/cilium/bpf/include/bpf/api.h" 2

# 1 "/var/lib/cilium/bpf/include/linux/../bpf/builtins.h" 1
# 38 "/var/lib/cilium/bpf/include/linux/../bpf/builtins.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_memset_builtin(void *d, __u8 c, __u64 len)
{



 __builtin_memset(d, c, len);
}

static inline __attribute__((always_inline)) void __bpf_memzero(void *d, __u64 len)
{

 if (!__builtin_constant_p(len))
  __builtin_trap();

 d += len;

 switch (len) {
 case 96: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 88: jmp_88: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 80: jmp_80: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 72: jmp_72: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 64: jmp_64: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 56: jmp_56: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 48: jmp_48: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 40: jmp_40: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 32: jmp_32: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 24: jmp_24: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 16: jmp_16: (*(__u64 *)(d -= sizeof(__u64))) = 0;
 case 8: jmp_8: (*(__u64 *)(d -= sizeof(__u64))) = 0;
  break;

 case 94: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_88;
 case 86: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_80;
 case 78: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_72;
 case 70: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_64;
 case 62: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_56;
 case 54: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_48;
 case 46: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_40;
 case 38: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_32;
 case 30: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_24;
 case 22: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_16;
 case 14: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_8;
 case 6: (*(__u16 *)(d -= sizeof(__u16))) = 0; (*(__u32 *)(d -= sizeof(__u32))) = 0;
  break;

 case 92: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_88;
 case 84: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_80;
 case 76: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_72;
 case 68: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_64;
 case 60: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_56;
 case 52: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_48;
 case 44: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_40;
 case 36: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_32;
 case 28: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_24;
 case 20: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_16;
 case 12: (*(__u32 *)(d -= sizeof(__u32))) = 0; goto jmp_8;
 case 4: (*(__u32 *)(d -= sizeof(__u32))) = 0;
  break;

 case 90: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_88;
 case 82: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_80;
 case 74: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_72;
 case 66: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_64;
 case 58: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_56;
 case 50: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_48;
 case 42: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_40;
 case 34: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_32;
 case 26: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_24;
 case 18: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_16;
 case 10: (*(__u16 *)(d -= sizeof(__u16))) = 0; goto jmp_8;
 case 2: (*(__u16 *)(d -= sizeof(__u16))) = 0;
  break;

 case 1: (*(__u8 *)(d -= sizeof(__u8))) = 0;
  break;

 default:





  __builtin_trap();
 }



}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_no_builtin_memset(void *d __attribute__((__unused__)), __u8 c __attribute__((__unused__)),
   __u64 len __attribute__((__unused__)))
{
 __builtin_trap();
}




static inline __attribute__((always_inline)) __attribute__((no_builtin("memset"))) void memset(void *d, int c,
        __u64 len)
{
 if (__builtin_constant_p(len) && __builtin_constant_p(c) && c == 0)
  __bpf_memzero(d, len);
 else
  __bpf_memset_builtin(d, c, len);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_memcpy_builtin(void *d, const void *s, __u64 len)
{

 __builtin_memcpy(d, s, len);
}

static inline __attribute__((always_inline)) void __bpf_memcpy(void *d, const void *s, __u64 len)
{

 if (!__builtin_constant_p(len))
  __builtin_trap();

 d += len;
 s += len;

 switch (len) {
 case 96: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 88: jmp_88: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 80: jmp_80: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 72: jmp_72: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 64: jmp_64: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 56: jmp_56: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 48: jmp_48: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 40: jmp_40: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 32: jmp_32: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 24: jmp_24: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 16: jmp_16: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
 case 8: jmp_8: (*(__u64 *)(d -= sizeof(__u64))) = (*(__u64 *)(s -= sizeof(__u64)));
  break;

 case 94: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_88;
 case 86: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_80;
 case 78: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_72;
 case 70: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_64;
 case 62: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_56;
 case 54: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_48;
 case 46: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_40;
 case 38: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_32;
 case 30: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_24;
 case 22: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_16;
 case 14: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_8;
 case 6: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32)));
  break;

 case 92: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_88;
 case 84: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_80;
 case 76: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_72;
 case 68: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_64;
 case 60: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_56;
 case 52: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_48;
 case 44: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_40;
 case 36: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_32;
 case 28: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_24;
 case 20: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_16;
 case 12: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32))); goto jmp_8;
 case 4: (*(__u32 *)(d -= sizeof(__u32))) = (*(__u32 *)(s -= sizeof(__u32)));
  break;

 case 90: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_88;
 case 82: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_80;
 case 74: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_72;
 case 66: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_64;
 case 58: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_56;
 case 50: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_48;
 case 42: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_40;
 case 34: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_32;
 case 26: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_24;
 case 18: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_16;
 case 10: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16))); goto jmp_8;
 case 2: (*(__u16 *)(d -= sizeof(__u16))) = (*(__u16 *)(s -= sizeof(__u16)));
  break;

 case 1: (*(__u8 *)(d -= sizeof(__u8))) = (*(__u8 *)(s -= sizeof(__u8)));
  break;

 default:





  __builtin_trap();
 }



}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_no_builtin_memcpy(void *d __attribute__((__unused__)), const void *s __attribute__((__unused__)),
   __u64 len __attribute__((__unused__)))
{
 __builtin_trap();
}




static inline __attribute__((always_inline)) __attribute__((no_builtin("memcpy"))) void memcpy(void *d, const void *s,
        __u64 len)
{
 return __bpf_memcpy(d, s, len);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u64
__bpf_memcmp_builtin(const void *x, const void *y, __u64 len)
{
# 264 "/var/lib/cilium/bpf/include/linux/../bpf/builtins.h"
 return __builtin_bcmp(x, y, len);
}

static inline __attribute__((always_inline)) __u64 __bpf_memcmp(const void *x, const void *y,
       __u64 len)
{

 __u64 r = 0;

 if (!__builtin_constant_p(len))
  __builtin_trap();

 x += len;
 y += len;

 switch (len) {
 case 32: r |= (*(__u64 *)(x -= sizeof(__u64))) ^ (*(__u64 *)(y -= sizeof(__u64)));
 case 24: jmp_24: r |= (*(__u64 *)(x -= sizeof(__u64))) ^ (*(__u64 *)(y -= sizeof(__u64)));
 case 16: jmp_16: r |= (*(__u64 *)(x -= sizeof(__u64))) ^ (*(__u64 *)(y -= sizeof(__u64)));
 case 8: jmp_8: r |= (*(__u64 *)(x -= sizeof(__u64))) ^ (*(__u64 *)(y -= sizeof(__u64)));
  break;

 case 30: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_24;
 case 22: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_16;
 case 14: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_8;
 case 6: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32)));
  break;

 case 28: r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_24;
 case 20: r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_16;
 case 12: r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32))); goto jmp_8;
 case 4: r |= (*(__u32 *)(x -= sizeof(__u32))) ^ (*(__u32 *)(y -= sizeof(__u32)));
  break;

 case 26: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); goto jmp_24;
 case 18: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); goto jmp_16;
 case 10: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16))); goto jmp_8;
 case 2: r |= (*(__u16 *)(x -= sizeof(__u16))) ^ (*(__u16 *)(y -= sizeof(__u16)));
  break;

 case 1: r |= (*(__u8 *)(x -= sizeof(__u8))) ^ (*(__u8 *)(y -= sizeof(__u8)));
  break;

 default:
  __builtin_trap();
 }

 return r;



}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __u64
__bpf_no_builtin_memcmp(const void *x __attribute__((__unused__)),
   const void *y __attribute__((__unused__)), __u64 len __attribute__((__unused__)))
{
 __builtin_trap();
 return 0;
}







static inline __attribute__((always_inline)) __attribute__((no_builtin("memcmp"))) __u64 memcmp(const void *x,
         const void *y,
         __u64 len)
{
 return __bpf_memcmp(x, y, len);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_memmove_builtin(void *d, const void *s, __u64 len)
{

 __builtin_memmove(d, s, len);
}

static inline __attribute__((always_inline)) void __bpf_memmove_bwd(void *d, const void *s, __u64 len)
{

 __bpf_memcpy(d, s, len);
}

static inline __attribute__((always_inline)) void __bpf_memmove_fwd(void *d, const void *s, __u64 len)
{

 if (!__builtin_constant_p(len))
  __builtin_trap();

 switch (len) {
 case 96: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 88: jmp_88: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 80: jmp_80: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 72: jmp_72: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 64: jmp_64: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 56: jmp_56: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 48: jmp_48: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 40: jmp_40: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 32: jmp_32: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 24: jmp_24: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 16: jmp_16: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
 case 8: jmp_8: do { *(__u64 *)d = *(__u64 *)s; (d += sizeof(__u64)); (s += sizeof(__u64)); } while (0);
  break;

 case 94: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_88;
 case 86: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_80;
 case 78: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_72;
 case 70: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_64;
 case 62: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_56;
 case 54: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_48;
 case 46: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_40;
 case 38: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_32;
 case 30: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_24;
 case 22: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_16;
 case 14: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_8;
 case 6: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0);
  break;

 case 92: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_88;
 case 84: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_80;
 case 76: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_72;
 case 68: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_64;
 case 60: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_56;
 case 52: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_48;
 case 44: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_40;
 case 36: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_32;
 case 28: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_24;
 case 20: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_16;
 case 12: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0); goto jmp_8;
 case 4: do { *(__u32 *)d = *(__u32 *)s; (d += sizeof(__u32)); (s += sizeof(__u32)); } while (0);
  break;

 case 90: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_88;
 case 82: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_80;
 case 74: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_72;
 case 66: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_64;
 case 58: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_56;
 case 50: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_48;
 case 42: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_40;
 case 34: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_32;
 case 26: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_24;
 case 18: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_16;
 case 10: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0); goto jmp_8;
 case 2: do { *(__u16 *)d = *(__u16 *)s; (d += sizeof(__u16)); (s += sizeof(__u16)); } while (0);
  break;

 case 1: do { *(__u8 *)d = *(__u8 *)s; (d += sizeof(__u8)); (s += sizeof(__u8)); } while (0);
  break;

 default:





  __builtin_trap();
 }



}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__bpf_no_builtin_memmove(void *d __attribute__((__unused__)), const void *s __attribute__((__unused__)),
    __u64 len __attribute__((__unused__)))
{
 __builtin_trap();
}




static inline __attribute__((always_inline)) void __bpf_memmove(void *d, const void *s, __u64 len)
{
# 451 "/var/lib/cilium/bpf/include/linux/../bpf/builtins.h"
 if (d <= s)
  return __bpf_memmove_fwd(d, s, len);
 else
  return __bpf_memmove_bwd(d, s, len);
}

static inline __attribute__((always_inline)) __attribute__((no_builtin("memmove"))) void memmove(void *d,
          const void *s,
          __u64 len)
{
 return __bpf_memmove(d, s, len);
}
# 16 "/var/lib/cilium/bpf/include/bpf/api.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/tailcall.h" 1
# 10 "/var/lib/cilium/bpf/include/linux/../bpf/tailcall.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) void
tail_call_static(const struct __sk_buff *ctx, const void *map,
   const __u32 slot)
{
 if (!__builtin_constant_p(slot))
  __builtin_trap();
# 27 "/var/lib/cilium/bpf/include/linux/../bpf/tailcall.h"
 asm volatile("r1 = %[ctx]\n\t"
       "r2 = %[map]\n\t"
       "r3 = %[slot]\n\t"
       "call 12\n\t"
       :: [ctx]"r"(ctx), [map]"r"(map), [slot]"i"(slot)
       : "r0", "r1", "r2", "r3", "r4", "r5");
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
tail_call_dynamic(struct __sk_buff *ctx, const void *map, __u32 slot)
{
 if (__builtin_constant_p(slot))
  __builtin_trap();





 tail_call(ctx, map, slot);
}
# 17 "/var/lib/cilium/bpf/include/bpf/api.h" 2

# 1 "/var/lib/cilium/bpf/include/linux/../bpf/loader.h" 1
# 13 "/var/lib/cilium/bpf/include/linux/../bpf/loader.h"
struct bpf_elf_map {
 __u32 type;
 __u32 size_key;
 __u32 size_value;
 __u32 max_elem;
 __u32 flags;
 __u32 id;
 __u32 pinning;
 __u32 inner_id;
 __u32 inner_idx;
};
# 19 "/var/lib/cilium/bpf/include/bpf/api.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/csum.h" 1
# 10 "/var/lib/cilium/bpf/include/linux/../bpf/csum.h"
static inline __attribute__((always_inline)) __sum16 csum_fold(__wsum csum)
{
 csum = (csum & 0xffff) + (csum >> 16);
 csum = (csum & 0xffff) + (csum >> 16);
 return (__sum16)~csum;
}

static inline __attribute__((always_inline)) __wsum csum_unfold(__sum16 csum)
{
 return (__wsum)csum;
}

static inline __attribute__((always_inline)) __wsum csum_add(__wsum csum, __wsum addend)
{
 csum += addend;
 return csum + (csum < addend);
}

static inline __attribute__((always_inline)) __wsum csum_diff(const void *from, __u32 size_from,
     const void *to, __u32 size_to,
     __u32 seed)
{
 if (__builtin_constant_p(size_from) &&
     __builtin_constant_p(size_to)) {



  if (size_from == 4 && size_to == 4 &&
      __builtin_constant_p(seed) && seed == 0)
   return csum_add(~(*(__u32 *)from), *(__u32 *)to);
  if (size_from == 4 && size_to == 4)
   return csum_add(seed,
     csum_add(~(*(__u32 *)from),
       *(__u32 *)to));
 }

 return csum_diff_external(from, size_from, to, size_to, seed);
}
# 20 "/var/lib/cilium/bpf/include/bpf/api.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/../bpf/access.h" 1
# 10 "/var/lib/cilium/bpf/include/linux/../bpf/access.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) __u16
map_array_get_16(const __u16 *array, __u32 index, const __u32 limit)
{
 __u16 datum = 0;

 if (__builtin_constant_p(index) ||
     !__builtin_constant_p(limit))
  __builtin_trap();






 asm volatile("%[index] <<= 1\n\t"
       "if %[index] > %[limit] goto +1\n\t"
       "%[array] += %[index]\n\t"
       "%[datum] = *(u16 *)(%[array] + 0)\n\t"
       : [datum]"=r"(datum)
       : [limit]"i"(limit), [array]"r"(array), [index]"r"(index)
       : );

 return datum;
}
# 21 "/var/lib/cilium/bpf/include/bpf/api.h" 2
# 6 "/var/lib/cilium/bpf/bpf_host.c" 2

# 1 "/var/run/cilium/state/globals/node_config.h" 1
# 1 "/var/lib/cilium/bpf/lib/utils.h" 1
# 10 "/var/lib/cilium/bpf/lib/utils.h"
# 1 "/var/lib/cilium/bpf/lib/endian.h" 1
# 11 "/var/lib/cilium/bpf/lib/utils.h" 2
# 1 "/var/lib/cilium/bpf/lib/time.h" 1
# 31 "/var/lib/cilium/bpf/lib/time.h"
struct bpf_elf_map __attribute__((section("maps"), used)) cilium_ktime_cache = {
 .type = BPF_MAP_TYPE_PERCPU_ARRAY,
 .size_key = sizeof(__u32),
 .size_value = sizeof(__u64),
 .pinning = 2,
 .max_elem = 1,
};
# 12 "/var/lib/cilium/bpf/lib/utils.h" 2
# 1 "/var/lib/cilium/bpf/lib/static_data.h" 1
# 13 "/var/lib/cilium/bpf/lib/utils.h" 2
# 2 "/var/run/cilium/state/globals/node_config.h" 2
# 8 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/run/cilium/state/templates/95957a392ab98a1ad4255abaf542b47a40c815566472333fb52cb5b620ca8917/ep_config.h" 1



volatile __u32 NATIVE_DEV_IFINDEX = 0x00000001;


volatile __u32 IPV4_MASQUERADE = 0x01010101;

volatile __u32 SECCTX_FROM_IPCACHE = 0x00000001;

volatile __u32 NODE_MAC_1 = (0x2) << 24 | (0x0) << 16 | (0x60) << 8 | (0xd); volatile __u32 NODE_MAC_2 = (0xf0) << 8 | (0xd);

volatile __u32 SECLABEL = 0x00000002;

volatile __u32 SECLABEL_NB = 0x02000000;

volatile __u32 POLICY_VERDICT_LOG_FILTER = 0x0000ffff;
# 9 "/var/lib/cilium/bpf/bpf_host.c" 2
# 40 "/var/lib/cilium/bpf/bpf_host.c"
# 1 "/var/lib/cilium/bpf/lib/common.h" 1
# 10 "/var/lib/cilium/bpf/lib/common.h"
# 1 "/var/lib/cilium/bpf/include/linux/if_ether.h" 1
# 143 "/var/lib/cilium/bpf/include/linux/if_ether.h"
struct ethhdr {
 unsigned char h_dest[6];
 unsigned char h_source[6];
 __be16 h_proto;
} __attribute__((packed));
# 11 "/var/lib/cilium/bpf/lib/common.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/ipv6.h" 1




# 1 "/var/lib/cilium/bpf/include/linux/in6.h" 1
# 30 "/var/lib/cilium/bpf/include/linux/in6.h"
struct in6_addr {
 union {
  __u8 u6_addr8[16];
  __be16 u6_addr16[8];
  __be32 u6_addr32[4];
 } in6_u;



};
# 6 "/var/lib/cilium/bpf/include/linux/ipv6.h" 2
# 24 "/var/lib/cilium/bpf/include/linux/ipv6.h"
struct ipv6_rt_hdr {
 __u8 nexthdr;
 __u8 hdrlen;
 __u8 type;
 __u8 segments_left;





};


struct ipv6_opt_hdr {
 __u8 nexthdr;
 __u8 hdrlen;



} __attribute__((packed));
# 55 "/var/lib/cilium/bpf/include/linux/ipv6.h"
struct rt0_hdr {
 struct ipv6_rt_hdr rt_hdr;
 __u32 reserved;
 struct in6_addr addr[0];


};





struct rt2_hdr {
 struct ipv6_rt_hdr rt_hdr;
 __u32 reserved;
 struct in6_addr addr;


};





struct ipv6_destopt_hao {
 __u8 type;
 __u8 length;
 struct in6_addr addr;
} __attribute__((packed));
# 92 "/var/lib/cilium/bpf/include/linux/ipv6.h"
struct ipv6hdr {

 __u8 priority:4,
    version:4;






 __u8 flow_lbl[3];

 __be16 payload_len;
 __u8 nexthdr;
 __u8 hop_limit;

 struct in6_addr saddr;
 struct in6_addr daddr;
};



enum {
 DEVCONF_FORWARDING = 0,
 DEVCONF_HOPLIMIT,
 DEVCONF_MTU6,
 DEVCONF_ACCEPT_RA,
 DEVCONF_ACCEPT_REDIRECTS,
 DEVCONF_AUTOCONF,
 DEVCONF_DAD_TRANSMITS,
 DEVCONF_RTR_SOLICITS,
 DEVCONF_RTR_SOLICIT_INTERVAL,
 DEVCONF_RTR_SOLICIT_DELAY,
 DEVCONF_USE_TEMPADDR,
 DEVCONF_TEMP_VALID_LFT,
 DEVCONF_TEMP_PREFERED_LFT,
 DEVCONF_REGEN_MAX_RETRY,
 DEVCONF_MAX_DESYNC_FACTOR,
 DEVCONF_MAX_ADDRESSES,
 DEVCONF_FORCE_MLD_VERSION,
 DEVCONF_ACCEPT_RA_DEFRTR,
 DEVCONF_ACCEPT_RA_PINFO,
 DEVCONF_ACCEPT_RA_RTR_PREF,
 DEVCONF_RTR_PROBE_INTERVAL,
 DEVCONF_ACCEPT_RA_RT_INFO_MAX_PLEN,
 DEVCONF_PROXY_NDP,
 DEVCONF_OPTIMISTIC_DAD,
 DEVCONF_ACCEPT_SOURCE_ROUTE,
 DEVCONF_MC_FORWARDING,
 DEVCONF_DISABLE_IPV6,
 DEVCONF_ACCEPT_DAD,
 DEVCONF_FORCE_TLLAO,
 DEVCONF_NDISC_NOTIFY,
 DEVCONF_MLDV1_UNSOLICITED_REPORT_INTERVAL,
 DEVCONF_MLDV2_UNSOLICITED_REPORT_INTERVAL,
 DEVCONF_SUPPRESS_FRAG_NDISC,
 DEVCONF_ACCEPT_RA_FROM_LOCAL,
 DEVCONF_USE_OPTIMISTIC,
 DEVCONF_ACCEPT_RA_MTU,
 DEVCONF_STABLE_SECRET,
 DEVCONF_USE_OIF_ADDRS_ONLY,
 DEVCONF_ACCEPT_RA_MIN_HOP_LIMIT,
 DEVCONF_IGNORE_ROUTES_WITH_LINKDOWN,
 DEVCONF_MAX
};
# 12 "/var/lib/cilium/bpf/lib/common.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/in.h" 1
# 24 "/var/lib/cilium/bpf/include/linux/in.h"
enum {
  IPPROTO_IP = 0,

  IPPROTO_ICMP = 1,

  IPPROTO_IGMP = 2,

  IPPROTO_IPIP = 4,

  IPPROTO_TCP = 6,

  IPPROTO_EGP = 8,

  IPPROTO_PUP = 12,

  IPPROTO_UDP = 17,

  IPPROTO_IDP = 22,

  IPPROTO_TP = 29,

  IPPROTO_DCCP = 33,

  IPPROTO_IPV6 = 41,

  IPPROTO_RSVP = 46,

  IPPROTO_GRE = 47,

  IPPROTO_ESP = 50,

  IPPROTO_AH = 51,

  IPPROTO_MTP = 92,

  IPPROTO_BEETPH = 94,

  IPPROTO_ENCAP = 98,

  IPPROTO_PIM = 103,

  IPPROTO_COMP = 108,

  IPPROTO_SCTP = 132,

  IPPROTO_UDPLITE = 136,

  IPPROTO_MPLS = 137,

  IPPROTO_RAW = 255,

  IPPROTO_MAX
};


struct in_addr {
 __be32 s_addr;
};
# 13 "/var/lib/cilium/bpf/lib/common.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/socket.h" 1
# 14 "/var/lib/cilium/bpf/lib/common.h" 2

# 1 "/var/lib/cilium/bpf/lib/eth.h" 1
# 17 "/var/lib/cilium/bpf/lib/eth.h"
union macaddr {
 struct {
  __u32 p1;
  __u16 p2;
 };
 __u8 addr[6];
};

static inline __attribute__((always_inline)) int eth_addrcmp(const union macaddr *a,
           const union macaddr *b)
{
 int tmp;

 tmp = a->p1 - b->p1;
 if (!tmp)
  tmp = a->p2 - b->p2;

 return tmp;
}

static inline __attribute__((always_inline)) int eth_is_bcast(const union macaddr *a)
{
 union macaddr bcast;

 bcast.p1 = 0xffffffff;
 bcast.p2 = 0xffff;

 if (!eth_addrcmp(a, &bcast))
  return 1;
 else
  return 0;
}

static inline __attribute__((always_inline)) int eth_load_saddr(struct __sk_buff *ctx, __u8 *mac,
       int off)
{
 return skb_load_bytes(ctx, off + 6, mac, 6);
}

static inline __attribute__((always_inline)) int eth_store_saddr_aligned(struct __sk_buff *ctx,
         const __u8 *mac, int off)
{
 return skb_store_bytes(ctx, off + 6, mac, 6, 0);
}

static inline __attribute__((always_inline)) int eth_store_saddr(struct __sk_buff *ctx,
        const __u8 *mac, int off)
{

 return eth_store_saddr_aligned(ctx, mac, off);
# 79 "/var/lib/cilium/bpf/lib/eth.h"
}

static inline __attribute__((always_inline)) int eth_load_daddr(struct __sk_buff *ctx, __u8 *mac,
       int off)
{
 return skb_load_bytes(ctx, off, mac, 6);
}

static inline __attribute__((always_inline)) int eth_store_daddr_aligned(struct __sk_buff *ctx,
         const __u8 *mac, int off)
{
 return skb_store_bytes(ctx, off, mac, 6, 0);
}

static inline __attribute__((always_inline)) int eth_store_daddr(struct __sk_buff *ctx,
        const __u8 *mac, int off)
{

 return eth_store_daddr_aligned(ctx, mac, off);
# 110 "/var/lib/cilium/bpf/lib/eth.h"
}

static inline __attribute__((always_inline)) int eth_store_proto(struct __sk_buff *ctx,
        const __u16 proto, int off)
{
 return skb_store_bytes(ctx, off + 6 + 6,
          &proto, sizeof(proto), 0);
}
# 16 "/var/lib/cilium/bpf/lib/common.h" 2

# 1 "/var/lib/cilium/bpf/lib/mono.h" 1
# 18 "/var/lib/cilium/bpf/lib/common.h" 2
# 1 "/var/lib/cilium/bpf/lib/config.h" 1
# 19 "/var/lib/cilium/bpf/lib/common.h" 2
# 101 "/var/lib/cilium/bpf/lib/common.h"
typedef __u64 mac_t;

union v6addr {
 struct {
  __u32 p1;
  __u32 p2;
  __u32 p3;
  __u32 p4;
 };
 struct {
  __u64 d1;
  __u64 d2;
 };
 __u8 addr[16];
} __attribute__((packed));

static inline __attribute__((always_inline)) _Bool validate_ethertype(struct __sk_buff *ctx,
            __u16 *proto)
{
 void *data = ctx_data(ctx);
 void *data_end = ctx_data_end(ctx);
 struct ethhdr *eth = data;

 if (14 == 0) {



  *proto = ctx_get_protocol(ctx);
  return true;
 }

 if (data + 14 > data_end)
  return false;
 *proto = eth->h_proto;
 if ((__builtin_constant_p(*proto) ? ((__u16)( (((__u16)((__be16)(*proto)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(*proto)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(*proto)) < 0x0600)
  return false;
 return true;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) _Bool
____revalidate_data_pull(struct __sk_buff *ctx, void **data_, void **data_end_,
    void **l3, const __u32 l3_len, const _Bool pull,
    __u8 eth_hlen)
{
 const __u64 tot_len = eth_hlen + l3_len;
 void *data_end;
 void *data;


 if (pull)
  skb_pull_data(ctx, tot_len);
 data_end = ctx_data_end(ctx);
 data = ctx_data(ctx);
 if (data + tot_len > data_end)
  return false;


 *data_ = data;
 *data_end_ = data_end;

 *l3 = data + eth_hlen;
 return true;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) _Bool
__revalidate_data_pull(struct __sk_buff *ctx, void **data, void **data_end,
         void **l3, const __u32 l3_len, const _Bool pull)
{
 return ____revalidate_data_pull(ctx, data, data_end, l3, l3_len, pull,
     14);
}
# 220 "/var/lib/cilium/bpf/lib/common.h"
struct endpoint_key {
 union {
  struct {
   __u32 ip4;
   __u32 pad1;
   __u32 pad2;
   __u32 pad3;
  };
  union v6addr ip6;
 };
 __u8 family;
 __u8 key;
 __u16 pad5;
} __attribute__((packed));




struct endpoint_info {
 __u32 ifindex;
 __u16 unused;
 __u16 lxc_id;
 __u32 flags;
 mac_t mac;
 mac_t node_mac;
 __u32 pad[4];
};

struct egress_info {
 __u32 egress_ip;
 __u32 tunnel_endpoint;
};

struct edt_id {
 __u64 id;
};

struct edt_info {
 __u64 bps;
 __u64 t_last;
 __u64 t_horizon_drop;
 __u64 pad[4];
};

struct remote_endpoint_info {
 __u32 sec_label;
 __u32 tunnel_endpoint;
 __u8 key;
};

struct policy_key {
 __u32 sec_label;
 __u16 dport;
 __u8 protocol;
 __u8 egress:1,
   pad:7;
};

struct policy_entry {
 __be16 proxy_port;
 __u8 deny:1,
   pad:7;
 __u8 pad0;
 __u16 pad1;
 __u16 pad2;
 __u64 packets;
 __u64 bytes;
};

struct metrics_key {
 __u8 reason;
 __u8 dir:2,
    pad:6;
 __u16 reserved[3];
};


struct metrics_value {
 __u64 count;
 __u64 bytes;
};

enum {
 POLICY_INGRESS = 1,
 POLICY_EGRESS = 2,
};

enum {
 POLICY_MATCH_NONE = 0,
 POLICY_MATCH_L3_ONLY = 1,
 POLICY_MATCH_L3_L4 = 2,
 POLICY_MATCH_L4_ONLY = 3,
 POLICY_MATCH_ALL = 4,
};

enum {
 CAPTURE_INGRESS = 1,
 CAPTURE_EGRESS = 2,
};

enum {
 CILIUM_NOTIFY_UNSPEC,
 CILIUM_NOTIFY_DROP,
 CILIUM_NOTIFY_DBG_MSG,
 CILIUM_NOTIFY_DBG_CAPTURE,
 CILIUM_NOTIFY_TRACE,
 CILIUM_NOTIFY_POLICY_VERDICT,
 CILIUM_NOTIFY_CAPTURE,
};
# 537 "/var/lib/cilium/bpf/lib/common.h"
struct encrypt_key {
 __u32 ctx;
} __attribute__((packed));


struct encrypt_config {
 __u8 encrypt_key;
} __attribute__((packed));




static inline __attribute__((always_inline)) __u32 or_encrypt_key(__u8 key)
{
 return (((__u32)key & 0x0F) << 12) | 0x0E00;
}
# 567 "/var/lib/cilium/bpf/lib/common.h"
enum {
 CB_SRC_LABEL,





 CB_IFINDEX,




 CB_POLICY,

 CB_NAT46_STATE,



 CB_CT_STATE,





};


enum {
 NAT46_CLEAR,
 NAT64,
 NAT46,
};
# 615 "/var/lib/cilium/bpf/lib/common.h"
enum {
 CT_NEW,
 CT_ESTABLISHED,
 CT_REPLY,
 CT_RELATED,
 CT_REOPENED,
};


enum {
 SVC_FLAG_EXTERNAL_IP = (1 << 0),
 SVC_FLAG_NODEPORT = (1 << 1),
 SVC_FLAG_LOCAL_SCOPE = (1 << 2),
 SVC_FLAG_HOSTPORT = (1 << 3),
 SVC_FLAG_AFFINITY = (1 << 4),
 SVC_FLAG_LOADBALANCER = (1 << 5),
 SVC_FLAG_ROUTABLE = (1 << 6),
 SVC_FLAG_SOURCE_RANGE = (1 << 7),
};


enum {
 SVC_FLAG_LOCALREDIRECT = (1 << 0),
};

struct ipv6_ct_tuple {



 union v6addr daddr;
 union v6addr saddr;



 __be16 dport;
 __be16 sport;
 __u8 nexthdr;
 __u8 flags;
} __attribute__((packed));

struct ipv4_ct_tuple {



 __be32 daddr;
 __be32 saddr;



 __be16 dport;
 __be16 sport;
 __u8 nexthdr;
 __u8 flags;
} __attribute__((packed));

struct ct_entry {
 __u64 rx_packets;
 __u64 rx_bytes;
 __u64 tx_packets;
 __u64 tx_bytes;
 __u32 lifetime;
 __u16 rx_closing:1,
       tx_closing:1,
       nat46:1,
       lb_loopback:1,
       seen_non_syn:1,
       node_port:1,
       proxy_redirect:1,
       dsr:1,
       reserved:8;
 __u16 rev_nat_index;



 __u16 ifindex;




 __u8 tx_flags_seen;
 __u8 rx_flags_seen;

 __u32 src_sec_id;




 __u32 last_tx_report;
 __u32 last_rx_report;
};

struct lb6_key {
 union v6addr address;
 __be16 dport;
 __u16 backend_slot;
 __u8 proto;
 __u8 scope;
 __u8 pad[2];
};


struct lb6_service {
 union {
  __u32 backend_id;
  __u32 affinity_timeout;
 };
 __u16 count;
 __u16 rev_nat_index;
 __u8 flags;
 __u8 flags2;
 __u8 pad[2];
};


struct lb6_backend {
 union v6addr address;
 __be16 port;
 __u8 proto;
 __u8 pad;
};

struct lb6_health {
 struct lb6_backend peer;
};

struct lb6_reverse_nat {
 union v6addr address;
 __be16 port;
} __attribute__((packed));

struct ipv6_revnat_tuple {
 __sock_cookie cookie;
 union v6addr address;
 __be16 port;
 __u16 pad;
};

struct ipv6_revnat_entry {
 union v6addr address;
 __be16 port;
 __u16 rev_nat_index;
};

struct lb4_key {
 __be32 address;
 __be16 dport;
 __u16 backend_slot;
 __u8 proto;
 __u8 scope;
 __u8 pad[2];
};

struct lb4_service {
 union {
  __u32 backend_id;
  __u32 affinity_timeout;
 };



 __u16 count;
 __u16 rev_nat_index;
 __u8 flags;
 __u8 flags2;
 __u8 pad[2];
};

struct lb4_backend {
 __be32 address;
 __be16 port;
 __u8 proto;
 __u8 pad;
};

struct lb4_health {
 struct lb4_backend peer;
};

struct lb4_reverse_nat {
 __be32 address;
 __be16 port;
} __attribute__((packed));

struct ipv4_revnat_tuple {
 __sock_cookie cookie;
 __be32 address;
 __be16 port;
 __u16 pad;
};

struct ipv4_revnat_entry {
 __be32 address;
 __be16 port;
 __u16 rev_nat_index;
};

union lb4_affinity_client_id {
 __u32 client_ip;
 __net_cookie client_cookie;
} __attribute__((packed));

struct lb4_affinity_key {
 union lb4_affinity_client_id client_id;
 __u16 rev_nat_id;
 __u8 netns_cookie:1,
      reserved:7;
 __u8 pad1;
 __u32 pad2;
} __attribute__((packed));

union lb6_affinity_client_id {
 union v6addr client_ip;
 __net_cookie client_cookie;
} __attribute__((packed));

struct lb6_affinity_key {
 union lb6_affinity_client_id client_id;
 __u16 rev_nat_id;
 __u8 netns_cookie:1,
      reserved:7;
 __u8 pad1;
 __u32 pad2;
} __attribute__((packed));

struct lb_affinity_val {
 __u64 last_used;
 __u32 backend_id;
 __u32 pad;
} __attribute__((packed));

struct lb_affinity_match {
 __u32 backend_id;
 __u16 rev_nat_id;
 __u16 pad;
} __attribute__((packed));

struct ct_state {
 __u16 rev_nat_index;
 __u16 loopback:1,
       node_port:1,
       proxy_redirect:1,
       dsr:1,
       reserved:12;
 __be32 addr;
 __be32 svc_addr;
 __u32 src_sec_id;
 __u16 ifindex;
 __u16 backend_id;
};




struct lb4_src_range_key {
 struct bpf_lpm_trie_key lpm_key;
 __u16 rev_nat_id;
 __u16 pad;
 __u32 addr;
};

struct lb6_src_range_key {
 struct bpf_lpm_trie_key lpm_key;
 __u16 rev_nat_id;
 __u16 pad;
 union v6addr addr;
};

static inline __attribute__((always_inline)) int redirect_ep(struct __sk_buff *ctx __attribute__((__unused__)),
           int ifindex __attribute__((__unused__)),
           _Bool needs_backlog __attribute__((__unused__)))
{
# 896 "/var/lib/cilium/bpf/lib/common.h"
 if (needs_backlog || !0) {
  return redirect(ifindex, 0);
 } else {




  skb_change_type(ctx, 0);

  return redirect_peer(ifindex, 0);
 }



}

struct lpm_v4_key {
 struct bpf_lpm_trie_key lpm;
 __u8 addr[4];
};

struct lpm_v6_key {
 struct bpf_lpm_trie_key lpm;
 __u8 addr[16];
};

struct lpm_val {

 __u8 flags;
};


# 1 "/var/lib/cilium/bpf/lib/overloadable.h" 1
# 11 "/var/lib/cilium/bpf/lib/overloadable.h"
# 1 "/var/lib/cilium/bpf/lib/overloadable_skb.h" 1






static inline __attribute__((always_inline)) __attribute__((__unused__)) void
bpf_clear_meta(struct __sk_buff *ctx)
{
 __u32 zero = 0;

 ({ typeof(ctx->cb[0]) __val = (zero); (*(volatile typeof(ctx->cb[0]) *)&ctx->cb[0]) = (__val); bpf_barrier(); __val; });
 ({ typeof(ctx->cb[1]) __val = (zero); (*(volatile typeof(ctx->cb[1]) *)&ctx->cb[1]) = (__val); bpf_barrier(); __val; });
 ({ typeof(ctx->cb[2]) __val = (zero); (*(volatile typeof(ctx->cb[2]) *)&ctx->cb[2]) = (__val); bpf_barrier(); __val; });
 ({ typeof(ctx->cb[3]) __val = (zero); (*(volatile typeof(ctx->cb[3]) *)&ctx->cb[3]) = (__val); bpf_barrier(); __val; });
 ({ typeof(ctx->cb[4]) __val = (zero); (*(volatile typeof(ctx->cb[4]) *)&ctx->cb[4]) = (__val); bpf_barrier(); __val; });
}




static inline __attribute__((always_inline)) __attribute__((__unused__)) int
get_identity(const struct __sk_buff *ctx)
{
 return ((ctx->mark & 0xFF) << 16) | ctx->mark >> 16;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_encrypt_dip(struct __sk_buff *ctx, __u32 ip_endpoint)
{
 ctx->cb[4] = ip_endpoint;
}




static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_identity_mark(struct __sk_buff *ctx, __u32 identity)
{
 ctx->mark = ctx->mark & 0xFF00;
 ctx->mark |= ((identity & 0xFFFF) << 16) | ((identity & 0xFF0000) >> 16);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_identity_meta(struct __sk_buff *ctx, __u32 identity)
{
 ctx->cb[1] = identity;
}




static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_encrypt_key_mark(struct __sk_buff *ctx, __u8 key)
{
 ctx->mark = or_encrypt_key(key);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_encrypt_key_meta(struct __sk_buff *ctx, __u8 key)
{
 ctx->cb[0] = or_encrypt_key(key);
}






static inline __attribute__((always_inline)) __attribute__((__unused__)) void
set_encrypt_mark(struct __sk_buff *ctx)
{
 ctx->mark |= 0x0E00;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int
redirect_self(const struct __sk_buff *ctx)
{







 return redirect(ctx->ifindex, 0);



}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ctx_skip_nodeport_clear(struct __sk_buff *ctx __attribute__((__unused__)))
{

 ctx->tc_index &= ~4;

}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ctx_skip_nodeport_set(struct __sk_buff *ctx __attribute__((__unused__)))
{

 ctx->tc_index |= 4;

}

static inline __attribute__((always_inline)) __attribute__((__unused__)) _Bool
ctx_skip_nodeport(struct __sk_buff *ctx __attribute__((__unused__)))
{

 volatile __u32 tc_index = ctx->tc_index;
 ctx->tc_index &= ~4;
 return tc_index & 4;



}
# 137 "/var/lib/cilium/bpf/lib/overloadable_skb.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) __u32 ctx_get_xfer(struct __sk_buff *ctx)
{
 __u32 *data_meta = ctx_data_meta(ctx);
 void *data = ctx_data(ctx);

 return !ctx_no_room(data_meta + 1, data) ? data_meta[0] : 0;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ctx_set_xfer(struct __sk_buff *ctx __attribute__((__unused__)), __u32 meta __attribute__((__unused__)))
{

}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int
ctx_change_head(struct __sk_buff *ctx, __u32 head_room, __u64 flags)
{
 return skb_change_head(ctx, head_room, flags);
}
# 12 "/var/lib/cilium/bpf/lib/overloadable.h" 2
# 928 "/var/lib/cilium/bpf/lib/common.h" 2
# 41 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/edt.h" 1
# 11 "/var/lib/cilium/bpf/lib/edt.h"
# 1 "/var/lib/cilium/bpf/lib/maps.h" 1







# 1 "/var/lib/cilium/bpf/lib/ipv6.h" 1








# 1 "/var/lib/cilium/bpf/lib/dbg.h" 1







enum {
 DBG_UNSPEC,
 DBG_GENERIC,
 DBG_LOCAL_DELIVERY,
 DBG_ENCAP,
 DBG_LXC_FOUND,
 DBG_POLICY_DENIED,
 DBG_CT_LOOKUP,
 DBG_CT_LOOKUP_REV,
 DBG_CT_MATCH,
 DBG_CT_CREATED,
 DBG_CT_CREATED2,
 DBG_ICMP6_HANDLE,
 DBG_ICMP6_REQUEST,
 DBG_ICMP6_NS,
 DBG_ICMP6_TIME_EXCEEDED,
 DBG_CT_VERDICT,
 DBG_DECAP,
 DBG_PORT_MAP,
 DBG_ERROR_RET,
 DBG_TO_HOST,
 DBG_TO_STACK,
 DBG_PKT_HASH,
 DBG_LB6_LOOKUP_FRONTEND,
 DBG_LB6_LOOKUP_FRONTEND_FAIL,
 DBG_LB6_LOOKUP_BACKEND_SLOT,
 DBG_LB6_LOOKUP_BACKEND_SLOT_SUCCESS,
 DBG_LB6_LOOKUP_BACKEND_SLOT_V2_FAIL,
 DBG_LB6_LOOKUP_BACKEND_FAIL,
 DBG_LB6_REVERSE_NAT_LOOKUP,
 DBG_LB6_REVERSE_NAT,
 DBG_LB4_LOOKUP_FRONTEND,
 DBG_LB4_LOOKUP_FRONTEND_FAIL,
 DBG_LB4_LOOKUP_BACKEND_SLOT,
 DBG_LB4_LOOKUP_BACKEND_SLOT_SUCCESS,
 DBG_LB4_LOOKUP_BACKEND_SLOT_V2_FAIL,
 DBG_LB4_LOOKUP_BACKEND_FAIL,
 DBG_LB4_REVERSE_NAT_LOOKUP,
 DBG_LB4_REVERSE_NAT,
 DBG_LB4_LOOPBACK_SNAT,
 DBG_LB4_LOOPBACK_SNAT_REV,
 DBG_CT_LOOKUP4,
 DBG_RR_BACKEND_SLOT_SEL,
 DBG_REV_PROXY_LOOKUP,
 DBG_REV_PROXY_FOUND,
 DBG_REV_PROXY_UPDATE,
 DBG_L4_POLICY,
 DBG_NETDEV_IN_CLUSTER,
 DBG_NETDEV_ENCAP4,
 DBG_CT_LOOKUP4_1,



 DBG_CT_LOOKUP4_2,



 DBG_CT_CREATED4,



 DBG_CT_LOOKUP6_1,



 DBG_CT_LOOKUP6_2,



 DBG_CT_CREATED6,



 DBG_SKIP_PROXY,


 DBG_L4_CREATE,



 DBG_IP_ID_MAP_FAILED4,



 DBG_IP_ID_MAP_FAILED6,



 DBG_IP_ID_MAP_SUCCEED4,



 DBG_IP_ID_MAP_SUCCEED6,



 DBG_LB_STALE_CT,



 DBG_INHERIT_IDENTITY,


 DBG_SK_LOOKUP4,



 DBG_SK_LOOKUP6,



 DBG_SK_ASSIGN,


};


enum {
 DBG_CAPTURE_UNSPEC,
 DBG_CAPTURE_FROM_RESERVED1,
 DBG_CAPTURE_FROM_RESERVED2,
 DBG_CAPTURE_FROM_RESERVED3,
 DBG_CAPTURE_DELIVERY,
 DBG_CAPTURE_FROM_LB,
 DBG_CAPTURE_AFTER_V46,
 DBG_CAPTURE_AFTER_V64,
 DBG_CAPTURE_PROXY_PRE,
 DBG_CAPTURE_PROXY_POST,
 DBG_CAPTURE_SNAT_PRE,
 DBG_CAPTURE_SNAT_POST,
};
# 238 "/var/lib/cilium/bpf/lib/dbg.h"
static inline __attribute__((always_inline))
void cilium_dbg(struct __sk_buff *ctx __attribute__((__unused__)), __u8 type __attribute__((__unused__)),
  __u32 arg1 __attribute__((__unused__)), __u32 arg2 __attribute__((__unused__)))
{
}

static inline __attribute__((always_inline))
void cilium_dbg3(struct __sk_buff *ctx __attribute__((__unused__)),
   __u8 type __attribute__((__unused__)), __u32 arg1 __attribute__((__unused__)),
   __u32 arg2 __attribute__((__unused__)), __u32 arg3 __attribute__((__unused__)))
{
}

static inline __attribute__((always_inline))
void cilium_dbg_capture(struct __sk_buff *ctx __attribute__((__unused__)),
   __u8 type __attribute__((__unused__)), __u32 arg1 __attribute__((__unused__)))
{
}

static inline __attribute__((always_inline))
void cilium_dbg_capture2(struct __sk_buff *ctx __attribute__((__unused__)),
    __u8 type __attribute__((__unused__)), __u32 arg1 __attribute__((__unused__)),
    __u32 arg2 __attribute__((__unused__)))
{
}
# 10 "/var/lib/cilium/bpf/lib/ipv6.h" 2
# 38 "/var/lib/cilium/bpf/lib/ipv6.h"
static inline __attribute__((always_inline)) int ipv6_optlen(const struct ipv6_opt_hdr *opthdr)
{
 return (opthdr->hdrlen + 1) << 3;
}

static inline __attribute__((always_inline)) int ipv6_authlen(const struct ipv6_opt_hdr *opthdr)
{
 return (opthdr->hdrlen + 2) << 2;
}

static inline __attribute__((always_inline)) int ipv6_hdrlen(struct __sk_buff *ctx, int l3_off,
           __u8 *nexthdr)
{
 int i, len = sizeof(struct ipv6hdr);
 struct ipv6_opt_hdr opthdr __attribute__((aligned(8)));
 __u8 nh = *nexthdr;

#pragma unroll
 for (i = 0; i < 4; i++) {
  switch (nh) {
  case 59:
   return -156;

  case 44:
   return -157;

  case 0:
  case 43:
  case 51:
  case 60:
   if (skb_load_bytes(ctx, l3_off + len, &opthdr, sizeof(opthdr)) < 0)
    return -134;

   nh = opthdr.nexthdr;
   if (nh == 51)
    len += ipv6_authlen(&opthdr);
   else
    len += ipv6_optlen(&opthdr);
   break;

  default:
   *nexthdr = nh;
   return len;
  }
 }


 return -156;
}

static inline __attribute__((always_inline)) void ipv6_addr_copy(union v6addr *dst,
        const union v6addr *src)
{
 dst->d1 = src->d1;
 dst->d2 = src->d2;
}

static inline __attribute__((always_inline)) __u64 ipv6_addrcmp(const union v6addr *a,
       const union v6addr *b)
{
 __u64 tmp;

 tmp = a->d1 - b->d1;
 if (!tmp)
  tmp = a->d2 - b->d2;
 return tmp;
}


static inline __attribute__((always_inline)) int ipv6_addr_in_net(const union v6addr *addr,
         const union v6addr *net,
         const union v6addr *mask)
{
 return ((addr->p1 & mask->p1) == net->p1)
  && (!mask->p2
      || (((addr->p2 & mask->p2) == net->p2)
   && (!mask->p3
       || (((addr->p3 & mask->p3) == net->p3)
    && (!mask->p4 || ((addr->p4 & mask->p4) == net->p4))))));
}





static inline __attribute__((always_inline)) void ipv6_addr_clear_suffix(union v6addr *addr,
         int prefix)
{
 addr->p1 &= (__builtin_constant_p(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF) ? ((__be32)((__u32)( (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF));
 prefix -= 32;
 addr->p2 &= (__builtin_constant_p(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF) ? ((__be32)((__u32)( (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF));
 prefix -= 32;
 addr->p3 &= (__builtin_constant_p(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF) ? ((__be32)((__u32)( (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF));
 prefix -= 32;
 addr->p4 &= (__builtin_constant_p(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF) ? ((__be32)((__u32)( (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF));
}

static inline __attribute__((always_inline)) int ipv6_match_prefix_64(const union v6addr *addr,
      const union v6addr *prefix)
{
 int tmp;

 tmp = addr->p1 - prefix->p1;
 if (!tmp)
  tmp = addr->p2 - prefix->p2;

 return !tmp;
}

static inline __attribute__((always_inline)) int ipv6_dec_hoplimit(struct __sk_buff *ctx, int off)
{
 __u8 hl;

 skb_load_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, hop_limit),
         &hl, sizeof(hl));
 if (hl <= 1)
  return 1;
 hl--;
 if (skb_store_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, hop_limit),
       &hl, sizeof(hl), BPF_F_RECOMPUTE_CSUM) < 0)
  return -141;
 return 0;
}

static inline __attribute__((always_inline)) int ipv6_load_saddr(struct __sk_buff *ctx, int off,
        union v6addr *dst)
{
 return skb_load_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, saddr), dst->addr,
         sizeof(((struct ipv6hdr *)((void *)0))->saddr));
}


static inline __attribute__((always_inline)) int ipv6_store_saddr(struct __sk_buff *ctx, __u8 *addr,
         int off)
{
 return skb_store_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, saddr), addr, 16, 0);
}

static inline __attribute__((always_inline)) int ipv6_load_daddr(struct __sk_buff *ctx, int off,
        union v6addr *dst)
{
 return skb_load_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, daddr), dst->addr,
         sizeof(((struct ipv6hdr *)((void *)0))->daddr));
}


static inline __attribute__((always_inline)) int ipv6_store_daddr(struct __sk_buff *ctx, __u8 *addr,
         int off)
{
 return skb_store_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, daddr), addr, 16, 0);
}

static inline __attribute__((always_inline)) int ipv6_load_nexthdr(struct __sk_buff *ctx, int off,
          __u8 *nexthdr)
{
 return skb_load_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, nexthdr), nexthdr,
         sizeof(__u8));
}


static inline __attribute__((always_inline)) int ipv6_store_nexthdr(struct __sk_buff *ctx, __u8 *nexthdr,
           int off)
{
 return skb_store_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, nexthdr), nexthdr,
         sizeof(__u8), 0);
}

static inline __attribute__((always_inline)) int ipv6_load_paylen(struct __sk_buff *ctx, int off,
         __be16 *len)
{
 return skb_load_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, payload_len),
         len, sizeof(*len));
}


static inline __attribute__((always_inline)) int ipv6_store_paylen(struct __sk_buff *ctx, int off,
          __be16 *len)
{
 return skb_store_bytes(ctx, off + __builtin_offsetof(struct ipv6hdr, payload_len),
          len, sizeof(*len), 0);
}

static inline __attribute__((always_inline)) int ipv6_store_flowlabel(struct __sk_buff *ctx, int off,
      __be32 label)
{
 __be32 old;


 if (skb_load_bytes(ctx, off, &old, 4) < 0)
  return -134;

 old &= ((__builtin_constant_p(0x0FFFFFFF) ? ((__be32)((__u32)( (((__u32)((0x0FFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x0FFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x0FFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x0FFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(0x0FFFFFFF)) & ~(__builtin_constant_p(0x000FFFFF) ? ((__be32)((__u32)( (((__u32)((0x000FFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x000FFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x000FFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x000FFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(0x000FFFFF)));
 old = (__builtin_constant_p(0x60000000) ? ((__be32)((__u32)( (((__u32)((0x60000000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x60000000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x60000000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x60000000)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(0x60000000)) | label | old;

 if (skb_store_bytes(ctx, off, &old, 4, BPF_F_RECOMPUTE_CSUM) < 0)
  return -141;

 return 0;
}

static inline __attribute__((always_inline)) __be32 ipv6_pseudohdr_checksum(struct ipv6hdr *hdr,
            __u8 next_hdr,
            __u16 payload_len, __be32 sum)
{
 __be32 len = (__builtin_constant_p((__u32)payload_len) ? ((__be32)((__u32)( (((__u32)(((__u32)payload_len)) & (__u32)0x000000ffUL) << 24) | (((__u32)(((__u32)payload_len)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(((__u32)payload_len)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(((__u32)payload_len)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32((__u32)payload_len));
 __be32 nexthdr = (__builtin_constant_p((__u32)next_hdr) ? ((__be32)((__u32)( (((__u32)(((__u32)next_hdr)) & (__u32)0x000000ffUL) << 24) | (((__u32)(((__u32)next_hdr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)(((__u32)next_hdr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(((__u32)next_hdr)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32((__u32)next_hdr));

 sum = csum_diff(((void *)0), 0, &hdr->saddr, sizeof(struct in6_addr), sum);
 sum = csum_diff(((void *)0), 0, &hdr->daddr, sizeof(struct in6_addr), sum);
 sum = csum_diff(((void *)0), 0, &len, sizeof(len), sum);
 sum = csum_diff(((void *)0), 0, &nexthdr, sizeof(nexthdr), sum);

 return sum;
}




static inline __attribute__((always_inline)) int ipv6_addr_is_mapped(const union v6addr *addr)
{
 return addr->p1 == 0 && addr->p2 == 0 && addr->p3 == 0xFFFF0000;
}
# 9 "/var/lib/cilium/bpf/lib/maps.h" 2
# 1 "/var/lib/cilium/bpf/lib/ids.h" 1
# 10 "/var/lib/cilium/bpf/lib/maps.h" 2



struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lxc = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(struct endpoint_key),
 .size_value = sizeof(struct endpoint_info),
 .pinning = 2,
 .max_elem = 65535,
 .flags = BPF_F_NO_PREALLOC,
};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_metrics = {
 .type = BPF_MAP_TYPE_PERCPU_HASH,
 .size_key = sizeof(struct metrics_key),
 .size_value = sizeof(struct metrics_value),
 .pinning = 2,
 .max_elem = 1024,
 .flags = BPF_F_NO_PREALLOC,
};



struct bpf_elf_map __attribute__((section("maps"), used)) cilium_call_policy = {
 .type = BPF_MAP_TYPE_PROG_ARRAY,
 .id = 1,
 .size_key = sizeof(__u32),
 .size_value = sizeof(__u32),
 .pinning = 2,
 .max_elem = 65535,
};
# 67 "/var/lib/cilium/bpf/lib/maps.h"
struct bpf_elf_map __attribute__((section("maps"), used)) cilium_policy_65535 = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(struct policy_key),
 .size_value = sizeof(struct policy_entry),
 .pinning = 2,
 .max_elem = 16384,
 .flags = BPF_F_NO_PREALLOC,
};




struct bpf_elf_map __attribute__((section("maps"), used)) cilium_calls_hostns_65535 = {
 .type = BPF_MAP_TYPE_PROG_ARRAY,
 .id = 2,
 .size_key = sizeof(__u32),
 .size_value = sizeof(__u32),
 .pinning = 2,
 .max_elem = 25,
};




struct bpf_elf_map __attribute__((section("maps"), used)) cilium_tunnel_map = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(struct endpoint_key),
 .size_value = sizeof(struct endpoint_key),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};
# 155 "/var/lib/cilium/bpf/lib/maps.h"
struct ipcache_key {
 struct bpf_lpm_trie_key lpm_key;
 __u16 pad1;
 __u8 pad2;
 __u8 family;
 union {
  struct {
   __u32 ip4;
   __u32 pad4;
   __u32 pad5;
   __u32 pad6;
  };
  union v6addr ip6;
 };
} __attribute__((packed));


struct bpf_elf_map __attribute__((section("maps"), used)) cilium_ipcache = {
 .type = BPF_MAP_TYPE_LPM_TRIE,
 .size_key = sizeof(struct ipcache_key),
 .size_value = sizeof(struct remote_endpoint_info),
 .pinning = 2,
 .max_elem = 512000,
 .flags = BPF_F_NO_PREALLOC,
};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_encrypt_state = {
 .type = BPF_MAP_TYPE_ARRAY,
 .size_key = sizeof(struct encrypt_key),
 .size_value = sizeof(struct encrypt_config),
 .pinning = 2,
 .max_elem = 1,
};

struct egress_key {
 struct bpf_lpm_trie_key lpm_key;
 __u32 sip;
 __u32 dip;
};


struct bpf_elf_map __attribute__((section("maps"), used)) cilium_egress_v4 = {
 .type = BPF_MAP_TYPE_LPM_TRIE,
 .size_key = sizeof(struct egress_key),
 .size_value = sizeof(struct egress_info),
 .pinning = 2,
 .max_elem = 16384,
 .flags = BPF_F_NO_PREALLOC,
};



static inline __attribute__((always_inline)) void ep_tail_call(struct __sk_buff *ctx,
      const __u32 index)
{
 tail_call_static(ctx, &cilium_calls_hostns_65535, index);
}
# 12 "/var/lib/cilium/bpf/lib/edt.h" 2
# 79 "/var/lib/cilium/bpf/lib/edt.h"
static inline __attribute__((always_inline)) void
edt_set_aggregate(struct __sk_buff *ctx __attribute__((__unused__)),
    __u32 aggregate __attribute__((__unused__)))
{
}
# 42 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/arp.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/if_arp.h" 1
# 116 "/var/lib/cilium/bpf/include/linux/if_arp.h"
struct arphdr {
 __be16 ar_hrd;
 __be16 ar_pro;
 unsigned char ar_hln;
 unsigned char ar_pln;
 __be16 ar_op;
# 133 "/var/lib/cilium/bpf/include/linux/if_arp.h"
};
# 8 "/var/lib/cilium/bpf/lib/arp.h" 2



# 1 "/var/lib/cilium/bpf/lib/drop.h" 1
# 18 "/var/lib/cilium/bpf/lib/drop.h"
# 1 "/var/lib/cilium/bpf/lib/events.h" 1








struct bpf_elf_map __attribute__((section("maps"), used)) cilium_events = {
 .type = BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 .size_key = sizeof(__u32),
 .size_value = sizeof(__u32),
 .pinning = 2,
 .max_elem = 8,
};
# 19 "/var/lib/cilium/bpf/lib/drop.h" 2


# 1 "/var/lib/cilium/bpf/lib/metrics.h" 1
# 24 "/var/lib/cilium/bpf/lib/metrics.h"
static inline __attribute__((always_inline)) void update_metrics(__u64 bytes, __u8 direction,
        __u8 reason)
{
 struct metrics_value *entry, newEntry = {};
 struct metrics_key key = {};

 key.reason = reason;
 key.dir = direction;


 entry = map_lookup_elem(&cilium_metrics, &key);
 if (entry) {
  entry->count += 1;
  entry->bytes += bytes;
 } else {
  newEntry.count = 1;
  newEntry.bytes = bytes;
  map_update_elem(&cilium_metrics, &key, &newEntry, 0);
 }
}






static inline __attribute__((always_inline)) __u8 ct_to_metrics_dir(__u8 ct_dir)
{
 switch (ct_dir) {
 case 1:
  return 1;
 case 0:
  return 2;
 case 2:
  return 3;
 default:
  return 0;
 }
}
# 22 "/var/lib/cilium/bpf/lib/drop.h" 2


struct drop_notify {
 __u8 type; __u8 subtype; __u16 source; __u32 hash; __u32 len_orig; __u16 len_cap; __u16 version;
 __u32 src_label;
 __u32 dst_label;
 __u32 dst_id;
 __u32 unused;
};

__attribute__((section("2" "/" "1"), used))
int __send_drop_notify(struct __sk_buff *ctx)
{

 int error = ctx_load_meta(ctx, 2) & 0xFFFFFFFF;
 __u64 ctx_len = ctx_full_len(ctx);
 __u64 cap_len = ({ __u64 _x = (128ULL); __u64 _y = (ctx_len); (void) (&_x == &_y); _x < _y ? _x : _y; });
 struct drop_notify msg;

 if (error < 0)
  error = -error;

 msg = (typeof(msg)) {
  .type = (CILIUM_NOTIFY_DROP), .subtype = (error), .source = 158, .hash = ctx->hash,
  .len_orig = (ctx_len), .len_cap = (cap_len), .version = 1,
  .src_label = ctx_load_meta(ctx, 0),
  .dst_label = ctx_load_meta(ctx, 1),
  .dst_id = ctx_load_meta(ctx, 3),
 };

 skb_event_output(ctx, &cilium_events,
    (cap_len << 32) | BPF_F_CURRENT_CPU,
    &msg, sizeof(msg));

 return ctx_load_meta(ctx, 4);
}
# 72 "/var/lib/cilium/bpf/lib/drop.h"
static inline __attribute__((always_inline)) int send_drop_notify(struct __sk_buff *ctx, __u32 src,
         __u32 dst, __u32 dst_id, int reason,
         int exitcode, __u8 direction)
{
 ctx_store_meta(ctx, 0, src);
 ctx_store_meta(ctx, 1, dst);
 ctx_store_meta(ctx, 2, reason);
 ctx_store_meta(ctx, 3, dst_id);
 ctx_store_meta(ctx, 4, exitcode);

 update_metrics(ctx_full_len(ctx), direction, -reason);
 ep_tail_call(ctx, 1);

 return exitcode;
}
# 98 "/var/lib/cilium/bpf/lib/drop.h"
static inline __attribute__((always_inline)) int send_drop_notify_error(struct __sk_buff *ctx, __u32 src,
        int error, int exitcode,
        __u8 direction)
{
 return send_drop_notify(ctx, src, 0, 0, error, exitcode, direction);
}
# 12 "/var/lib/cilium/bpf/lib/arp.h" 2

struct arp_eth {
 unsigned char ar_sha[6];
 __be32 ar_sip;
 unsigned char ar_tha[6];
 __be32 ar_tip;
} __attribute__((packed));


static inline __attribute__((always_inline)) int arp_check(struct ethhdr *eth,
         const struct arphdr *arp,
         union macaddr *mac)
{
 union macaddr *dmac = (union macaddr *) &eth->h_dest;

 return arp->ar_op == (__builtin_constant_p(1) ? ((__be16)((__u16)( (((__u16)((1)) & (__u16)0x00ffU) << 8) | (((__u16)((1)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(1)) &&
        arp->ar_hrd == (__builtin_constant_p(1) ? ((__be16)((__u16)( (((__u16)((1)) & (__u16)0x00ffU) << 8) | (((__u16)((1)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(1)) &&
        (eth_is_bcast(dmac) || !eth_addrcmp(dmac, mac));
}

static inline __attribute__((always_inline)) int
arp_prepare_response(struct __sk_buff *ctx, union macaddr *smac, __be32 sip,
       union macaddr *dmac, __be32 tip)
{
 __be16 arpop = (__builtin_constant_p(2) ? ((__be16)((__u16)( (((__u16)((2)) & (__u16)0x00ffU) << 8) | (((__u16)((2)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(2));

 if (eth_store_saddr(ctx, smac->addr, 0) < 0 ||
     eth_store_daddr(ctx, dmac->addr, 0) < 0 ||
     skb_store_bytes(ctx, 20, &arpop, sizeof(arpop), 0) < 0 ||

     skb_store_bytes(ctx, 22, smac, 6, 0) < 0 ||
     skb_store_bytes(ctx, 28, &sip, sizeof(sip), 0) < 0 ||
     skb_store_bytes(ctx, 32, dmac, 6, 0) < 0 ||
     skb_store_bytes(ctx, 38, &tip, sizeof(tip), 0) < 0)
  return -141;

 return 0;
}

static inline __attribute__((always_inline)) _Bool
arp_validate(const struct __sk_buff *ctx, union macaddr *mac,
      union macaddr *smac, __be32 *sip, __be32 *tip)
{
 void *data_end = (void *) (long) ctx->data_end;
 void *data = (void *) (long) ctx->data;
 struct arphdr *arp = data + 14;
 struct ethhdr *eth = data;
 struct arp_eth *arp_eth;

 if (data + 14 + sizeof(*arp) + sizeof(*arp_eth) > data_end)
  return false;

 if (!arp_check(eth, arp, mac))
  return false;

 arp_eth = data + 14 + sizeof(*arp);
 *smac = *(union macaddr *) &eth->h_source;
 *sip = arp_eth->ar_sip;
 *tip = arp_eth->ar_tip;

 return true;
}

static inline __attribute__((always_inline)) int
arp_respond(struct __sk_buff *ctx, union macaddr *smac, __be32 sip,
     union macaddr *dmac, __be32 tip, int direction)
{
 int ret = arp_prepare_response(ctx, smac, sip, dmac, tip);

 if (__builtin_expect(!!(ret != 0), 0))
  goto error;

 cilium_dbg_capture(ctx, DBG_CAPTURE_DELIVERY,
      ctx_get_ifindex(ctx));
 return ctx_redirect(ctx, ctx_get_ifindex(ctx), direction);

error:
 return send_drop_notify_error(ctx, 0, ret, 2, 2);
}
# 43 "/var/lib/cilium/bpf/bpf_host.c" 2


# 1 "/var/lib/cilium/bpf/lib/ipv4.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/ip.h" 1
# 86 "/var/lib/cilium/bpf/include/linux/ip.h"
struct iphdr {

 __u8 ihl:4,
  version:4;






 __u8 tos;
 __be16 tot_len;
 __be16 id;
 __be16 frag_off;
 __u8 ttl;
 __u8 protocol;
 __sum16 check;
 __be32 saddr;
 __be32 daddr;

};


struct ip_auth_hdr {
 __u8 nexthdr;
 __u8 hdrlen;
 __be16 reserved;
 __be32 spi;
 __be32 seq_no;
 __u8 auth_data[0];
};

struct ip_esp_hdr {
 __be32 spi;
 __be32 seq_no;
 __u8 enc_data[0];
};

struct ip_comp_hdr {
 __u8 nexthdr;
 __u8 flags;
 __be16 cpi;
};

struct ip_beet_phdr {
 __u8 nexthdr;
 __u8 hdrlen;
 __u8 padlen;
 __u8 reserved;
};
# 8 "/var/lib/cilium/bpf/lib/ipv4.h" 2




struct ipv4_frag_id {
 __be32 daddr;
 __be32 saddr;
 __be16 id;
 __u8 proto;
 __u8 pad;
} __attribute__((packed));

struct ipv4_frag_l4ports {
 __be16 sport;
 __be16 dport;
} __attribute__((packed));


struct bpf_elf_map __attribute__((section("maps"), used)) cilium_ipv4_frag_datagrams = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(struct ipv4_frag_id),
 .size_value = sizeof(struct ipv4_frag_l4ports),
 .pinning = 2,
 .max_elem = 8192,
};


static inline __attribute__((always_inline)) int ipv4_load_daddr(struct __sk_buff *ctx, int off,
        __u32 *dst)
{
 return skb_load_bytes(ctx, off + __builtin_offsetof(struct iphdr, daddr), dst, 4);
}

static inline __attribute__((always_inline)) int ipv4_dec_ttl(struct __sk_buff *ctx, int off,
     const struct iphdr *ip4)
{
 __u8 new_ttl, ttl = ip4->ttl;

 if (ttl <= 1)
  return 1;

 new_ttl = ttl - 1;

 l3_csum_replace(ctx, off + __builtin_offsetof(struct iphdr, check), ttl, new_ttl, 2);
 skb_store_bytes(ctx, off + __builtin_offsetof(struct iphdr, ttl), &new_ttl, sizeof(new_ttl), 0);

 return 0;
}

static inline __attribute__((always_inline)) int ipv4_hdrlen(const struct iphdr *ip4)
{
 return ip4->ihl * 4;
}

static inline __attribute__((always_inline)) _Bool ipv4_is_fragment(const struct iphdr *ip4)
{
# 73 "/var/lib/cilium/bpf/lib/ipv4.h"
 return ip4->frag_off & (__builtin_constant_p(0x3FFF) ? ((__be16)((__u16)( (((__u16)((0x3FFF)) & (__u16)0x00ffU) << 8) | (((__u16)((0x3FFF)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x3FFF));
}

static inline __attribute__((always_inline)) _Bool ipv4_is_not_first_fragment(const struct iphdr *ip4)
{

 return ip4->frag_off & (__builtin_constant_p(0x1FFF) ? ((__be16)((__u16)( (((__u16)((0x1FFF)) & (__u16)0x00ffU) << 8) | (((__u16)((0x1FFF)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x1FFF));
}


static inline __attribute__((always_inline)) _Bool ipv4_has_l4_header(const struct iphdr *ip4)
{
 return !ipv4_is_not_first_fragment(ip4);
}

static inline __attribute__((always_inline)) _Bool ipv4_is_in_subnet(__be32 addr,
           __be32 subnet, int prefixlen)
{
 return (addr & (__builtin_constant_p(~((1 << (32 - prefixlen)) - 1)) ? ((__be32)((__u32)( (((__u32)((~((1 << (32 - prefixlen)) - 1))) & (__u32)0x000000ffUL) << 24) | (((__u32)((~((1 << (32 - prefixlen)) - 1))) & (__u32)0x0000ff00UL) << 8) | (((__u32)((~((1 << (32 - prefixlen)) - 1))) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((~((1 << (32 - prefixlen)) - 1))) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(~((1 << (32 - prefixlen)) - 1)))) == subnet;
}


static inline __attribute__((always_inline)) int
ipv4_frag_get_l4ports(const struct ipv4_frag_id *frag_id,
        struct ipv4_frag_l4ports *ports)
{
 struct ipv4_frag_l4ports *tmp;

 tmp = map_lookup_elem(&cilium_ipv4_frag_datagrams, frag_id);
 if (!tmp)
  return -175;


 memcpy(ports, tmp, sizeof(*ports));
 return 0;
}

static inline __attribute__((always_inline)) int
ipv4_handle_fragmentation(struct __sk_buff *ctx,
     const struct iphdr *ip4, int l4_off, int ct_dir,
     struct ipv4_frag_l4ports *ports,
     _Bool *has_l4_header)
{
 int ret, dir;
 _Bool is_fragment, not_first_fragment;

 struct ipv4_frag_id frag_id = {
  .daddr = ip4->daddr,
  .saddr = ip4->saddr,
  .id = ip4->id,
  .proto = ip4->protocol,
  .pad = 0,
 };

 is_fragment = ipv4_is_fragment(ip4);
 dir = ct_to_metrics_dir(ct_dir);

 if (__builtin_expect(!!(is_fragment), 0)) {
  update_metrics(ctx_full_len(ctx), dir, 9);

  not_first_fragment = ipv4_is_not_first_fragment(ip4);
  if (has_l4_header)
   *has_l4_header = !not_first_fragment;

  if (__builtin_expect(!!(not_first_fragment), 1))
   return ipv4_frag_get_l4ports(&frag_id, ports);
 }


 ret = skb_load_bytes(ctx, l4_off, ports, 4);
 if (ret < 0)
  return ret;

 if (__builtin_expect(!!(is_fragment), 0)) {



  if (map_update_elem(&cilium_ipv4_frag_datagrams, &frag_id, ports, BPF_ANY))
   update_metrics(ctx_full_len(ctx), dir, 10);




 }

 return 0;
}
# 46 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/icmp6.h" 1
# 47 "/var/lib/cilium/bpf/bpf_host.c" 2


# 1 "/var/lib/cilium/bpf/lib/proxy.h" 1






# 1 "/var/lib/cilium/bpf/lib/conntrack.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/icmpv6.h" 1






struct icmp6hdr {

 __u8 icmp6_type;
 __u8 icmp6_code;
 __sum16 icmp6_cksum;


 union {
  __be32 un_data32[1];
  __be16 un_data16[2];
  __u8 un_data8[4];

  struct icmpv6_echo {
   __be16 identifier;
   __be16 sequence;
  } u_echo;

                struct icmpv6_nd_advt {

                        __u32 reserved:5,
                          override:1,
                          solicited:1,
                          router:1,
     reserved2:24;
# 39 "/var/lib/cilium/bpf/include/linux/icmpv6.h"
                } u_nd_advt;

                struct icmpv6_nd_ra {
   __u8 hop_limit;

   __u8 reserved:3,
     router_pref:2,
     home_agent:1,
     other:1,
     managed:1;
# 59 "/var/lib/cilium/bpf/include/linux/icmpv6.h"
   __be16 rt_lifetime;
                } u_nd_ra;

 } icmp6_dataun;
# 79 "/var/lib/cilium/bpf/include/linux/icmpv6.h"
};
# 149 "/var/lib/cilium/bpf/include/linux/icmpv6.h"
struct icmp6_filter {
 __u32 data[8];
};
# 8 "/var/lib/cilium/bpf/lib/conntrack.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/icmp.h" 1
# 68 "/var/lib/cilium/bpf/include/linux/icmp.h"
struct icmphdr {
  __u8 type;
  __u8 code;
  __sum16 checksum;
  union {
 struct {
  __be16 id;
  __be16 sequence;
 } echo;
 __be32 gateway;
 struct {
  __be16 __unused;
  __be16 mtu;
 } frag;
  } un;
};
# 92 "/var/lib/cilium/bpf/include/linux/icmp.h"
struct icmp_filter {
 __u32 data;
};
# 9 "/var/lib/cilium/bpf/lib/conntrack.h" 2

# 1 "/var/lib/cilium/bpf/include/bpf/verifier.h" 1
# 13 "/var/lib/cilium/bpf/include/bpf/verifier.h"
static inline __attribute__((always_inline)) void relax_verifier(void)
{

       volatile int __attribute__((__unused__)) id = get_smp_processor_id();

}
# 11 "/var/lib/cilium/bpf/lib/conntrack.h" 2






# 1 "/var/lib/cilium/bpf/lib/l4.h" 1






# 1 "/var/lib/cilium/bpf/include/linux/tcp.h" 1
# 22 "/var/lib/cilium/bpf/include/linux/tcp.h"
struct tcphdr {
 __be16 source;
 __be16 dest;
 __be32 seq;
 __be32 ack_seq;

 __u16 res1:4,
  doff:4,
  fin:1,
  syn:1,
  rst:1,
  psh:1,
  ack:1,
  urg:1,
  ece:1,
  cwr:1;
# 52 "/var/lib/cilium/bpf/include/linux/tcp.h"
 __be16 window;
 __sum16 check;
 __be16 urg_ptr;
};






union tcp_word_hdr {
 struct tcphdr hdr;
 __be32 words[5];
};



enum {
 TCP_FLAG_CWR = ((__be32)((__u32)( (((__u32)((0x00800000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00800000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00800000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00800000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_ECE = ((__be32)((__u32)( (((__u32)((0x00400000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00400000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00400000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00400000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_URG = ((__be32)((__u32)( (((__u32)((0x00200000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00200000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00200000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00200000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_ACK = ((__be32)((__u32)( (((__u32)((0x00100000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00100000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00100000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00100000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_PSH = ((__be32)((__u32)( (((__u32)((0x00080000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00080000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00080000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00080000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_RST = ((__be32)((__u32)( (((__u32)((0x00040000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00040000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00040000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00040000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_SYN = ((__be32)((__u32)( (((__u32)((0x00020000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00020000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00020000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00020000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_FLAG_FIN = ((__be32)((__u32)( (((__u32)((0x00010000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x00010000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x00010000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x00010000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_RESERVED_BITS = ((__be32)((__u32)( (((__u32)((0x0F000000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0x0F000000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0x0F000000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0x0F000000)) & (__u32)0xff000000UL) >> 24)))),
 TCP_DATA_OFFSET = ((__be32)((__u32)( (((__u32)((0xF0000000)) & (__u32)0x000000ffUL) << 24) | (((__u32)((0xF0000000)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((0xF0000000)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((0xF0000000)) & (__u32)0xff000000UL) >> 24))))
};
# 8 "/var/lib/cilium/bpf/lib/l4.h" 2
# 1 "/var/lib/cilium/bpf/include/linux/udp.h" 1
# 22 "/var/lib/cilium/bpf/include/linux/udp.h"
struct udphdr {
 __be16 source;
 __be16 dest;
 __be16 len;
 __sum16 check;
};
# 9 "/var/lib/cilium/bpf/lib/l4.h" 2


# 1 "/var/lib/cilium/bpf/lib/csum.h" 1
# 14 "/var/lib/cilium/bpf/lib/csum.h"
struct csum_offset {
 __u16 offset;
 __u16 flags;
};
# 29 "/var/lib/cilium/bpf/lib/csum.h"
static inline __attribute__((always_inline)) void csum_l4_offset_and_flags(__u8 nexthdr,
           struct csum_offset *off)
{
 switch (nexthdr) {
 case IPPROTO_TCP:
  off->offset = (__builtin_offsetof(struct tcphdr, check));
  break;

 case IPPROTO_UDP:
  off->offset = (__builtin_offsetof(struct udphdr, check));
  off->flags = BPF_F_MARK_MANGLED_0;
  break;

 case 58:
  off->offset = __builtin_offsetof(struct icmp6hdr, icmp6_cksum);
  break;

 case IPPROTO_ICMP:
  break;
 }
}
# 60 "/var/lib/cilium/bpf/lib/csum.h"
static inline __attribute__((always_inline)) int csum_l4_replace(struct __sk_buff *ctx, __u64 l4_off,
        const struct csum_offset *csum,
        __be32 from, __be32 to, int flags)
{
 return l4_csum_replace(ctx, l4_off + csum->offset, from, to, flags | csum->flags);
}
# 12 "/var/lib/cilium/bpf/lib/l4.h" 2
# 36 "/var/lib/cilium/bpf/lib/l4.h"
static inline __attribute__((always_inline)) int l4_modify_port(struct __sk_buff *ctx, int l4_off,
       int off, struct csum_offset *csum_off,
       __be16 port, __be16 old_port)
{
 if (csum_l4_replace(ctx, l4_off, csum_off, old_port, port, sizeof(port)) < 0)
  return -154;

 if (skb_store_bytes(ctx, l4_off + off, &port, sizeof(port), 0) < 0)
  return -141;

 return 0;
}

static inline __attribute__((always_inline)) int l4_load_port(struct __sk_buff *ctx, int off,
     __be16 *port)
{
 return skb_load_bytes(ctx, off, port, sizeof(__be16));
}
# 18 "/var/lib/cilium/bpf/lib/conntrack.h" 2
# 1 "/var/lib/cilium/bpf/lib/nat46.h" 1
# 22 "/var/lib/cilium/bpf/lib/nat46.h"
static inline __attribute__((always_inline)) int get_csum_offset(__u8 protocol)
{
 int csum_off;

 switch (protocol) {
 case IPPROTO_TCP:
  csum_off = (__builtin_offsetof(struct tcphdr, check));
  break;
 case IPPROTO_UDP:
  csum_off = (__builtin_offsetof(struct udphdr, check));
  break;
 case IPPROTO_ICMP:
  csum_off = (__builtin_offsetof(struct icmphdr, checksum));
  break;
 case 58:
  csum_off = (__builtin_offsetof(struct icmp6hdr, icmp6_cksum));
  break;
 default:
  return -142;
 }

 return csum_off;
}

static inline __attribute__((always_inline)) int icmp4_to_icmp6(struct __sk_buff *ctx, int nh_off)
{
 struct icmphdr icmp4 __attribute__((aligned(8)));
 struct icmp6hdr icmp6 __attribute__((aligned(8))) = {};

 if (skb_load_bytes(ctx, nh_off, &icmp4, sizeof(icmp4)) < 0)
  return -134;

 icmp6.icmp6_cksum = icmp4.checksum;

 switch (icmp4.type) {
 case 8:
  icmp6.icmp6_type = 128;
  icmp6.icmp6_dataun.u_echo.identifier = icmp4.un.echo.id;
  icmp6.icmp6_dataun.u_echo.sequence = icmp4.un.echo.sequence;
  break;
 case 0:
  icmp6.icmp6_type = 129;
  icmp6.icmp6_dataun.u_echo.identifier = icmp4.un.echo.id;
  icmp6.icmp6_dataun.u_echo.sequence = icmp4.un.echo.sequence;
  break;
 case 3:
  icmp6.icmp6_type = 1;
  switch (icmp4.code) {
  case 0:
  case 1:
   icmp6.icmp6_code = 0;
   break;
  case 2:
   icmp6.icmp6_type = 4;
   icmp6.icmp6_code = 1;
   icmp6.icmp6_dataun.un_data32[0] = 6;
   break;
  case 3:
   icmp6.icmp6_code = 4;
   break;
  case 4:
   icmp6.icmp6_type = 2;
   icmp6.icmp6_code = 0;

   if (icmp4.un.frag.mtu)
    icmp6.icmp6_dataun.un_data32[0] = (__builtin_constant_p((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu))) ? ((__be32)((__u32)( (((__u32)(((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu)))) & (__u32)0x000000ffUL) << 24) | (((__u32)(((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu)))) & (__u32)0x0000ff00UL) << 8) | (((__u32)(((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu)))) & (__u32)0x00ff0000UL) >> 8) | (((__u32)(((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu)))) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32((__builtin_constant_p(icmp4.un.frag.mtu) ? ((__u16)( (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(icmp4.un.frag.mtu)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(icmp4.un.frag.mtu))));
   else
    icmp6.icmp6_dataun.un_data32[0] = (__builtin_constant_p(1500) ? ((__be32)((__u32)( (((__u32)((1500)) & (__u32)0x000000ffUL) << 24) | (((__u32)((1500)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((1500)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((1500)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(1500));
   break;
  case 5:
   icmp6.icmp6_code = 0;
   break;
  case 6:
  case 7:
  case 8:
  case 11:
  case 12:
   icmp6.icmp6_code = 0;
   break;
  case 9:
  case 10:
  case 13:
   icmp6.icmp6_code = 1;
   break;
  default:
   return -143;
  }
  break;
 case 11:
  icmp6.icmp6_type = 3;
  break;
 case 12:
  icmp6.icmp6_type = 4;

  icmp6.icmp6_dataun.un_data32[0] = 6;
  break;
 default:
  return -144;
 }

 if (skb_store_bytes(ctx, nh_off, &icmp6, sizeof(icmp6), 0) < 0)
  return -141;

 icmp4.checksum = 0;
 icmp6.icmp6_cksum = 0;
 return csum_diff(&icmp4, sizeof(icmp4), &icmp6, sizeof(icmp6), 0);
}

static inline __attribute__((always_inline)) int icmp6_to_icmp4(struct __sk_buff *ctx, int nh_off)
{
 struct icmphdr icmp4 __attribute__((aligned(8))) = {};
 struct icmp6hdr icmp6 __attribute__((aligned(8)));

 if (skb_load_bytes(ctx, nh_off, &icmp6, sizeof(icmp6)) < 0)
  return -134;

 icmp4.checksum = icmp6.icmp6_cksum;

 switch (icmp6.icmp6_type) {
 case 128:
  icmp4.type = 8;
  icmp4.un.echo.id = icmp6.icmp6_dataun.u_echo.identifier;
  icmp4.un.echo.sequence = icmp6.icmp6_dataun.u_echo.sequence;
  break;
 case 129:
  icmp4.type = 0;
  icmp4.un.echo.id = icmp6.icmp6_dataun.u_echo.identifier;
  icmp4.un.echo.sequence = icmp6.icmp6_dataun.u_echo.sequence;
  break;
 case 1:
  icmp4.type = 3;
  switch (icmp6.icmp6_code) {
  case 0:
  case 2:
  case 3:
   icmp4.code = 1;
   break;
  case 1:
   icmp4.code = 10;
   break;
  case 4:
   icmp4.code = 3;
   break;
  default:
   return -145;
  }
  break;
 case 2:
  icmp4.type = 3;
  icmp4.code = 4;

  if (icmp6.icmp6_dataun.un_data32[0])
   icmp4.un.frag.mtu = (__builtin_constant_p((__builtin_constant_p(icmp6.icmp6_dataun.un_data32[0]) ? ((__u32)( (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(icmp6.icmp6_dataun.un_data32[0]))) ? ((__be16)((__u16)( (((__u16)(((__builtin_constant_p(icmp6.icmp6_dataun.un_data32[0]) ? ((__u32)( (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(icmp6.icmp6_dataun.un_data32[0])))) & (__u16)0x00ffU) << 8) | (((__u16)(((__builtin_constant_p(icmp6.icmp6_dataun.un_data32[0]) ? ((__u32)( (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(icmp6.icmp6_dataun.un_data32[0])))) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16((__builtin_constant_p(icmp6.icmp6_dataun.un_data32[0]) ? ((__u32)( (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(icmp6.icmp6_dataun.un_data32[0])) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(icmp6.icmp6_dataun.un_data32[0]))));
  else
   icmp4.un.frag.mtu = (__builtin_constant_p(1500) ? ((__be16)((__u16)( (((__u16)((1500)) & (__u16)0x00ffU) << 8) | (((__u16)((1500)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(1500));
  break;
 case 3:
  icmp4.type = 11;
  icmp4.code = icmp6.icmp6_code;
  break;
 case 4:
  switch (icmp6.icmp6_code) {
  case 0:
   icmp4.type = 12;
   icmp4.code = 0;
   break;
  case 1:
   icmp4.type = 3;
   icmp4.code = 2;
   break;
  default:
   return -145;
  }
  break;
 default:
  return -146;
 }

 if (skb_store_bytes(ctx, nh_off, &icmp4, sizeof(icmp4), 0) < 0)
  return -141;

 icmp4.checksum = 0;
 icmp6.icmp6_cksum = 0;
 return csum_diff(&icmp6, sizeof(icmp6), &icmp4, sizeof(icmp4), 0);
}

static inline __attribute__((always_inline)) int ipv6_prefix_match(const struct in6_addr *addr,
          const union v6addr *v6prefix)
{
 if (addr->in6_u.u6_addr32[0] == v6prefix->p1 &&
     addr->in6_u.u6_addr32[1] == v6prefix->p2 &&
     addr->in6_u.u6_addr32[2] == v6prefix->p3)
  return 1;
 else
  return 0;
}







static inline __attribute__((always_inline)) int ipv4_to_ipv6(struct __sk_buff *ctx, struct iphdr *ip4,
     int nh_off,
     const union v6addr *v6_dst)
{
 struct ipv6hdr v6 = {};
 struct iphdr v4;
 int csum_off;
 __be32 csum;
 __be16 v4hdr_len;
 __be16 protocol = (__builtin_constant_p(0x86DD) ? ((__be16)((__u16)( (((__u16)((0x86DD)) & (__u16)0x00ffU) << 8) | (((__u16)((0x86DD)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x86DD));
 __u64 csum_flags = (1ULL << 4);
 union v6addr nat46_prefix = { .addr = { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xff, 0xff, 0x0, 0x0, 0x0, 0x0 } };

 if (skb_load_bytes(ctx, nh_off, &v4, sizeof(v4)) < 0)
  return -134;

 if (ipv4_hdrlen(ip4) != sizeof(v4))
  return -156;


 v6.version = 0x6;
 v6.saddr.in6_u.u6_addr32[0] = nat46_prefix.p1;
 v6.saddr.in6_u.u6_addr32[1] = nat46_prefix.p2;
 v6.saddr.in6_u.u6_addr32[2] = nat46_prefix.p3;
 v6.saddr.in6_u.u6_addr32[3] = v4.saddr;

 if (v6_dst) {
  v6.daddr.in6_u.u6_addr32[0] = v6_dst->p1;
  v6.daddr.in6_u.u6_addr32[1] = v6_dst->p2;
  v6.daddr.in6_u.u6_addr32[2] = v6_dst->p3;
  v6.daddr.in6_u.u6_addr32[3] = v6_dst->p4;
 } else {
  v6.daddr.in6_u.u6_addr32[0] = nat46_prefix.p1;
  v6.daddr.in6_u.u6_addr32[1] = nat46_prefix.p2;
  v6.daddr.in6_u.u6_addr32[2] = nat46_prefix.p3;
  v6.daddr.in6_u.u6_addr32[3] = (__builtin_constant_p(((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF)) ? ((__be32)((__u32)( (((__u32)((((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF))) & (__u32)0x000000ffUL) << 24) | (((__u32)((((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF))) & (__u32)0x0000ff00UL) << 8) | (((__u32)((((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF))) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF))) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(((__builtin_constant_p(nat46_prefix.p4) ? ((__u32)( (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(nat46_prefix.p4)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(nat46_prefix.p4)) & 0xFFFF0000) | ((__builtin_constant_p(v4.daddr) ? ((__u32)( (((__u32)((__be32)(v4.daddr)) & (__u32)0x000000ffUL) << 24) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((__be32)(v4.daddr)) & (__u32)0xff000000UL) >> 24))) : __builtin_bswap32(v4.daddr)) & 0xFFFF)));

 }

 if (v4.protocol == IPPROTO_ICMP)
  v6.nexthdr = 58;
 else
  v6.nexthdr = v4.protocol;
 v6.hop_limit = v4.ttl;
 v4hdr_len = (v4.ihl << 2);
 v6.payload_len = (__builtin_constant_p((__builtin_constant_p(v4.tot_len) ? ((__u16)( (((__u16)((__be16)(v4.tot_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v4.tot_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v4.tot_len)) - v4hdr_len) ? ((__be16)((__u16)( (((__u16)(((__builtin_constant_p(v4.tot_len) ? ((__u16)( (((__u16)((__be16)(v4.tot_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v4.tot_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v4.tot_len)) - v4hdr_len)) & (__u16)0x00ffU) << 8) | (((__u16)(((__builtin_constant_p(v4.tot_len) ? ((__u16)( (((__u16)((__be16)(v4.tot_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v4.tot_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v4.tot_len)) - v4hdr_len)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16((__builtin_constant_p(v4.tot_len) ? ((__u16)( (((__u16)((__be16)(v4.tot_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v4.tot_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v4.tot_len)) - v4hdr_len));

 if (skb_change_proto(ctx, (__builtin_constant_p(0x86DD) ? ((__be16)((__u16)( (((__u16)((0x86DD)) & (__u16)0x00ffU) << 8) | (((__u16)((0x86DD)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x86DD)), 0) < 0) {



  return -141;
 }

 if (skb_store_bytes(ctx, nh_off, &v6, sizeof(v6), 0) < 0 ||
     skb_store_bytes(ctx, nh_off - 2, &protocol, 2, 0) < 0)
  return -141;

 if (v4.protocol == IPPROTO_ICMP) {
  csum = icmp4_to_icmp6(ctx, nh_off + sizeof(v6));
  csum = ipv6_pseudohdr_checksum(&v6, 58,
            (__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)), csum);
 } else {
  csum = 0;
  csum = csum_diff(&v4.saddr, 4, &v6.saddr, 16, csum);
  csum = csum_diff(&v4.daddr, 4, &v6.daddr, 16, csum);
  if (v4.protocol == IPPROTO_UDP)
   csum_flags |= BPF_F_MARK_MANGLED_0;
 }






 csum_off = get_csum_offset(v6.nexthdr);
 if (csum_off < 0)
  return csum_off;
 csum_off += sizeof(struct ipv6hdr);

 if (l4_csum_replace(ctx, nh_off + csum_off, 0, csum, csum_flags) < 0)
  return -154;




 return 0;
}







static inline __attribute__((always_inline)) int ipv6_to_ipv4(struct __sk_buff *ctx, int nh_off,
     __be32 saddr)
{
 struct ipv6hdr v6;
 struct iphdr v4 = {};
 int csum_off;
 __be32 csum = 0;
 __be16 protocol = (__builtin_constant_p(0x0800) ? ((__be16)((__u16)( (((__u16)((0x0800)) & (__u16)0x00ffU) << 8) | (((__u16)((0x0800)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x0800));
 __u64 csum_flags = (1ULL << 4);

 if (skb_load_bytes(ctx, nh_off, &v6, sizeof(v6)) < 0)
  return -134;


 if (ipv6_hdrlen(ctx, nh_off, &v6.nexthdr) != sizeof(v6))
  return -156;


 v4.ihl = 0x5;
 v4.version = 0x4;
 v4.saddr = saddr;
 v4.daddr = v6.daddr.in6_u.u6_addr32[3];
 if (v6.nexthdr == 58)
  v4.protocol = IPPROTO_ICMP;
 else
  v4.protocol = v6.nexthdr;
 v4.ttl = v6.hop_limit;
 v4.tot_len = (__builtin_constant_p((__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)) + sizeof(v4)) ? ((__be16)((__u16)( (((__u16)(((__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)) + sizeof(v4))) & (__u16)0x00ffU) << 8) | (((__u16)(((__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)) + sizeof(v4))) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16((__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)) + sizeof(v4)));
 csum_off = __builtin_offsetof(struct iphdr, check);
 csum = csum_diff(((void *)0), 0, &v4, sizeof(v4), csum);

 if (skb_change_proto(ctx, (__builtin_constant_p(0x0800) ? ((__be16)((__u16)( (((__u16)((0x0800)) & (__u16)0x00ffU) << 8) | (((__u16)((0x0800)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x0800)), 0) < 0) {



  return -141;
 }

 if (skb_store_bytes(ctx, nh_off, &v4, sizeof(v4), 0) < 0 ||
     skb_store_bytes(ctx, nh_off - 2, &protocol, 2, 0) < 0)
  return -141;

 if (l3_csum_replace(ctx, nh_off + csum_off, 0, csum, 0) < 0)
  return -153;

 if (v6.nexthdr == 58) {
  __be32 csum1 = 0;

  csum = icmp6_to_icmp4(ctx, nh_off + sizeof(v4));
  csum1 = ipv6_pseudohdr_checksum(&v6, 58,
      (__builtin_constant_p(v6.payload_len) ? ((__u16)( (((__u16)((__be16)(v6.payload_len)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(v6.payload_len)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(v6.payload_len)), 0);
  csum = csum - csum1;
 } else {
  csum = 0;
  csum = csum_diff(&v6.saddr, 16, &v4.saddr, 4, csum);
  csum = csum_diff(&v6.daddr, 16, &v4.daddr, 4, csum);
  if (v4.protocol == IPPROTO_UDP)
   csum_flags |= BPF_F_MARK_MANGLED_0;
 }





 csum_off = get_csum_offset(v4.protocol);
 if (csum_off < 0)
  return csum_off;
 csum_off += sizeof(struct iphdr);

 if (l4_csum_replace(ctx, nh_off + csum_off, 0, csum, csum_flags) < 0)
  return -154;





 return 0;
}
# 19 "/var/lib/cilium/bpf/lib/conntrack.h" 2
# 1 "/var/lib/cilium/bpf/lib/signal.h" 1








struct bpf_elf_map __attribute__((section("maps"), used)) cilium_signals = {
 .type = BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 .size_key = sizeof(__u32),
 .size_value = sizeof(__u32),
 .pinning = 2,
 .max_elem = 8,
};

enum {
 SIGNAL_NAT_FILL_UP = 0,
 SIGNAL_CT_FILL_UP,
};

enum {
 SIGNAL_PROTO_V4 = 0,
 SIGNAL_PROTO_V6,
};

struct signal_msg {
 __u32 signal_nr;
 union {
  struct {
   __u32 proto;
  };
 };
};

static inline __attribute__((always_inline)) void send_signal(struct __sk_buff *ctx,
     struct signal_msg *msg)
{
 skb_event_output(ctx, &cilium_signals, BPF_F_CURRENT_CPU,
    msg, sizeof(*msg));
}

static inline __attribute__((always_inline)) void send_signal_nat_fill_up(struct __sk_buff *ctx,
          __u32 proto)
{
 struct signal_msg msg = {
  .signal_nr = SIGNAL_NAT_FILL_UP,
  .proto = proto,
 };

 send_signal(ctx, &msg);
}

static inline __attribute__((always_inline)) void send_signal_ct_fill_up(struct __sk_buff *ctx,
         __u32 proto)
{
 struct signal_msg msg = {
  .signal_nr = SIGNAL_CT_FILL_UP,
  .proto = proto,
 };

 send_signal(ctx, &msg);
}
# 20 "/var/lib/cilium/bpf/lib/conntrack.h" 2


enum {
 ACTION_UNSPEC,
 ACTION_CREATE,
 ACTION_CLOSE,
};
# 37 "/var/lib/cilium/bpf/lib/conntrack.h"
static inline __attribute__((always_inline)) _Bool conn_is_dns(__u16 dport)
{
 return dport == (__builtin_constant_p(53) ? ((__be16)((__u16)( (((__u16)((53)) & (__u16)0x00ffU) << 8) | (((__u16)((53)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(53));
}

static inline __attribute__((always_inline)) _Bool ct_entry_seen_both_syns(const struct ct_entry *entry)
{
 _Bool rx_syn = entry->rx_flags_seen & TCP_FLAG_SYN;
 _Bool tx_syn = entry->tx_flags_seen & TCP_FLAG_SYN;

 return rx_syn && tx_syn;
}

union tcp_flags {
 struct {
  __u8 upper_bits;
  __u8 lower_bits;
  __u16 pad;
 };
 __u32 value;
};
# 78 "/var/lib/cilium/bpf/lib/conntrack.h"
static inline __attribute__((always_inline)) __u32 __ct_update_timeout(struct ct_entry *entry,
       __u32 lifetime, int dir,
       union tcp_flags flags,
       __u8 report_mask)
{
 __u32 now = ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
 __u8 accumulated_flags;
 __u8 seen_flags = flags.lower_bits & report_mask;
 __u32 last_report;


 ({ typeof(entry->lifetime) __val = (now + lifetime); (*(volatile typeof(entry->lifetime) *)&entry->lifetime) = (__val); bpf_barrier(); __val; });

 if (dir == 1) {
  accumulated_flags = ({ typeof(entry->rx_flags_seen) __val = (*(volatile typeof(entry->rx_flags_seen) *)&entry->rx_flags_seen); bpf_barrier(); __val; });
  last_report = ({ typeof(entry->last_rx_report) __val = (*(volatile typeof(entry->last_rx_report) *)&entry->last_rx_report); bpf_barrier(); __val; });
 } else {
  accumulated_flags = ({ typeof(entry->tx_flags_seen) __val = (*(volatile typeof(entry->tx_flags_seen) *)&entry->tx_flags_seen); bpf_barrier(); __val; });
  last_report = ({ typeof(entry->last_tx_report) __val = (*(volatile typeof(entry->last_tx_report) *)&entry->last_tx_report); bpf_barrier(); __val; });
 }
 seen_flags |= accumulated_flags;
# 130 "/var/lib/cilium/bpf/lib/conntrack.h"
 if (last_report + (5) < now ||
     accumulated_flags != seen_flags) {

  if (dir == 1) {
   ({ typeof(entry->rx_flags_seen) __val = (seen_flags); (*(volatile typeof(entry->rx_flags_seen) *)&entry->rx_flags_seen) = (__val); bpf_barrier(); __val; });
   ({ typeof(entry->last_rx_report) __val = (now); (*(volatile typeof(entry->last_rx_report) *)&entry->last_rx_report) = (__val); bpf_barrier(); __val; });
  } else {
   ({ typeof(entry->tx_flags_seen) __val = (seen_flags); (*(volatile typeof(entry->tx_flags_seen) *)&entry->tx_flags_seen) = (__val); bpf_barrier(); __val; });
   ({ typeof(entry->last_tx_report) __val = (now); (*(volatile typeof(entry->last_tx_report) *)&entry->last_tx_report) = (__val); bpf_barrier(); __val; });
  }
  return 128ULL;
 }
 return 0;
}







static inline __attribute__((always_inline)) __u32 ct_update_timeout(struct ct_entry *entry,
            _Bool tcp, int dir,
            union tcp_flags seen_flags)
{
 __u32 lifetime = dir == 2 ?
    (60) :
    (60);
 _Bool syn = seen_flags.value & TCP_FLAG_SYN;

 if (tcp) {
  entry->seen_non_syn |= !syn;
  if (entry->seen_non_syn) {
   lifetime = dir == 2 ?
       (21600) :
       (21600);
  } else {
   lifetime = (60);
  }
 }

 return __ct_update_timeout(entry, lifetime, dir, seen_flags,
       0x00ff);
}

static inline __attribute__((always_inline)) void ct_reset_closing(struct ct_entry *entry)
{
 entry->rx_closing = 0;
 entry->tx_closing = 0;
}

static inline __attribute__((always_inline)) _Bool ct_entry_alive(const struct ct_entry *entry)
{
 return !entry->rx_closing || !entry->tx_closing;
}


static inline __attribute__((always_inline)) _Bool __ct_entry_keep_alive(const void *map,
        const void *tuple)
{
 struct ct_entry *entry;


 entry = map_lookup_elem(map, tuple);
 if (entry) {
  if (entry->node_port) {

   __u32 lifetime = (entry->seen_non_syn ?
       (21600) :
       (60)) +
      ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
   ({ typeof(entry->lifetime) __val = (lifetime); (*(volatile typeof(entry->lifetime) *)&entry->lifetime) = (__val); bpf_barrier(); __val; });

   if (!ct_entry_alive(entry))
    ct_reset_closing(entry);
  }
  return true;
 }
 return false;
}

static inline __attribute__((always_inline)) __u8 __ct_lookup(const void *map, struct __sk_buff *ctx,
     const void *tuple, int action, int dir,
     struct ct_state *ct_state,
     _Bool is_tcp, union tcp_flags seen_flags,
     __u32 *monitor)
{
 struct ct_entry *entry;
 int reopen;

 relax_verifier();

 entry = map_lookup_elem(map, tuple);
 if (entry) {
  cilium_dbg(ctx, DBG_CT_MATCH, entry->lifetime, entry->rev_nat_index);
  if (ct_entry_alive(entry))
   *monitor = ct_update_timeout(entry, is_tcp, dir, seen_flags);
  if (ct_state) {
   ct_state->rev_nat_index = entry->rev_nat_index;
   ct_state->loopback = entry->lb_loopback;
   ct_state->node_port = entry->node_port;
   ct_state->ifindex = entry->ifindex;
   ct_state->dsr = entry->dsr;
   ct_state->proxy_redirect = entry->proxy_redirect;

   if (dir == 2)
    ct_state->backend_id = entry->rx_bytes;
  }
# 246 "/var/lib/cilium/bpf/lib/conntrack.h"
  if (dir == 1) {
   __sync_fetch_and_add(&entry->rx_packets, 1);
   __sync_fetch_and_add(&entry->rx_bytes, ctx_full_len(ctx));
  } else if (dir == 0) {
   __sync_fetch_and_add(&entry->tx_packets, 1);
   __sync_fetch_and_add(&entry->tx_bytes, ctx_full_len(ctx));
  }

  switch (action) {
  case ACTION_CREATE:
   reopen = entry->rx_closing | entry->tx_closing;
   reopen |= seen_flags.value & TCP_FLAG_SYN;
   if (__builtin_expect(!!(reopen == (TCP_FLAG_SYN|0x1)), 0)) {
    ct_reset_closing(entry);
    *monitor = ct_update_timeout(entry, is_tcp, dir, seen_flags);
    return CT_REOPENED;
   }
   break;

  case ACTION_CLOSE:





   if (!ct_entry_seen_both_syns(entry) &&
       (seen_flags.value & TCP_FLAG_RST) &&
       dir != 2) {
    entry->rx_closing = 1;
    entry->tx_closing = 1;
   } else if (dir == 1) {
    entry->rx_closing = 1;
   } else {
    entry->tx_closing = 1;
   }

   *monitor = 128ULL;
   if (ct_entry_alive(entry))
    break;
   __ct_update_timeout(entry, (10),
         dir, seen_flags, 0x00ff);
   break;
  }

  return CT_ESTABLISHED;
 }

 *monitor = 128ULL;
 return CT_NEW;
}

static inline __attribute__((always_inline)) int
ipv6_extract_tuple(struct __sk_buff *ctx, struct ipv6_ct_tuple *tuple,
     int *l4_off)
{
 int ret, l3_off = 14;
 void *data, *data_end;
 struct ipv6hdr *ip6;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip6, sizeof(**&ip6), false))
  return -134;

 tuple->nexthdr = ip6->nexthdr;
 ipv6_addr_copy(&tuple->daddr, (union v6addr *)&ip6->daddr);
 ipv6_addr_copy(&tuple->saddr, (union v6addr *)&ip6->saddr);

 ret = ipv6_hdrlen(ctx, l3_off, &tuple->nexthdr);
 if (ret < 0)
  return ret;

 if (__builtin_expect(!!(tuple->nexthdr != IPPROTO_TCP && tuple->nexthdr != IPPROTO_UDP), 0))

  return -137;

 if (ret < 0)
  return ret;

 *l4_off = l3_off + ret;
 return 0;
}

static inline __attribute__((always_inline)) void ct_flip_tuple_dir6(struct ipv6_ct_tuple *tuple)
{
 if (tuple->flags & 1)
  tuple->flags &= ~1;
 else
  tuple->flags |= 1;
}

static inline __attribute__((always_inline)) void
__ipv6_ct_tuple_reverse(struct ipv6_ct_tuple *tuple)
{
 union v6addr tmp_addr = {};
 __be16 tmp;

 ipv6_addr_copy(&tmp_addr, &tuple->saddr);
 ipv6_addr_copy(&tuple->saddr, &tuple->daddr);
 ipv6_addr_copy(&tuple->daddr, &tmp_addr);

 tmp = tuple->sport;
 tuple->sport = tuple->dport;
 tuple->dport = tmp;
}

static inline __attribute__((always_inline)) void
ipv6_ct_tuple_reverse(struct ipv6_ct_tuple *tuple)
{
 __ipv6_ct_tuple_reverse(tuple);
 ct_flip_tuple_dir6(tuple);
}


static inline __attribute__((always_inline)) int ct_lookup6(const void *map,
          struct ipv6_ct_tuple *tuple,
          struct __sk_buff *ctx, int l4_off,
          int dir, struct ct_state *ct_state,
          __u32 *monitor)
{
 int ret = CT_NEW, action = ACTION_UNSPEC;
 _Bool is_tcp = tuple->nexthdr == IPPROTO_TCP;
 union tcp_flags tcp_flags = { .value = 0 };
# 375 "/var/lib/cilium/bpf/lib/conntrack.h"
 if (dir == 1)
  tuple->flags = 0;
 else if (dir == 0)
  tuple->flags = 1;
 else if (dir == 2)
  tuple->flags = 4;
 else
  return -135;

 switch (tuple->nexthdr) {
 case 58:
  if (1) {
   __be16 identifier = 0;
   __u8 type;

   if (skb_load_bytes(ctx, l4_off, &type, 1) < 0)
    return -135;
   if ((type == 128 || type == 129) &&
        skb_load_bytes(ctx, l4_off + __builtin_offsetof(struct icmp6hdr, icmp6_dataun.u_echo.identifier),

         &identifier, 2) < 0)
    return -135;

   tuple->sport = 0;
   tuple->dport = 0;

   switch (type) {
   case 1:
   case 2:
   case 3:
   case 4:
    tuple->flags |= 2;
    break;

   case 129:
    tuple->sport = identifier;
    break;

   case 128:
    tuple->dport = identifier;

   default:
    action = ACTION_CREATE;
    break;
   }
  }
  break;

 case IPPROTO_TCP:
  if (1) {
   if (skb_load_bytes(ctx, l4_off + 12, &tcp_flags, 2) < 0)
    return -135;

   if (__builtin_expect(!!(tcp_flags.value & (TCP_FLAG_RST|TCP_FLAG_FIN)), 0))
    action = ACTION_CLOSE;
   else
    action = ACTION_CREATE;
  }


  if (skb_load_bytes(ctx, l4_off, &tuple->dport, 4) < 0)
   return -135;
  break;

 case IPPROTO_UDP:

  if (skb_load_bytes(ctx, l4_off, &tuple->dport, 4) < 0)
   return -135;

  action = ACTION_CREATE;
  break;

 default:

  return -137;
 }






 cilium_dbg3(ctx, DBG_CT_LOOKUP6_1, (__u32) tuple->saddr.p4, (__u32) tuple->daddr.p4,
        ((__builtin_constant_p(tuple->sport) ? ((__u16)( (((__u16)((__be16)(tuple->sport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->sport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->sport)) << 16) | (__builtin_constant_p(tuple->dport) ? ((__u16)( (((__u16)((__be16)(tuple->dport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->dport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->dport)));
 cilium_dbg3(ctx, DBG_CT_LOOKUP6_2, (tuple->nexthdr << 8) | tuple->flags, 0, 0);
 ret = __ct_lookup(map, ctx, tuple, action, dir, ct_state, is_tcp,
     tcp_flags, monitor);
 if (ret != CT_NEW) {
  if (__builtin_expect(!!(ret == CT_ESTABLISHED || ret == CT_REOPENED), 1)) {
   if (__builtin_expect(!!(tuple->flags & 2), 0))
    ret = CT_RELATED;
   else
    ret = CT_REPLY;
  }
  goto out;
 }


 if (dir != 2) {
  ipv6_ct_tuple_reverse(tuple);
  ret = __ct_lookup(map, ctx, tuple, action, dir, ct_state,
      is_tcp, tcp_flags, monitor);
 }




out:
 cilium_dbg(ctx, DBG_CT_VERDICT, ret < 0 ? -ret : ret, ct_state->rev_nat_index);
 if (conn_is_dns(tuple->dport))
  *monitor = 1500;
 return ret;
}

static inline __attribute__((always_inline)) int
ipv4_extract_tuple(struct __sk_buff *ctx, struct ipv4_ct_tuple *tuple,
     int *l4_off)
{
 int l3_off = 14;
 void *data, *data_end;
 struct iphdr *ip4;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;

 tuple->nexthdr = ip4->protocol;

 if (__builtin_expect(!!(tuple->nexthdr != IPPROTO_TCP && tuple->nexthdr != IPPROTO_UDP), 0))

  return -137;

 tuple->daddr = ip4->daddr;
 tuple->saddr = ip4->saddr;

 *l4_off = l3_off + ipv4_hdrlen(ip4);
 return 0;
}

static inline __attribute__((always_inline)) void ct_flip_tuple_dir4(struct ipv4_ct_tuple *tuple)
{
 if (tuple->flags & 1)
  tuple->flags &= ~1;
 else
  tuple->flags |= 1;
}

static inline __attribute__((always_inline)) void
__ipv4_ct_tuple_reverse(struct ipv4_ct_tuple *tuple)
{
 __be32 tmp_addr = tuple->saddr;
 __be16 tmp;

 tuple->saddr = tuple->daddr;
 tuple->daddr = tmp_addr;

 tmp = tuple->sport;
 tuple->sport = tuple->dport;
 tuple->dport = tmp;
}

static inline __attribute__((always_inline)) void
ipv4_ct_tuple_reverse(struct ipv4_ct_tuple *tuple)
{
 __ipv4_ct_tuple_reverse(tuple);
 ct_flip_tuple_dir4(tuple);
}

static inline __attribute__((always_inline)) int ipv4_ct_extract_l4_ports(struct __sk_buff *ctx,
          int off,
          int dir __attribute__((__unused__)),
          struct ipv4_ct_tuple *tuple,
          _Bool *has_l4_header __attribute__((__unused__)))
{

 void *data, *data_end;
 struct iphdr *ip4;




 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -135;

 return ipv4_handle_fragmentation(ctx, ip4, off, dir,
        (struct ipv4_frag_l4ports *)&tuple->dport,
        has_l4_header);






 return 0;
}

static inline __attribute__((always_inline)) void ct4_cilium_dbg_tuple(struct __sk_buff *ctx, __u8 type,
       const struct ipv4_ct_tuple *tuple,
       __u32 rev_nat_index, int dir)
{
 __be32 addr = (dir == 1) ? tuple->saddr : tuple->daddr;

 cilium_dbg(ctx, type, addr, rev_nat_index);
}


static inline __attribute__((always_inline)) int ct_lookup4(const void *map,
          struct ipv4_ct_tuple *tuple,
          struct __sk_buff *ctx, int off, int dir,
          struct ct_state *ct_state, __u32 *monitor)
{
 int err, ret = CT_NEW, action = ACTION_UNSPEC;
 _Bool is_tcp = tuple->nexthdr == IPPROTO_TCP,
      has_l4_header = true;
 union tcp_flags tcp_flags = { .value = 0 };
# 597 "/var/lib/cilium/bpf/lib/conntrack.h"
 if (dir == 1)
  tuple->flags = 0;
 else if (dir == 0)
  tuple->flags = 1;
 else if (dir == 2)
  tuple->flags = 4;
 else
  return -135;

 switch (tuple->nexthdr) {
 case IPPROTO_ICMP:
  if (1) {
   __be16 identifier = 0;
   __u8 type;

   if (skb_load_bytes(ctx, off, &type, 1) < 0)
    return -135;
   if ((type == 8 || type == 0) &&
        skb_load_bytes(ctx, off + __builtin_offsetof(struct icmphdr, un.echo.id),
         &identifier, 2) < 0)
    return -135;

   tuple->sport = 0;
   tuple->dport = 0;

   switch (type) {
   case 3:
   case 11:
   case 12:
    tuple->flags |= 2;
    break;

   case 0:
    tuple->sport = identifier;
    break;
   case 8:
    tuple->dport = identifier;

   default:
    action = ACTION_CREATE;
    break;
   }
  }
  break;

 case IPPROTO_TCP:
  err = ipv4_ct_extract_l4_ports(ctx, off, dir, tuple, &has_l4_header);
  if (err < 0)
   return err;

  action = ACTION_CREATE;

  if (has_l4_header) {
   if (skb_load_bytes(ctx, off + 12, &tcp_flags, 2) < 0)
    return -135;

   if (__builtin_expect(!!(tcp_flags.value & (TCP_FLAG_RST|TCP_FLAG_FIN)), 0))
    action = ACTION_CLOSE;
  }
  break;

 case IPPROTO_UDP:
  err = ipv4_ct_extract_l4_ports(ctx, off, dir, tuple, ((void *)0));
  if (err < 0)
   return err;

  action = ACTION_CREATE;
  break;

 default:

  return -137;
 }






 cilium_dbg3(ctx, DBG_CT_LOOKUP4_1, tuple->saddr, tuple->daddr,
        ((__builtin_constant_p(tuple->sport) ? ((__u16)( (((__u16)((__be16)(tuple->sport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->sport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->sport)) << 16) | (__builtin_constant_p(tuple->dport) ? ((__u16)( (((__u16)((__be16)(tuple->dport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->dport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->dport)));
 cilium_dbg3(ctx, DBG_CT_LOOKUP4_2, (tuple->nexthdr << 8) | tuple->flags, 0, 0);

 ret = __ct_lookup(map, ctx, tuple, action, dir, ct_state, is_tcp,
     tcp_flags, monitor);
 if (ret != CT_NEW) {
  if (__builtin_expect(!!(ret == CT_ESTABLISHED || ret == CT_REOPENED), 1)) {
   if (__builtin_expect(!!(tuple->flags & 2), 0))
    ret = CT_RELATED;
   else
    ret = CT_REPLY;
  }
  goto out;
 }

 relax_verifier();


 if (dir != 2) {
  ipv4_ct_tuple_reverse(tuple);
  ret = __ct_lookup(map, ctx, tuple, action, dir, ct_state,
      is_tcp, tcp_flags, monitor);
 }
out:
 cilium_dbg(ctx, DBG_CT_VERDICT, ret < 0 ? -ret : ret, ct_state->rev_nat_index);
 if (conn_is_dns(tuple->dport))
  *monitor = 1500;
 return ret;
}

static inline __attribute__((always_inline)) void
ct_update6_backend_id(const void *map, const struct ipv6_ct_tuple *tuple,
        const struct ct_state *state)
{
 struct ct_entry *entry;

 entry = map_lookup_elem(map, tuple);
 if (!entry)
  return;


 entry->rx_bytes = state->backend_id;
}

static inline __attribute__((always_inline)) void
ct_update6_rev_nat_index(const void *map, const struct ipv6_ct_tuple *tuple,
    const struct ct_state *state)
{
 struct ct_entry *entry;

 entry = map_lookup_elem(map, tuple);
 if (!entry)
  return;

 entry->rev_nat_index = state->rev_nat_index;
}


static inline __attribute__((always_inline)) int ct_create6(const void *map_main, const void *map_related,
          struct ipv6_ct_tuple *tuple,
          struct __sk_buff *ctx, const int dir,
          const struct ct_state *ct_state,
          _Bool proxy_redirect)
{

 struct ct_entry entry = { };
 _Bool is_tcp = tuple->nexthdr == IPPROTO_TCP;
 union tcp_flags seen_flags = { .value = 0 };




 entry.proxy_redirect = proxy_redirect;


 if (dir == 2)
  entry.rx_bytes = ct_state->backend_id;

 entry.lb_loopback = ct_state->loopback;
 entry.node_port = ct_state->node_port;
 relax_verifier();
 entry.dsr = ct_state->dsr;
 entry.ifindex = ct_state->ifindex;

 entry.rev_nat_index = ct_state->rev_nat_index;
 seen_flags.value |= is_tcp ? TCP_FLAG_SYN : 0;
 ct_update_timeout(&entry, is_tcp, dir, seen_flags);

 if (dir == 1) {
  entry.rx_packets = 1;
  entry.rx_bytes = ctx_full_len(ctx);
 } else if (dir == 0) {
  entry.tx_packets = 1;
  entry.tx_bytes = ctx_full_len(ctx);
 }

 cilium_dbg3(ctx, DBG_CT_CREATED6, entry.rev_nat_index, ct_state->src_sec_id, 0);

 entry.src_sec_id = ct_state->src_sec_id;
 if (map_update_elem(map_main, tuple, &entry, 0) < 0) {
  send_signal_ct_fill_up(ctx, SIGNAL_PROTO_V6);
  return -155;
 }

 if (map_related != ((void *)0)) {

  struct ipv6_ct_tuple icmp_tuple = {
   .nexthdr = 58,
   .sport = 0,
   .dport = 0,
   .flags = tuple->flags | 2,
  };

  entry.seen_non_syn = true;

  ipv6_addr_copy(&icmp_tuple.daddr, &tuple->daddr);
  ipv6_addr_copy(&icmp_tuple.saddr, &tuple->saddr);

  if (map_update_elem(map_related, &icmp_tuple, &entry, 0) < 0) {
   send_signal_ct_fill_up(ctx, SIGNAL_PROTO_V6);
   return -155;
  }
 }
 return 0;
}

static inline __attribute__((always_inline)) void ct_update4_backend_id(const void *map,
        const struct ipv4_ct_tuple *tuple,
        const struct ct_state *state)
{
 struct ct_entry *entry;

 entry = map_lookup_elem(map, tuple);
 if (!entry)
  return;


 entry->rx_bytes = state->backend_id;
}

static inline __attribute__((always_inline)) void
ct_update4_rev_nat_index(const void *map, const struct ipv4_ct_tuple *tuple,
    const struct ct_state *state)
{
 struct ct_entry *entry;

 entry = map_lookup_elem(map, tuple);
 if (!entry)
  return;

 entry->rev_nat_index = state->rev_nat_index;
}

static inline __attribute__((always_inline)) int ct_create4(const void *map_main,
          const void *map_related,
          struct ipv4_ct_tuple *tuple,
          struct __sk_buff *ctx, const int dir,
          const struct ct_state *ct_state,
          _Bool proxy_redirect)
{

 struct ct_entry entry = { };
 _Bool is_tcp = tuple->nexthdr == IPPROTO_TCP;
 union tcp_flags seen_flags = { .value = 0 };




 entry.proxy_redirect = proxy_redirect;

 entry.lb_loopback = ct_state->loopback;
 entry.node_port = ct_state->node_port;
 relax_verifier();
 entry.dsr = ct_state->dsr;
 entry.ifindex = ct_state->ifindex;





 if (dir == 2)
  entry.rx_bytes = ct_state->backend_id;
 entry.rev_nat_index = ct_state->rev_nat_index;
 seen_flags.value |= is_tcp ? TCP_FLAG_SYN : 0;
 ct_update_timeout(&entry, is_tcp, dir, seen_flags);

 if (dir == 1) {
  entry.rx_packets = 1;
  entry.rx_bytes = ctx_full_len(ctx);
 } else if (dir == 0) {
  entry.tx_packets = 1;
  entry.tx_bytes = ctx_full_len(ctx);
 }






 cilium_dbg3(ctx, DBG_CT_CREATED4, entry.rev_nat_index,
      ct_state->src_sec_id, ct_state->addr);

 entry.src_sec_id = ct_state->src_sec_id;
 if (map_update_elem(map_main, tuple, &entry, 0) < 0) {
  send_signal_ct_fill_up(ctx, SIGNAL_PROTO_V4);
  return -155;
 }

 if (ct_state->addr && ct_state->loopback) {
  __u8 flags = tuple->flags;
  __be32 saddr, daddr;

  saddr = tuple->saddr;
  daddr = tuple->daddr;






  tuple->flags = 1;
  if (dir == 1) {
   tuple->saddr = ct_state->addr;
   tuple->daddr = ct_state->svc_addr;
  } else {
   tuple->saddr = ct_state->svc_addr;
   tuple->daddr = ct_state->addr;
  }

  if (map_update_elem(map_main, tuple, &entry, 0) < 0) {
   send_signal_ct_fill_up(ctx, SIGNAL_PROTO_V4);
   return -155;
  }

  tuple->saddr = saddr;
  tuple->daddr = daddr;
  tuple->flags = flags;
 }

 if (map_related != ((void *)0)) {

  struct ipv4_ct_tuple icmp_tuple = {
   .daddr = tuple->daddr,
   .saddr = tuple->saddr,
   .nexthdr = IPPROTO_ICMP,
   .sport = 0,
   .dport = 0,
   .flags = tuple->flags | 2,
  };

  entry.seen_non_syn = true;




  if (map_update_elem(map_related, &icmp_tuple, &entry, 0) < 0) {
   send_signal_ct_fill_up(ctx, SIGNAL_PROTO_V4);
   return -155;
  }
 }
 return 0;
}
# 8 "/var/lib/cilium/bpf/lib/proxy.h" 2
# 190 "/var/lib/cilium/bpf/lib/proxy.h"
static inline __attribute__((always_inline)) int
__ctx_redirect_to_proxy(struct __sk_buff *ctx, void *tuple __attribute__((__unused__)),
   __be16 proxy_port, _Bool from_host __attribute__((__unused__)),
   _Bool ipv4 __attribute__((__unused__)))
{
 int result __attribute__((__unused__)) = 0;






  ctx->mark = 0x0200 | proxy_port << 16;

 cilium_dbg(ctx, DBG_CAPTURE_PROXY_PRE, proxy_port, 0);
# 218 "/var/lib/cilium/bpf/lib/proxy.h"
 skb_change_type(ctx, 0);
 return result;
}


static inline __attribute__((always_inline)) int
ctx_redirect_to_proxy4(struct __sk_buff *ctx, void *tuple __attribute__((__unused__)),
         __be16 proxy_port, _Bool from_host __attribute__((__unused__)))
{
 return __ctx_redirect_to_proxy(ctx, tuple, proxy_port, from_host, true);
}
# 280 "/var/lib/cilium/bpf/lib/proxy.h"
static inline __attribute__((always_inline)) int
ctx_redirect_to_proxy_first(struct __sk_buff *ctx, __be16 proxy_port)
{
 int ret = 0;
# 330 "/var/lib/cilium/bpf/lib/proxy.h"
mark: __attribute__((__unused__))
 cilium_dbg(ctx, DBG_CAPTURE_PROXY_POST, proxy_port, 0);
 ctx->mark = 0x0200 | (proxy_port << 16);
 skb_change_type(ctx, 0);

out: __attribute__((__unused__))
 return ret;
}




static inline __attribute__((always_inline)) _Bool tc_index_skip_ingress_proxy(struct __sk_buff *ctx)
{
 volatile __u32 tc_index = ctx->tc_index;





 return tc_index & 1;
}




static inline __attribute__((always_inline)) _Bool tc_index_skip_egress_proxy(struct __sk_buff *ctx)
{
 volatile __u32 tc_index = ctx->tc_index;





 return tc_index & 2;
}
# 50 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/trace.h" 1
# 22 "/var/lib/cilium/bpf/lib/trace.h"
enum {
 TRACE_TO_LXC,
 TRACE_TO_PROXY,
 TRACE_TO_HOST,
 TRACE_TO_STACK,
 TRACE_TO_OVERLAY,
 TRACE_FROM_LXC,
 TRACE_FROM_PROXY,
 TRACE_FROM_HOST,
 TRACE_FROM_STACK,
 TRACE_FROM_OVERLAY,
 TRACE_FROM_NETWORK,
 TRACE_TO_NETWORK,
};


enum {
 TRACE_REASON_POLICY = CT_NEW,
 TRACE_REASON_CT_ESTABLISHED = CT_ESTABLISHED,
 TRACE_REASON_CT_REPLY = CT_REPLY,
 TRACE_REASON_CT_RELATED = CT_RELATED,
 TRACE_REASON_CT_REOPENED = CT_REOPENED,
};




enum {
 TRACE_AGGREGATE_NONE = 0,
 TRACE_AGGREGATE_RX = 1,
 TRACE_AGGREGATE_ACTIVE_CT = 3,
};
# 67 "/var/lib/cilium/bpf/lib/trace.h"
static inline __attribute__((always_inline)) void
update_trace_metrics(struct __sk_buff *ctx, __u8 obs_point, __u8 reason)
{
 __u8 encrypted;

 switch (obs_point) {
 case TRACE_TO_LXC:
  update_metrics(ctx_full_len(ctx), 1,
          0);
  break;
# 87 "/var/lib/cilium/bpf/lib/trace.h"
 case TRACE_TO_HOST:
 case TRACE_TO_STACK:
 case TRACE_TO_OVERLAY:
 case TRACE_TO_NETWORK:
  update_metrics(ctx_full_len(ctx), 2,
          0);
  break;
 case TRACE_FROM_OVERLAY:
 case TRACE_FROM_NETWORK:
  encrypted = reason & 0x80;
  if (!encrypted)
   update_metrics(ctx_full_len(ctx), 1,
           3);
  else
   update_metrics(ctx_full_len(ctx), 1,
           4);
  break;
 }
}


struct trace_notify {
 __u8 type; __u8 subtype; __u16 source; __u32 hash; __u32 len_orig; __u16 len_cap; __u16 version;
 __u32 src_label;
 __u32 dst_label;
 __u16 dst_id;
 __u8 reason;
 __u8 ipv6:1;
 __u8 pad:7;
 __u32 ifindex;
 union {
  struct {
   __be32 orig_ip4;
   __u32 orig_pad1;
   __u32 orig_pad2;
   __u32 orig_pad3;
  };
  union v6addr orig_ip6;
 };
};

static inline __attribute__((always_inline)) _Bool emit_trace_notify(__u8 obs_point, __u32 monitor)
{
 if (3 >= TRACE_AGGREGATE_RX) {
  switch (obs_point) {
  case TRACE_FROM_LXC:
  case TRACE_FROM_PROXY:
  case TRACE_FROM_HOST:
  case TRACE_FROM_STACK:
  case TRACE_FROM_OVERLAY:
  case TRACE_FROM_NETWORK:
   return false;
  default:
   break;
  }
 }

 if (3 >= TRACE_AGGREGATE_ACTIVE_CT && !monitor)
  return false;

 return true;
}

static inline __attribute__((always_inline)) void
send_trace_notify(struct __sk_buff *ctx, __u8 obs_point, __u32 src, __u32 dst,
     __u16 dst_id, __u32 ifindex, __u8 reason, __u32 monitor)
{
 __u64 ctx_len = ctx_full_len(ctx);
 __u64 cap_len = ({ __u64 _x = (monitor ? : 128ULL); __u64 _y = (ctx_len); (void) (&_x == &_y); _x < _y ? _x : _y; });

 struct trace_notify msg __attribute__((aligned(8)));

 update_trace_metrics(ctx, obs_point, reason);

 if (!emit_trace_notify(obs_point, monitor))
  return;

 msg = (typeof(msg)) {
  .type = (CILIUM_NOTIFY_TRACE), .subtype = (obs_point), .source = 158, .hash = ctx->hash,
  .len_orig = (ctx_len), .len_cap = (cap_len), .version = 1,
  .src_label = src,
  .dst_label = dst,
  .dst_id = dst_id,
  .reason = reason,
  .ifindex = ifindex,
 };
 memset(&msg.orig_ip6, 0, sizeof(union v6addr));

 skb_event_output(ctx, &cilium_events,
    (cap_len << 32) | BPF_F_CURRENT_CPU,
    &msg, sizeof(msg));
}

static inline __attribute__((always_inline)) void
send_trace_notify4(struct __sk_buff *ctx, __u8 obs_point, __u32 src, __u32 dst,
     __be32 orig_addr, __u16 dst_id, __u32 ifindex, __u8 reason,
     __u32 monitor)
{
 __u64 ctx_len = ctx_full_len(ctx);
 __u64 cap_len = ({ __u64 _x = (monitor ? : 128ULL); __u64 _y = (ctx_len); (void) (&_x == &_y); _x < _y ? _x : _y; });

 struct trace_notify msg;

 update_trace_metrics(ctx, obs_point, reason);

 if (!emit_trace_notify(obs_point, monitor))
  return;

 msg = (typeof(msg)) {
  .type = (CILIUM_NOTIFY_TRACE), .subtype = (obs_point), .source = 158, .hash = ctx->hash,
  .len_orig = (ctx_len), .len_cap = (cap_len), .version = 1,
  .src_label = src,
  .dst_label = dst,
  .dst_id = dst_id,
  .reason = reason,
  .ifindex = ifindex,
  .ipv6 = 0,
  .orig_ip4 = orig_addr,
 };

 skb_event_output(ctx, &cilium_events,
    (cap_len << 32) | BPF_F_CURRENT_CPU,
    &msg, sizeof(msg));
}

static inline __attribute__((always_inline)) void
send_trace_notify6(struct __sk_buff *ctx, __u8 obs_point, __u32 src, __u32 dst,
     union v6addr *orig_addr, __u16 dst_id, __u32 ifindex,
     __u8 reason, __u32 monitor)
{
 __u64 ctx_len = ctx_full_len(ctx);
 __u64 cap_len = ({ __u64 _x = (monitor ? : 128ULL); __u64 _y = (ctx_len); (void) (&_x == &_y); _x < _y ? _x : _y; });

 struct trace_notify msg;

 update_trace_metrics(ctx, obs_point, reason);

 if (!emit_trace_notify(obs_point, monitor))
  return;

 msg = (typeof(msg)) {
  .type = (CILIUM_NOTIFY_TRACE), .subtype = (obs_point), .source = 158, .hash = ctx->hash,
  .len_orig = (ctx_len), .len_cap = (cap_len), .version = 1,
  .src_label = src,
  .dst_label = dst,
  .dst_id = dst_id,
  .reason = reason,
  .ifindex = ifindex,
  .ipv6 = 1,
 };

 ipv6_addr_copy(&msg.orig_ip6, orig_addr);

 skb_event_output(ctx, &cilium_events,
    (cap_len << 32) | BPF_F_CURRENT_CPU,
    &msg, sizeof(msg));
}
# 51 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/identity.h" 1
# 27 "/var/lib/cilium/bpf/lib/identity.h"
static inline __attribute__((always_inline)) _Bool identity_is_reserved(__u32 identity)
{
 return identity < 3 || identity == 6;
}

static inline __attribute__((always_inline)) _Bool inherit_identity_from_host(struct __sk_buff *ctx,
             __u32 *identity)
{
 __u32 magic = ctx->mark & 0x0F00;
 _Bool from_proxy = false;





 if (magic == 0x0A00) {
  *identity = get_identity(ctx);
  ctx->tc_index |= 1;
  from_proxy = true;




 } else if (magic == 0x0B00) {
  *identity = get_identity(ctx);
  ctx->tc_index |= 2;
  from_proxy = true;
 } else if (magic == 0x0F00) {
  *identity = get_identity(ctx);
 } else if (magic == 0x0C00) {
  *identity = 1;
 } else {
  *identity = 2;
 }


 ctx->mark = 0;
 cilium_dbg(ctx, DBG_INHERIT_IDENTITY, *identity, 0);

 return from_proxy;
}
# 52 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/l3.h" 1
# 10 "/var/lib/cilium/bpf/lib/l3.h"
# 1 "/var/lib/cilium/bpf/lib/eps.h" 1
# 12 "/var/lib/cilium/bpf/lib/eps.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) struct endpoint_info *
__lookup_ip6_endpoint(const union v6addr *ip6)
{
 struct endpoint_key key = {};

 key.ip6 = *ip6;
 key.family = 2;

 return map_lookup_elem(&cilium_lxc, &key);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) struct endpoint_info *
lookup_ip6_endpoint(struct ipv6hdr *ip6)
{
 return __lookup_ip6_endpoint((union v6addr *)&ip6->daddr);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) struct endpoint_info *
__lookup_ip4_endpoint(__u32 ip)
{
 struct endpoint_key key = {};

 key.ip4 = ip;
 key.family = 1;

 return map_lookup_elem(&cilium_lxc, &key);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) struct endpoint_info *
lookup_ip4_endpoint(const struct iphdr *ip4)
{
 return __lookup_ip4_endpoint(ip4->daddr);
}
# 74 "/var/lib/cilium/bpf/lib/eps.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) struct remote_endpoint_info *
ipcache_lookup6(struct bpf_elf_map *map, const union v6addr *addr,
  __u32 prefix)
{
 struct ipcache_key key = {
  .lpm_key = { ((8 * (sizeof(struct ipcache_key) - sizeof(struct bpf_lpm_trie_key) - sizeof(union v6addr))) + (prefix)), {} },
  .family = 2,
  .ip6 = *addr,
 };
 ipv6_addr_clear_suffix(&key.ip6, prefix);
 return map_lookup_elem(map, &key);
}



static inline __attribute__((always_inline)) __attribute__((__unused__)) struct remote_endpoint_info *
ipcache_lookup4(struct bpf_elf_map *map, __be32 addr, __u32 prefix)
{
 struct ipcache_key key = {
  .lpm_key = { ((8 * (sizeof(struct ipcache_key) - sizeof(struct bpf_lpm_trie_key) - sizeof(union v6addr))) + (prefix)), {} },
  .family = 1,
  .ip4 = addr,
 };
 key.ip4 &= (__builtin_constant_p(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF) ? ((__be32)((__u32)( (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x000000ffUL) << 24) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(prefix <= 0 ? 0 : prefix < 32 ? ((1<<prefix) - 1) << (32-prefix) : 0xFFFFFFFF));
 return map_lookup_elem(map, &key);
}
# 142 "/var/lib/cilium/bpf/lib/eps.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) struct egress_info *
egress_lookup4(struct bpf_elf_map *map, __be32 sip, __be32 dip)
{
 struct egress_key key = {
  .lpm_key = { ((8 * (sizeof(struct egress_key) - sizeof(struct bpf_lpm_trie_key) - 4)) + (32)), {} },
  .sip = sip,
  .dip = dip,
 };
 return map_lookup_elem(map, &key);
}
# 11 "/var/lib/cilium/bpf/lib/l3.h" 2



# 1 "/var/lib/cilium/bpf/lib/icmp6.h" 1
# 15 "/var/lib/cilium/bpf/lib/l3.h" 2
# 41 "/var/lib/cilium/bpf/lib/l3.h"
static inline __attribute__((always_inline)) int ipv4_l3(struct __sk_buff *ctx, int l3_off,
       const __u8 *smac, const __u8 *dmac,
       struct iphdr *ip4)
{
 if (ipv4_dec_ttl(ctx, l3_off, ip4)) {

  return -134;
 }

 if (smac && eth_store_saddr(ctx, smac, 0) < 0)
  return -141;
 if (dmac && eth_store_daddr(ctx, dmac, 0) < 0)
  return -141;

 return 0;
}
# 114 "/var/lib/cilium/bpf/lib/l3.h"
static inline __attribute__((always_inline)) int ipv4_local_delivery(struct __sk_buff *ctx, int l3_off,
            __u32 seclabel, struct iphdr *ip4,
            const struct endpoint_info *ep,
            __u8 direction __attribute__((__unused__)),
            _Bool from_host __attribute__((__unused__)))
{
 mac_t router_mac = ep->node_mac;
 mac_t lxc_mac = ep->mac;
 int ret;

 cilium_dbg(ctx, DBG_LOCAL_DELIVERY, ep->lxc_id, seclabel);

 ret = ipv4_l3(ctx, l3_off, (__u8 *) &router_mac, (__u8 *) &lxc_mac, ip4);
 if (ret != 0)
  return ret;







 update_metrics(ctx_full_len(ctx), direction, 0);
# 147 "/var/lib/cilium/bpf/lib/l3.h"
 ctx_store_meta(ctx, CB_SRC_LABEL, seclabel);
 ctx_store_meta(ctx, CB_IFINDEX, ep->ifindex);
 ctx_store_meta(ctx, CB_NAT46_STATE, from_host ? 1 : 0);

 tail_call_dynamic(ctx, &cilium_call_policy, ep->lxc_id);
 return -140;

}


static inline __attribute__((always_inline)) __u8 get_encrypt_key(__u32 ctx)
{
 struct encrypt_key key = {.ctx = ctx};
 struct encrypt_config *cfg;

 cfg = map_lookup_elem(&cilium_encrypt_state, &key);

 if (!cfg)
  return 0;
 return cfg->encrypt_key;
}

static inline __attribute__((always_inline)) __u8 get_min_encrypt_key(__u8 peer_key)
{
 __u8 local_key = get_encrypt_key(0);
# 181 "/var/lib/cilium/bpf/lib/l3.h"
 if (peer_key == 15)
  return local_key == 1 ? peer_key : local_key;
 if (local_key == 15)
  return peer_key == 1 ? local_key : peer_key;
 return local_key < peer_key ? local_key : peer_key;
}
# 53 "/var/lib/cilium/bpf/bpf_host.c" 2


# 1 "/var/lib/cilium/bpf/lib/encap.h" 1
# 56 "/var/lib/cilium/bpf/lib/encap.h"
static inline __attribute__((always_inline)) int
encap_remap_v6_host_address(struct __sk_buff *ctx __attribute__((__unused__)),
       const _Bool egress __attribute__((__unused__)))
{
# 112 "/var/lib/cilium/bpf/lib/encap.h"
 return 0;
}

static inline __attribute__((always_inline)) int
__encap_with_nodeid(struct __sk_buff *ctx, __u32 tunnel_endpoint,
      __u32 seclabel, __u32 monitor)
{
 struct bpf_tunnel_key key = {};
 __u32 node_id;
 int ret;





 if (seclabel == 1)
  seclabel = 6;

 node_id = (__builtin_constant_p(tunnel_endpoint) ? ((__be32)((__u32)( (((__u32)((tunnel_endpoint)) & (__u32)0x000000ffUL) << 24) | (((__u32)((tunnel_endpoint)) & (__u32)0x0000ff00UL) << 8) | (((__u32)((tunnel_endpoint)) & (__u32)0x00ff0000UL) >> 8) | (((__u32)((tunnel_endpoint)) & (__u32)0xff000000UL) >> 24)))) : __builtin_bswap32(tunnel_endpoint));
 key.tunnel_id = seclabel;
 key.remote_ipv4 = node_id;
 key.tunnel_ttl = 64;

 cilium_dbg(ctx, DBG_ENCAP, node_id, seclabel);

 ret = skb_set_tunnel_key(ctx, &key, sizeof(key), BPF_F_ZERO_CSUM_TX);
 if (__builtin_expect(!!(ret < 0), 0))
  return -141;

 send_trace_notify(ctx, TRACE_TO_OVERLAY, seclabel, 0, 0, 17,
     0, monitor);
 return 0;
}

static inline __attribute__((always_inline)) int
__encap_and_redirect_with_nodeid(struct __sk_buff *ctx, __u32 tunnel_endpoint,
     __u32 seclabel, __u32 monitor)
{
 int ret = __encap_with_nodeid(ctx, tunnel_endpoint, seclabel, monitor);
 if (ret != 0)
  return ret;

 return redirect(17, 0);
}






static inline __attribute__((always_inline)) int
encap_and_redirect_with_nodeid(struct __sk_buff *ctx, __u32 tunnel_endpoint,
          __u8 key __attribute__((__unused__)), __u32 seclabel,
          __u32 monitor)
{




 return __encap_and_redirect_with_nodeid(ctx, tunnel_endpoint, seclabel, monitor);
}
# 184 "/var/lib/cilium/bpf/lib/encap.h"
static inline __attribute__((always_inline)) int
encap_and_redirect_lxc(struct __sk_buff *ctx, __u32 tunnel_endpoint,
         __u8 encrypt_key __attribute__((__unused__)),
         struct endpoint_key *key, __u32 seclabel, __u32 monitor)
{
 struct endpoint_key *tunnel;

 if (tunnel_endpoint) {
# 207 "/var/lib/cilium/bpf/lib/encap.h"
  return __encap_and_redirect_with_nodeid(ctx, tunnel_endpoint, seclabel, monitor);

 }

 tunnel = map_lookup_elem(&cilium_tunnel_map, key);
 if (!tunnel)
  return -160;
# 224 "/var/lib/cilium/bpf/lib/encap.h"
 return __encap_and_redirect_with_nodeid(ctx, tunnel->ip4, seclabel, monitor);
}

static inline __attribute__((always_inline)) int
encap_and_redirect_netdev(struct __sk_buff *ctx, struct endpoint_key *k,
     __u32 seclabel, __u32 monitor)
{
 struct endpoint_key *tunnel;

 tunnel = map_lookup_elem(&cilium_tunnel_map, k);
 if (!tunnel)
  return -160;
# 245 "/var/lib/cilium/bpf/lib/encap.h"
 return __encap_and_redirect_with_nodeid(ctx, tunnel->ip4, seclabel, monitor);
}
# 56 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/nat.h" 1
# 19 "/var/lib/cilium/bpf/lib/nat.h"
# 1 "/var/lib/cilium/bpf/lib/conntrack_map.h" 1
# 51 "/var/lib/cilium/bpf/lib/conntrack_map.h"
struct bpf_elf_map __attribute__((section("maps"), used)) cilium_ct4_global = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(struct ipv4_ct_tuple),
 .size_value = sizeof(struct ct_entry),
 .pinning = 2,
 .max_elem = 131072,



};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_ct_any4_global = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(struct ipv4_ct_tuple),
 .size_value = sizeof(struct ct_entry),
 .pinning = 2,
 .max_elem = 65536,



};

static inline __attribute__((always_inline)) struct bpf_elf_map *
get_ct_map4(const struct ipv4_ct_tuple *tuple)
{
 if (tuple->nexthdr == IPPROTO_TCP)
  return &cilium_ct4_global;

 return &cilium_ct_any4_global;
}
# 20 "/var/lib/cilium/bpf/lib/nat.h" 2
# 1 "/var/lib/cilium/bpf/lib/icmp6.h" 1
# 21 "/var/lib/cilium/bpf/lib/nat.h" 2

enum {
 NAT_DIR_EGRESS = 0,
 NAT_DIR_INGRESS = 1,
};

struct nat_entry {
 __u64 created;
 __u64 host_local;
 __u64 pad1;
 __u64 pad2;
};
# 50 "/var/lib/cilium/bpf/lib/nat.h"
static inline __attribute__((always_inline)) __be16 __snat_clamp_port_range(__u16 start, __u16 end,
            __u16 val)
{
 return (val % (__u16)(end - start)) + start;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) __be16
__snat_try_keep_port(__u16 start, __u16 end, __u16 val)
{
 return val >= start && val <= end ? val :
        __snat_clamp_port_range(start, end, get_prandom_u32());
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void *
__snat_lookup(const void *map, const void *tuple)
{
 return map_lookup_elem(map, tuple);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int
__snat_update(const void *map, const void *otuple, const void *ostate,
       const void *rtuple, const void *rstate)
{
 int ret;

 ret = map_update_elem(map, rtuple, rstate, BPF_NOEXIST);
 if (!ret) {
  ret = map_update_elem(map, otuple, ostate, BPF_NOEXIST);
  if (ret)
   map_delete_elem(map, rtuple);
 }
 return ret;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
__snat_delete(const void *map, const void *otuple, const void *rtuple)
{
 map_delete_elem(map, otuple);
 map_delete_elem(map, rtuple);
}

struct ipv4_nat_entry {
 struct nat_entry common;
 union {
  struct {
   __be32 to_saddr;
   __be16 to_sport;
  };
  struct {
   __be32 to_daddr;
   __be16 to_dport;
  };
 };
};

struct ipv4_nat_target {
 __be32 addr;
 const __u16 min_port;
 const __u16 max_port;
 _Bool src_from_world;
};


struct bpf_elf_map __attribute__((section("maps"), used)) cilium_snat_v4_external = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(struct ipv4_ct_tuple),
 .size_value = sizeof(struct ipv4_nat_entry),
 .pinning = 2,
 .max_elem = 131072,



};
# 135 "/var/lib/cilium/bpf/lib/nat.h"
static inline __attribute__((always_inline))
struct ipv4_nat_entry *snat_v4_lookup(const struct ipv4_ct_tuple *tuple)
{
 return __snat_lookup(&cilium_snat_v4_external, tuple);
}

static inline __attribute__((always_inline)) int snat_v4_update(const struct ipv4_ct_tuple *otuple,
       const struct ipv4_nat_entry *ostate,
       const struct ipv4_ct_tuple *rtuple,
       const struct ipv4_nat_entry *rstate)
{
 return __snat_update(&cilium_snat_v4_external, otuple, ostate,
        rtuple, rstate);
}

static inline __attribute__((always_inline)) void snat_v4_delete(const struct ipv4_ct_tuple *otuple,
        const struct ipv4_ct_tuple *rtuple)
{
 __snat_delete(&cilium_snat_v4_external, otuple, rtuple);
}

static inline __attribute__((always_inline)) void snat_v4_swap_tuple(const struct ipv4_ct_tuple *otuple,
            struct ipv4_ct_tuple *rtuple)
{
 memset(rtuple, 0, sizeof(*rtuple));
 rtuple->nexthdr = otuple->nexthdr;
 rtuple->daddr = otuple->saddr;
 rtuple->saddr = otuple->daddr;
 rtuple->dport = otuple->sport;
 rtuple->sport = otuple->dport;
 rtuple->flags = otuple->flags == NAT_DIR_EGRESS ?
   NAT_DIR_INGRESS : NAT_DIR_EGRESS;
}

static inline __attribute__((always_inline)) int snat_v4_reverse_tuple(const struct ipv4_ct_tuple *otuple,
       struct ipv4_ct_tuple *rtuple)
{
 struct ipv4_nat_entry *ostate;

 ostate = snat_v4_lookup(otuple);
 if (ostate) {
  snat_v4_swap_tuple(otuple, rtuple);
  rtuple->daddr = ostate->to_saddr;
  rtuple->dport = ostate->to_sport;
 }

 return ostate ? 0 : -1;
}

static inline __attribute__((always_inline)) void snat_v4_ct_canonicalize(struct ipv4_ct_tuple *otuple)
{
 __be32 addr = otuple->saddr;

 otuple->flags = NAT_DIR_EGRESS;

 otuple->saddr = otuple->daddr;
 otuple->daddr = addr;
}

static inline __attribute__((always_inline)) void snat_v4_delete_tuples(struct ipv4_ct_tuple *otuple)
{
 struct ipv4_ct_tuple rtuple;

 if (otuple->flags & 1)
  return;
 snat_v4_ct_canonicalize(otuple);
 if (!snat_v4_reverse_tuple(otuple, &rtuple))
  snat_v4_delete(otuple, &rtuple);
}

static inline __attribute__((always_inline)) int snat_v4_new_mapping(struct __sk_buff *ctx,
            struct ipv4_ct_tuple *otuple,
            struct ipv4_nat_entry *ostate,
            const struct ipv4_nat_target *target)
{
 int ret = -167, retries;
 struct ipv4_nat_entry rstate;
 struct ipv4_ct_tuple rtuple;
 __u16 port;

 memset(&rstate, 0, sizeof(rstate));
 memset(ostate, 0, sizeof(*ostate));

 rstate.to_daddr = otuple->saddr;
 rstate.to_dport = otuple->sport;

 ostate->to_saddr = target->addr;

 snat_v4_swap_tuple(otuple, &rtuple);
 port = __snat_try_keep_port(target->min_port,
        target->max_port,
        (__builtin_constant_p(otuple->sport) ? ((__u16)( (((__u16)((__be16)(otuple->sport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(otuple->sport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(otuple->sport)));

 rtuple.dport = ostate->to_sport = (__builtin_constant_p(port) ? ((__be16)((__u16)( (((__u16)((port)) & (__u16)0x00ffU) << 8) | (((__u16)((port)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(port));
 rtuple.daddr = target->addr;

 if (otuple->saddr == target->addr) {
  ostate->common.host_local = 1;
  rstate.common.host_local = ostate->common.host_local;
 }

#pragma unroll
 for (retries = 0; retries < 32; retries++) {
  if (!snat_v4_lookup(&rtuple)) {
   ostate->common.created = ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
   rstate.common.created = ostate->common.created;

   ret = snat_v4_update(otuple, ostate, &rtuple, &rstate);
   if (!ret)
    break;
  }

  port = __snat_clamp_port_range(target->min_port,
            target->max_port,
            retries ? port + 1 :
            get_prandom_u32());
  rtuple.dport = ostate->to_sport = (__builtin_constant_p(port) ? ((__be16)((__u16)( (((__u16)((port)) & (__u16)0x00ffU) << 8) | (((__u16)((port)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(port));
 }

 if (retries > 16)
  send_signal_nat_fill_up(ctx, SIGNAL_PROTO_V4);
 return !ret ? 0 : -167;
}

static inline __attribute__((always_inline)) int snat_v4_track_local(struct __sk_buff *ctx,
            const struct ipv4_ct_tuple *tuple,
            const struct ipv4_nat_entry *state,
            int dir, __u32 off,
            const struct ipv4_nat_target *target)
{
 struct ct_state ct_state;
 struct ipv4_ct_tuple tmp;
 _Bool needs_ct = false;
 __u32 monitor = 0;
 int ret, where;

 if (state && state->common.host_local) {
  needs_ct = true;
 } else if (!state && dir == NAT_DIR_EGRESS) {
  if (tuple->saddr == target->addr)
   needs_ct = true;
 }
 if (!needs_ct)
  return 0;

 memset(&ct_state, 0, sizeof(ct_state));
 memcpy(&tmp, tuple, sizeof(tmp));

 where = dir == NAT_DIR_INGRESS ? 1 : 0;

 ret = ct_lookup4(get_ct_map4(&tmp), &tmp, ctx, off, where,
    &ct_state, &monitor);
 if (ret < 0) {
  return ret;
 } else if (ret == CT_NEW) {
  ret = ct_create4(get_ct_map4(&tmp), ((void *)0), &tmp, ctx,
     where, &ct_state, false);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;
 }

 return 0;
}

static inline __attribute__((always_inline)) int snat_v4_handle_mapping(struct __sk_buff *ctx,
        struct ipv4_ct_tuple *tuple,
        struct ipv4_nat_entry **state,
        struct ipv4_nat_entry *tmp,
        int dir, __u32 off,
        const struct ipv4_nat_target *target)
{
 int ret;

 *state = snat_v4_lookup(tuple);
 ret = snat_v4_track_local(ctx, tuple, *state, dir, off, target);
 if (ret < 0)
  return ret;
 else if (*state)
  return 0;
 else if (dir == NAT_DIR_INGRESS)
  return tuple->nexthdr != IPPROTO_ICMP &&
         (__builtin_constant_p(tuple->dport) ? ((__u16)( (((__u16)((__be16)(tuple->dport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->dport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->dport)) < target->min_port ?
         -173 : -167;
 else
  return snat_v4_new_mapping(ctx, tuple, (*state = tmp), target);
}

static inline __attribute__((always_inline)) int snat_v4_rewrite_egress(struct __sk_buff *ctx,
        struct ipv4_ct_tuple *tuple,
        struct ipv4_nat_entry *state,
        __u32 off, _Bool has_l4_header)
{
 struct csum_offset csum = {};
 __be32 sum_l4 = 0, sum;
 int ret;

 if (state->to_saddr == tuple->saddr &&
     state->to_sport == tuple->sport)
  return 0;
 sum = csum_diff(&tuple->saddr, 4, &state->to_saddr, 4, 0);
 if (has_l4_header) {
  csum_l4_offset_and_flags(tuple->nexthdr, &csum);

  if (state->to_sport != tuple->sport) {
   switch (tuple->nexthdr) {
   case IPPROTO_TCP:
   case IPPROTO_UDP:
    ret = l4_modify_port(ctx, off,
           __builtin_offsetof(struct tcphdr, source),
           &csum, state->to_sport,
           tuple->sport);
    if (ret < 0)
     return ret;
    break;
   case IPPROTO_ICMP: {
    __be32 from, to;

    if (skb_store_bytes(ctx, off +
          __builtin_offsetof(struct icmphdr, un.echo.id),
          &state->to_sport,
          sizeof(state->to_sport), 0) < 0)
     return -141;
    from = tuple->sport;
    to = state->to_sport;
    sum_l4 = csum_diff(&from, 4, &to, 4, 0);
    csum.offset = __builtin_offsetof(struct icmphdr, checksum);
    break;
   }}
  }
 }
 if (skb_store_bytes(ctx, 14 + __builtin_offsetof(struct iphdr, saddr),
       &state->to_saddr, 4, 0) < 0)
  return -141;
 if (l3_csum_replace(ctx, 14 + __builtin_offsetof(struct iphdr, check),
       0, sum, 0) < 0)
  return -153;
 if (tuple->nexthdr == IPPROTO_ICMP)
  sum = sum_l4;
 if (csum.offset &&
     csum_l4_replace(ctx, off, &csum, 0, sum, (1ULL << 4)) < 0)
  return -154;
 return 0;
}

static inline __attribute__((always_inline)) int snat_v4_rewrite_ingress(struct __sk_buff *ctx,
         struct ipv4_ct_tuple *tuple,
         struct ipv4_nat_entry *state,
         __u32 off)
{
 struct csum_offset csum = {};
 __be32 sum_l4 = 0, sum;
 int ret;

 if (state->to_daddr == tuple->daddr &&
     state->to_dport == tuple->dport)
  return 0;
 sum = csum_diff(&tuple->daddr, 4, &state->to_daddr, 4, 0);
 csum_l4_offset_and_flags(tuple->nexthdr, &csum);
 if (state->to_dport != tuple->dport) {
  switch (tuple->nexthdr) {
  case IPPROTO_TCP:
  case IPPROTO_UDP:
   ret = l4_modify_port(ctx, off,
          __builtin_offsetof(struct tcphdr, dest),
          &csum, state->to_dport,
          tuple->dport);
   if (ret < 0)
    return ret;
   break;
  case IPPROTO_ICMP: {
   __be32 from, to;

   if (skb_store_bytes(ctx, off +
         __builtin_offsetof(struct icmphdr, un.echo.id),
         &state->to_dport,
         sizeof(state->to_dport), 0) < 0)
    return -141;
   from = tuple->dport;
   to = state->to_dport;
   sum_l4 = csum_diff(&from, 4, &to, 4, 0);
   csum.offset = __builtin_offsetof(struct icmphdr, checksum);
   break;
  }}
 }
 if (skb_store_bytes(ctx, 14 + __builtin_offsetof(struct iphdr, daddr),
       &state->to_daddr, 4, 0) < 0)
  return -141;
 if (l3_csum_replace(ctx, 14 + __builtin_offsetof(struct iphdr, check),
       0, sum, 0) < 0)
  return -153;
 if (tuple->nexthdr == IPPROTO_ICMP)
  sum = sum_l4;
 if (csum.offset &&
     csum_l4_replace(ctx, off, &csum, 0, sum, (1ULL << 4)) < 0)
  return -154;
 return 0;
}

static inline __attribute__((always_inline)) _Bool snat_v4_can_skip(const struct ipv4_nat_target *target,
          const struct ipv4_ct_tuple *tuple, int dir,
          _Bool from_endpoint, _Bool icmp_echoreply)
{
 __u16 dport = (__builtin_constant_p(tuple->dport) ? ((__u16)( (((__u16)((__be16)(tuple->dport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->dport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->dport)), sport = (__builtin_constant_p(tuple->sport) ? ((__u16)( (((__u16)((__be16)(tuple->sport)) & (__u16)0x00ffU) << 8) | (((__u16)((__be16)(tuple->sport)) & (__u16)0xff00U) >> 8))) : __builtin_bswap16(tuple->sport));

 if (dir == NAT_DIR_EGRESS &&
     ((!from_endpoint && !target->src_from_world && sport < 32768) ||
      icmp_echoreply))
  return true;
 if (dir == NAT_DIR_INGRESS && (dport < target->min_port || dport > target->max_port))
  return true;

 return false;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int snat_v4_create_dsr(struct __sk_buff *ctx,
            __be32 to_saddr,
            __be16 to_sport)
{
 void *data, *data_end;
 struct ipv4_ct_tuple tuple = {};
 struct ipv4_nat_entry state = {};
 struct iphdr *ip4;
 struct {
  __be16 sport;
  __be16 dport;
 } l4hdr;
 __u32 off;
 int ret;

 ((void)sizeof(char[1 - 2*!!(sizeof(struct ipv4_nat_entry) > 64)]));

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;

 tuple.nexthdr = ip4->protocol;
 tuple.daddr = ip4->saddr;
 tuple.saddr = ip4->daddr;
 tuple.flags = NAT_DIR_EGRESS;

 off = ((void *)ip4 - data) + ipv4_hdrlen(ip4);

 switch (tuple.nexthdr) {
 case IPPROTO_TCP:
 case IPPROTO_UDP:
  if (skb_load_bytes(ctx, off, &l4hdr, sizeof(l4hdr)) < 0)
   return -134;
  tuple.dport = l4hdr.sport;
  tuple.sport = l4hdr.dport;
  break;
 default:



  return -168;
 }

 state.common.created = ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
 state.to_saddr = to_saddr;
 state.to_sport = to_sport;

 ret = map_update_elem(&cilium_snat_v4_external, &tuple, &state, 0);
 if (ret)
  return ret;

 return 0;
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) int snat_v4_process(struct __sk_buff *ctx, int dir,
      const struct ipv4_nat_target *target,
      _Bool from_endpoint)
{
 struct icmphdr icmphdr __attribute__((aligned(8)));
 struct ipv4_nat_entry *state, tmp;
 struct ipv4_ct_tuple tuple = {};
 void *data, *data_end;
 struct iphdr *ip4;
 struct {
  __be16 sport;
  __be16 dport;
 } l4hdr;
 _Bool icmp_echoreply = false;
 __u64 off;
 int ret;

 ((void)sizeof(char[1 - 2*!!(sizeof(struct ipv4_nat_entry) > 64)]));

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;

 tuple.nexthdr = ip4->protocol;
 tuple.daddr = ip4->daddr;
 tuple.saddr = ip4->saddr;
 tuple.flags = dir;
 off = ((void *)ip4 - data) + ipv4_hdrlen(ip4);
 switch (tuple.nexthdr) {
 case IPPROTO_TCP:
 case IPPROTO_UDP:
  if (skb_load_bytes(ctx, off, &l4hdr, sizeof(l4hdr)) < 0)
   return -134;
  tuple.dport = l4hdr.dport;
  tuple.sport = l4hdr.sport;
  break;
 case IPPROTO_ICMP:
  if (skb_load_bytes(ctx, off, &icmphdr, sizeof(icmphdr)) < 0)
   return -134;
  if (icmphdr.type != 8 &&
      icmphdr.type != 0)
   return -168;
  if (icmphdr.type == 8) {
   tuple.dport = 0;
   tuple.sport = icmphdr.un.echo.id;
  } else {
   tuple.dport = icmphdr.un.echo.id;
   tuple.sport = 0;
   icmp_echoreply = true;
  }
  break;
 default:
  return -173;
 };

 if (snat_v4_can_skip(target, &tuple, dir, from_endpoint, icmp_echoreply))
  return -173;
 ret = snat_v4_handle_mapping(ctx, &tuple, &state, &tmp, dir, off, target);
 if (ret > 0)
  return 0;
 if (ret < 0)
  return ret;

 return dir == NAT_DIR_EGRESS ?
        snat_v4_rewrite_egress(ctx, &tuple, state, off, ipv4_has_l4_header(ip4)) :
        snat_v4_rewrite_ingress(ctx, &tuple, state, off);
}
# 584 "/var/lib/cilium/bpf/lib/nat.h"
struct ipv6_nat_entry {
 struct nat_entry common;
 union {
  struct {
   union v6addr to_saddr;
   __be16 to_sport;
  };
  struct {
   union v6addr to_daddr;
   __be16 to_dport;
  };
 };
};

struct ipv6_nat_target {
 union v6addr addr;
 const __u16 min_port;
 const __u16 max_port;
 _Bool src_from_world;
};
# 1049 "/var/lib/cilium/bpf/lib/nat.h"
static inline __attribute__((always_inline)) __attribute__((__unused__))
int snat_v6_process(struct __sk_buff *ctx __attribute__((__unused__)),
      int dir __attribute__((__unused__)),
      const struct ipv6_nat_target *target __attribute__((__unused__)))
{
 return 0;
}

static inline __attribute__((always_inline)) __attribute__((__unused__))
void snat_v6_delete_tuples(struct ipv6_ct_tuple *tuple __attribute__((__unused__)))
{
}



static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ct_delete4(const void *map, struct ipv4_ct_tuple *tuple, struct __sk_buff *ctx)
{
 int err;

 err = map_delete_elem(map, tuple);
 if (err < 0)
  cilium_dbg(ctx, DBG_ERROR_RET, BPF_FUNC_map_delete_elem, err);
 else
  snat_v4_delete_tuples(tuple);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
ct_delete6(const void *map, struct ipv6_ct_tuple *tuple, struct __sk_buff *ctx)
{
 int err;

 err = map_delete_elem(map, tuple);
 if (err < 0)
  cilium_dbg(ctx, DBG_ERROR_RET, BPF_FUNC_map_delete_elem, err);
 else
  snat_v6_delete_tuples(tuple);
}
# 57 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/lb.h" 1
# 10 "/var/lib/cilium/bpf/lib/lb.h"
# 1 "/var/lib/cilium/bpf/lib/hash.h" 1







# 1 "/var/lib/cilium/bpf/lib/jhash.h" 1
# 14 "/var/lib/cilium/bpf/lib/jhash.h"
static inline __attribute__((always_inline)) __u32 rol32(__u32 word, __u32 shift)
{
 return (word << shift) | (word >> ((-shift) & 31));
}
# 40 "/var/lib/cilium/bpf/lib/jhash.h"
static inline __attribute__((always_inline)) __u32 jhash(const void *key, __u32 length,
       __u32 initval)
{
 const unsigned char *k = key;
 __u32 a, b, c;

 if (!__builtin_constant_p(length))
  __builtin_trap();

 a = b = c = 0xdeadbeef + length + initval;

 while (length > 12) {
  a += *(__u32 *)(k);
  b += *(__u32 *)(k + 4);
  c += *(__u32 *)(k + 8);

  { a -= c; a ^= rol32(c, 4); c += b; b -= a; b ^= rol32(a, 6); a += c; c -= b; c ^= rol32(b, 8); b += a; a -= c; a ^= rol32(c, 16); c += b; b -= a; b ^= rol32(a, 19); a += c; c -= b; c ^= rol32(b, 4); b += a; };
  length -= 12;
  k += 12;
 }

 switch (length) {
 case 12: c += (__u32)k[11] << 24;
 case 11: c += (__u32)k[10] << 16;
 case 10: c += (__u32)k[9] << 8;
 case 9: c += (__u32)k[8];
 case 8: b += (__u32)k[7] << 24;
 case 7: b += (__u32)k[6] << 16;
 case 6: b += (__u32)k[5] << 8;
 case 5: b += (__u32)k[4];
 case 4: a += (__u32)k[3] << 24;
 case 3: a += (__u32)k[2] << 16;
 case 2: a += (__u32)k[1] << 8;
 case 1: a += (__u32)k[0];

  { c ^= b; c -= rol32(b, 14); a ^= c; a -= rol32(c, 11); b ^= a; b -= rol32(a, 25); c ^= b; c -= rol32(b, 16); a ^= c; a -= rol32(c, 4); b ^= a; b -= rol32(a, 14); c ^= b; c -= rol32(b, 24); };
 case 0:
  break;
 }

 return c;
}

static inline __attribute__((always_inline)) __u32 __jhash_nwords(__u32 a, __u32 b, __u32 c,
         __u32 initval)
{
 a += initval;
 b += initval;
 c += initval;
 { c ^= b; c -= rol32(b, 14); a ^= c; a -= rol32(c, 11); b ^= a; b -= rol32(a, 25); c ^= b; c -= rol32(b, 16); a ^= c; a -= rol32(c, 4); b ^= a; b -= rol32(a, 14); c ^= b; c -= rol32(b, 24); };
 return c;
}

static inline __attribute__((always_inline)) __u32 jhash_3words(__u32 a, __u32 b, __u32 c,
       __u32 initval)
{
 return __jhash_nwords(a, b, c, initval + 0xdeadbeef + (3 << 2));
}

static inline __attribute__((always_inline)) __u32 jhash_2words(__u32 a, __u32 b, __u32 initval)
{
 return __jhash_nwords(a, b, 0, initval + 0xdeadbeef + (2 << 2));
}

static inline __attribute__((always_inline)) __u32 jhash_1word(__u32 a, __u32 initval)
{
 return __jhash_nwords(a, 0, 0, initval + 0xdeadbeef + (1 << 2));
}
# 9 "/var/lib/cilium/bpf/lib/hash.h" 2




static inline __attribute__((always_inline)) __u32 hash_from_tuple_v4(const struct ipv4_ct_tuple *tuple)
{
 return jhash_3words(tuple->saddr,
       ((__u32)tuple->dport << 16) | tuple->sport,
       tuple->nexthdr, 0);
}

static inline __attribute__((always_inline)) __u32 hash_from_tuple_v6(const struct ipv6_ct_tuple *tuple)
{
 __u32 a, b, c;

 a = tuple->saddr.p1;
 b = tuple->saddr.p2;
 c = tuple->saddr.p3;
 { a -= c; a ^= rol32(c, 4); c += b; b -= a; b ^= rol32(a, 6); a += c; c -= b; c ^= rol32(b, 8); b += a; a -= c; a ^= rol32(c, 16); c += b; b -= a; b ^= rol32(a, 19); a += c; c -= b; c ^= rol32(b, 4); b += a; };
 a += tuple->saddr.p4;
 b += ((__u32)tuple->dport << 16) | tuple->sport;
 c += tuple->nexthdr;
 { a -= c; a ^= rol32(c, 4); c += b; b -= a; b ^= rol32(a, 6); a += c; c -= b; c ^= rol32(b, 8); b += a; a -= c; a ^= rol32(c, 16); c += b; b -= a; b ^= rol32(a, 19); a += c; c -= b; c ^= rol32(b, 4); b += a; };
 a += 0;
 { c ^= b; c -= rol32(b, 14); a ^= c; a -= rol32(c, 11); b ^= a; b -= rol32(a, 25); c ^= b; c -= rol32(b, 16); a ^= c; a -= rol32(c, 4); b ^= a; b -= rol32(a, 14); c ^= b; c -= rol32(b, 24); };
 return c;
}
# 11 "/var/lib/cilium/bpf/lib/lb.h" 2
# 96 "/var/lib/cilium/bpf/lib/lb.h"
struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb4_reverse_nat = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(__u16),
 .size_value = sizeof(struct lb4_reverse_nat),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb4_services_v2 = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(struct lb4_key),
 .size_value = sizeof(struct lb4_service),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb4_backends = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(__u16),
 .size_value = sizeof(struct lb4_backend),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};


struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb4_affinity = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(struct lb4_affinity_key),
 .size_value = sizeof(struct lb_affinity_val),
 .pinning = 2,
 .max_elem = 65536,
};



struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb4_source_range = {
 .type = BPF_MAP_TYPE_LPM_TRIE,
 .size_key = sizeof(struct lb4_src_range_key),
 .size_value = sizeof(__u8),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};
# 178 "/var/lib/cilium/bpf/lib/lb.h"
struct bpf_elf_map __attribute__((section("maps"), used)) cilium_lb_affinity_match = {
 .type = BPF_MAP_TYPE_HASH,
 .size_key = sizeof(struct lb_affinity_match),
 .size_value = sizeof(__u8),
 .pinning = 2,
 .max_elem = 65536,
 .flags = BPF_F_NO_PREALLOC,
};
# 199 "/var/lib/cilium/bpf/lib/lb.h"
static inline __attribute__((always_inline))
_Bool lb4_svc_is_loadbalancer(const struct lb4_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_LOADBALANCER;



}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_loadbalancer(const struct lb6_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_LOADBALANCER;



}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_nodeport(const struct lb4_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_NODEPORT;



}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_nodeport(const struct lb6_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_NODEPORT;



}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_external_ip(const struct lb4_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_EXTERNAL_IP;



}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_external_ip(const struct lb6_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_EXTERNAL_IP;



}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_hostport(const struct lb4_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_HOSTPORT;



}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_hostport(const struct lb6_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_HOSTPORT;



}

static inline __attribute__((always_inline))
_Bool lb4_svc_has_src_range_check(const struct lb4_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_SOURCE_RANGE;



}

static inline __attribute__((always_inline))
_Bool lb6_svc_has_src_range_check(const struct lb6_service *svc __attribute__((__unused__)))
{

 return svc->flags & SVC_FLAG_SOURCE_RANGE;



}

static inline __attribute__((always_inline)) _Bool lb_skip_l4_dnat(void)
{
 return 0 == 1;
}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_local_scope(const struct lb4_service *svc)
{
 return svc->flags & SVC_FLAG_LOCAL_SCOPE;
}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_local_scope(const struct lb6_service *svc)
{
 return svc->flags & SVC_FLAG_LOCAL_SCOPE;
}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_affinity(const struct lb4_service *svc)
{
 return svc->flags & SVC_FLAG_AFFINITY;
}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_affinity(const struct lb6_service *svc)
{
 return svc->flags & SVC_FLAG_AFFINITY;
}

static inline __attribute__((always_inline))
__u8 svc_is_routable_mask(void)
{
 __u8 mask = SVC_FLAG_ROUTABLE;


 mask |= SVC_FLAG_LOADBALANCER;


 mask |= SVC_FLAG_NODEPORT;


 mask |= SVC_FLAG_EXTERNAL_IP;


 mask |= SVC_FLAG_HOSTPORT;

 return mask;
}

static inline __attribute__((always_inline)) _Bool __lb_svc_is_routable(__u8 flags)
{
 return (flags & svc_is_routable_mask()) > SVC_FLAG_ROUTABLE;
}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_routable(const struct lb4_service *svc)
{
 return __lb_svc_is_routable(svc->flags);
}

static inline __attribute__((always_inline))
_Bool lb6_svc_is_routable(const struct lb6_service *svc)
{
 return __lb_svc_is_routable(svc->flags);
}

static inline __attribute__((always_inline))
_Bool lb4_svc_is_localredirect(const struct lb4_service *svc __attribute__((__unused__)))
{
 return svc->flags2 & SVC_FLAG_LOCALREDIRECT;
}

static inline __attribute__((always_inline)) int extract_l4_port(struct __sk_buff *ctx, __u8 nexthdr,
        int l4_off,
        int dir __attribute__((__unused__)),
        __be16 *port,
        __attribute__((__unused__)) struct iphdr *ip4)
{
 int ret;

 switch (nexthdr) {
 case IPPROTO_TCP:
 case IPPROTO_UDP:

  if (ip4) {
   struct ipv4_frag_l4ports ports = { };

   ret = ipv4_handle_fragmentation(ctx, ip4, l4_off,
       dir, &ports, ((void *)0));
   if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
    return ret;
   *port = ports.dport;
   break;
  }


  ret = l4_load_port(ctx, l4_off + (__builtin_offsetof(struct tcphdr, dest)), port);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;
  break;

 case 58:
 case IPPROTO_ICMP:

  return -158;

 default:

  return -142;
 }

 return 0;
}

static inline __attribute__((always_inline)) int reverse_map_l4_port(struct __sk_buff *ctx, __u8 nexthdr,
            __be16 port, int l4_off,
            struct csum_offset *csum_off)
{
 switch (nexthdr) {
 case IPPROTO_TCP:
 case IPPROTO_UDP:
  if (port) {
   __be16 old_port;
   int ret;


   ret = l4_load_port(ctx, l4_off + (__builtin_offsetof(struct tcphdr, source)), &old_port);
   if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
    return ret;

   if (port != old_port) {
    ret = l4_modify_port(ctx, l4_off, (__builtin_offsetof(struct tcphdr, source)),
           csum_off, port, old_port);
    if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
     return ret;
   }
  }
  break;

 case 58:
 case IPPROTO_ICMP:
  return 0;

 default:
  return -142;
 }

 return 0;
}
# 932 "/var/lib/cilium/bpf/lib/lb.h"
static inline __attribute__((always_inline))
struct lb6_service *lb6_lookup_service(struct lb6_key *key __attribute__((__unused__)),
           const _Bool scope_switch __attribute__((__unused__)))
{
 return ((void *)0);
}

static inline __attribute__((always_inline))
struct lb6_service *__lb6_lookup_backend_slot(struct lb6_key *key __attribute__((__unused__)))
{
 return ((void *)0);
}

static inline __attribute__((always_inline)) struct lb6_backend *
__lb6_lookup_backend(__u16 backend_id __attribute__((__unused__)))
{
 return ((void *)0);
}



static inline __attribute__((always_inline)) int __lb4_rev_nat(struct __sk_buff *ctx, int l3_off, int l4_off,
      struct csum_offset *csum_off,
      struct ipv4_ct_tuple *tuple, int flags,
      const struct lb4_reverse_nat *nat,
      const struct ct_state *ct_state, _Bool has_l4_header)
{
 __be32 old_sip, new_sip, sum = 0;
 int ret;

                                                                 ;

 if (nat->port && has_l4_header) {
  ret = reverse_map_l4_port(ctx, tuple->nexthdr, nat->port, l4_off, csum_off);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;
 }

 if (flags & 1) {
  old_sip = tuple->saddr;
  tuple->saddr = new_sip = nat->address;
 } else {
  ret = skb_load_bytes(ctx, l3_off + __builtin_offsetof(struct iphdr, saddr), &old_sip, 4);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;

  new_sip = nat->address;
 }

 if (ct_state->loopback) {






  __be32 old_dip;

  ret = skb_load_bytes(ctx, l3_off + __builtin_offsetof(struct iphdr, daddr), &old_dip, 4);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;

                                                                 ;

  ret = skb_store_bytes(ctx, l3_off + __builtin_offsetof(struct iphdr, daddr), &old_sip, 4, 0);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return -141;

  sum = csum_diff(&old_dip, 4, &old_sip, 4, 0);


  tuple->saddr = old_sip;
 }

 ret = skb_store_bytes(ctx, l3_off + __builtin_offsetof(struct iphdr, saddr),
         &new_sip, 4, 0);
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
  return -141;

 sum = csum_diff(&old_sip, 4, &new_sip, 4, sum);
 if (l3_csum_replace(ctx, l3_off + __builtin_offsetof(struct iphdr, check), 0, sum, 0) < 0)
  return -153;

 if (csum_off->offset &&
     csum_l4_replace(ctx, l4_off, csum_off, 0, sum, (1ULL << 4)) < 0)
  return -154;

 return 0;
}
# 1032 "/var/lib/cilium/bpf/lib/lb.h"
static inline __attribute__((always_inline)) int lb4_rev_nat(struct __sk_buff *ctx, int l3_off, int l4_off,
           struct csum_offset *csum_off,
           struct ct_state *ct_state,
           struct ipv4_ct_tuple *tuple, int flags, _Bool has_l4_header)
{
 struct lb4_reverse_nat *nat;

                                                                           ;
 nat = map_lookup_elem(&cilium_lb4_reverse_nat, &ct_state->rev_nat_index);
 if (nat == ((void *)0))
  return 0;

 return __lb4_rev_nat(ctx, l3_off, l4_off, csum_off, tuple, flags, nat,
        ct_state, has_l4_header);
}
# 1061 "/var/lib/cilium/bpf/lib/lb.h"
static inline __attribute__((always_inline)) int lb4_extract_key(struct __sk_buff *ctx __attribute__((__unused__)),
        struct iphdr *ip4,
        int l4_off __attribute__((__unused__)),
        struct lb4_key *key,
        struct csum_offset *csum_off,
        int dir)
{

 key->proto = 0;
 key->address = (dir == 1) ? ip4->saddr : ip4->daddr;
 if (ipv4_has_l4_header(ip4))
  csum_l4_offset_and_flags(ip4->protocol, csum_off);

 return extract_l4_port(ctx, ip4->protocol, l4_off, dir, &key->dport, ip4);
}

static inline __attribute__((always_inline))
_Bool lb4_src_range_ok(const struct lb4_service *svc __attribute__((__unused__)),
        __u32 saddr __attribute__((__unused__)))
{

 struct lb4_src_range_key key;

 if (!lb4_svc_has_src_range_check(svc))
  return true;

 key = (typeof(key)) {
  .lpm_key = { (8 * (sizeof(key) - sizeof(struct bpf_lpm_trie_key))), {} },
  .rev_nat_id = svc->rev_nat_index,
  .addr = saddr,
 };

 if (map_lookup_elem(&cilium_lb4_source_range, &key))
  return true;

 return false;



}

static inline __attribute__((always_inline))
struct lb4_service *lb4_lookup_service(struct lb4_key *key,
           const _Bool scope_switch)
{
 struct lb4_service *svc;

 key->scope = 0;
 key->backend_slot = 0;
 svc = map_lookup_elem(&cilium_lb4_services_v2, key);
 if (svc) {
  if (!scope_switch || !lb4_svc_is_local_scope(svc))
   return svc->count ? svc : ((void *)0);
  key->scope = 1;
  svc = map_lookup_elem(&cilium_lb4_services_v2, key);
  if (svc && svc->count)
   return svc;
 }

 return ((void *)0);
}

static inline __attribute__((always_inline)) struct lb4_backend *__lb4_lookup_backend(__u16 backend_id)
{
 return map_lookup_elem(&cilium_lb4_backends, &backend_id);
}

static inline __attribute__((always_inline)) struct lb4_backend *
lb4_lookup_backend(struct __sk_buff *ctx __attribute__((__unused__)), __u16 backend_id)
{
 struct lb4_backend *backend;

 backend = __lb4_lookup_backend(backend_id);
 if (!backend)
                                                                ;

 return backend;
}

static inline __attribute__((always_inline))
struct lb4_service *__lb4_lookup_backend_slot(struct lb4_key *key)
{
 return map_lookup_elem(&cilium_lb4_services_v2, key);
}

static inline __attribute__((always_inline))
struct lb4_service *lb4_lookup_backend_slot(struct __sk_buff *ctx __attribute__((__unused__)),
         struct lb4_key *key, __u16 slot)
{
 struct lb4_service *svc;

 key->backend_slot = slot;
                                                                               ;
 svc = __lb4_lookup_backend_slot(key);
 if (svc)
  return svc;

                                                                                       ;

 return ((void *)0);
}



static inline __attribute__((always_inline)) __u16
lb4_select_backend_id(struct __sk_buff *ctx,
        struct lb4_key *key,
        const struct ipv4_ct_tuple *tuple __attribute__((__unused__)),
        const struct lb4_service *svc)
{
 __u32 slot = (get_prandom_u32() % svc->count) + 1;
 struct lb4_service *be = lb4_lookup_backend_slot(ctx, key, slot);

 return be ? be->backend_id : 0;
}
# 1202 "/var/lib/cilium/bpf/lib/lb.h"
static inline __attribute__((always_inline)) int
lb4_xlate(struct __sk_buff *ctx, __be32 *new_daddr, __be32 *new_saddr __attribute__((__unused__)),
   __be32 *old_saddr __attribute__((__unused__)), __u8 nexthdr __attribute__((__unused__)), int l3_off,
   int l4_off, struct csum_offset *csum_off, struct lb4_key *key,
   const struct lb4_backend *backend __attribute__((__unused__)), _Bool has_l4_header,
   const _Bool skip_l3_xlate)
{
 __be32 sum;
 int ret;

 if (skip_l3_xlate)
  goto l4_xlate;

 ret = skb_store_bytes(ctx, l3_off + __builtin_offsetof(struct iphdr, daddr),
         new_daddr, 4, 0);
 if (ret < 0)
  return -141;

 sum = csum_diff(&key->address, 4, new_daddr, 4, 0);
# 1233 "/var/lib/cilium/bpf/lib/lb.h"
 if (l3_csum_replace(ctx, l3_off + __builtin_offsetof(struct iphdr, check),
       0, sum, 0) < 0)
  return -153;
 if (csum_off->offset) {
  if (csum_l4_replace(ctx, l4_off, csum_off, 0, sum,
        (1ULL << 4)) < 0)
   return -154;
 }

l4_xlate:
 if (__builtin_expect(!!(backend->port), 1) && key->dport != backend->port &&
     (nexthdr == IPPROTO_TCP || nexthdr == IPPROTO_UDP) &&
     has_l4_header) {
  __be16 tmp = backend->port;


  ret = l4_modify_port(ctx, l4_off, (__builtin_offsetof(struct tcphdr, dest)), csum_off,
         tmp, key->dport);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;
 }

 return 0;
}


static inline __attribute__((always_inline)) __u32
__lb4_affinity_backend_id(const struct lb4_service *svc, _Bool netns_cookie,
     const union lb4_affinity_client_id *id)
{
 struct lb4_affinity_key key = {
  .rev_nat_id = svc->rev_nat_index,
  .netns_cookie = netns_cookie,
  .client_id = *id,
 };
 struct lb_affinity_val *val;

 val = map_lookup_elem(&cilium_lb4_affinity, &key);
 if (val != ((void *)0)) {
  __u32 now = ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
  struct lb_affinity_match match = {
   .rev_nat_id = svc->rev_nat_index,
   .backend_id = val->backend_id,
  };






  if (({ typeof(val->last_used) __val = (*(volatile typeof(val->last_used) *)&val->last_used); bpf_barrier(); __val; }) +
      (svc->affinity_timeout) <= now) {
   map_delete_elem(&cilium_lb4_affinity, &key);
   return 0;
  }

  if (!map_lookup_elem(&cilium_lb_affinity_match, &match)) {
   map_delete_elem(&cilium_lb4_affinity, &key);
   return 0;
  }

  ({ typeof(val->last_used) __val = (now); (*(volatile typeof(val->last_used) *)&val->last_used) = (__val); bpf_barrier(); __val; });
  return val->backend_id;
 }

 return 0;
}

static inline __attribute__((always_inline)) __u32
lb4_affinity_backend_id_by_addr(const struct lb4_service *svc,
    union lb4_affinity_client_id *id)
{
 return __lb4_affinity_backend_id(svc, false, id);
}

static inline __attribute__((always_inline)) void
__lb4_update_affinity(const struct lb4_service *svc, _Bool netns_cookie,
        const union lb4_affinity_client_id *id,
        __u32 backend_id)
{
 __u32 now = ({ __u64 __x = ktime_get_ns() / (1000ULL * 1000ULL * 1000UL); __x; });
 struct lb4_affinity_key key = {
  .rev_nat_id = svc->rev_nat_index,
  .netns_cookie = netns_cookie,
  .client_id = *id,
 };
 struct lb_affinity_val val = {
  .backend_id = backend_id,
  .last_used = now,
 };

 map_update_elem(&cilium_lb4_affinity, &key, &val, 0);
}

static inline __attribute__((always_inline)) void
lb4_update_affinity_by_addr(const struct lb4_service *svc,
       union lb4_affinity_client_id *id, __u32 backend_id)
{
 __lb4_update_affinity(svc, false, id, backend_id);
}


static inline __attribute__((always_inline)) __u32
lb4_affinity_backend_id_by_netns(const struct lb4_service *svc __attribute__((__unused__)),
     union lb4_affinity_client_id *id __attribute__((__unused__)))
{

 return __lb4_affinity_backend_id(svc, true, id);



}

static inline __attribute__((always_inline)) void
lb4_update_affinity_by_netns(const struct lb4_service *svc __attribute__((__unused__)),
        union lb4_affinity_client_id *id __attribute__((__unused__)),
        __u32 backend_id __attribute__((__unused__)))
{

 __lb4_update_affinity(svc, true, id, backend_id);

}

static inline __attribute__((always_inline)) int lb4_local(const void *map, struct __sk_buff *ctx,
         int l3_off, int l4_off,
         struct csum_offset *csum_off,
         struct lb4_key *key,
         struct ipv4_ct_tuple *tuple,
         const struct lb4_service *svc,
         struct ct_state *state, __be32 saddr,
         _Bool has_l4_header,
         const _Bool skip_l3_xlate)
{
 __u32 monitor;
 __be32 new_saddr = 0, new_daddr;
 __u8 flags = tuple->flags;
 struct lb4_backend *backend;
 __u32 backend_id = 0;
 int ret;

 union lb4_affinity_client_id client_id = {
  .client_ip = saddr,
 };

 ret = ct_lookup4(map, tuple, ctx, l4_off, 2, state, &monitor);
 switch (ret) {
 case CT_NEW:

  if (lb4_svc_is_affinity(svc)) {
   backend_id = lb4_affinity_backend_id_by_addr(svc, &client_id);
   if (backend_id != 0) {
    backend = lb4_lookup_backend(ctx, backend_id);
    if (backend == ((void *)0))
     backend_id = 0;
   }
  }

  if (backend_id == 0) {

   backend_id = lb4_select_backend_id(ctx, key, tuple, svc);
   backend = lb4_lookup_backend(ctx, backend_id);
   if (backend == ((void *)0))
    goto drop_no_service;
  }

  state->backend_id = backend_id;
  state->rev_nat_index = svc->rev_nat_index;

  ret = ct_create4(map, ((void *)0), tuple, ctx, 2, state, false);



  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   goto drop_no_service;
  goto update_state;
 case CT_REOPENED:
 case CT_ESTABLISHED:
 case CT_RELATED:
 case CT_REPLY:






  if (__builtin_expect(!!(state->rev_nat_index == 0), 0)) {
   state->rev_nat_index = svc->rev_nat_index;
   ct_update4_rev_nat_index(map, tuple, state);
  }
  break;
 default:
  goto drop_no_service;
 }
# 1434 "/var/lib/cilium/bpf/lib/lb.h"
 if (state->rev_nat_index != svc->rev_nat_index) {

  if (lb4_svc_is_affinity(svc))
   backend_id = lb4_affinity_backend_id_by_addr(svc,
             &client_id);

  if (!backend_id) {
   backend_id = lb4_select_backend_id(ctx, key, tuple, svc);
   if (!backend_id)
    goto drop_no_service;
  }

  state->backend_id = backend_id;
  ct_update4_backend_id(map, tuple, state);
  state->rev_nat_index = svc->rev_nat_index;
  ct_update4_rev_nat_index(map, tuple, state);
 }




 backend = lb4_lookup_backend(ctx, state->backend_id);
 if (!backend) {
  key->backend_slot = 0;
  svc = lb4_lookup_service(key, false);
  if (!svc)
   goto drop_no_service;
  backend_id = lb4_select_backend_id(ctx, key, tuple, svc);
  backend = lb4_lookup_backend(ctx, backend_id);
  if (!backend)
   goto drop_no_service;
  state->backend_id = backend_id;
  ct_update4_backend_id(map, tuple, state);
 }

update_state:



 tuple->flags = flags;
 state->rev_nat_index = svc->rev_nat_index;
 state->addr = new_daddr = backend->address;


 if (lb4_svc_is_affinity(svc))
  lb4_update_affinity_by_addr(svc, &client_id,
         state->backend_id);
# 1500 "/var/lib/cilium/bpf/lib/lb.h"
  tuple->daddr = backend->address;

 return lb_skip_l4_dnat() ? 0 :
        lb4_xlate(ctx, &new_daddr, &new_saddr, &saddr,
    tuple->nexthdr, l3_off, l4_off, csum_off, key,
    backend, has_l4_header, skip_l3_xlate);
drop_no_service:
  tuple->flags = flags;
  return -158;
}
# 58 "/var/lib/cilium/bpf/bpf_host.c" 2
# 1 "/var/lib/cilium/bpf/lib/nodeport.h" 1
# 10 "/var/lib/cilium/bpf/lib/nodeport.h"
# 1 "/var/lib/cilium/bpf/lib/tailcall.h" 1
# 11 "/var/lib/cilium/bpf/lib/nodeport.h" 2
# 21 "/var/lib/cilium/bpf/lib/nodeport.h"
# 1 "/var/lib/cilium/bpf/lib/ghash.h" 1
# 31 "/var/lib/cilium/bpf/lib/ghash.h"
static inline __attribute__((always_inline)) __u32 hash_32(__u32 val, __u32 bits)
{

 return (val * 0x61C88647) >> (32 - bits);
}

static inline __attribute__((always_inline)) __u32 hash_64(__u64 val, __u32 bits)
{
 return (val * 0x61C8864680B583EBull) >> (64 - bits);
}
# 22 "/var/lib/cilium/bpf/lib/nodeport.h" 2
# 1 "/var/lib/cilium/bpf/lib/pcap.h" 1
# 13 "/var/lib/cilium/bpf/lib/pcap.h"
struct pcap_timeval {
 __u32 tv_sec;
 __u32 tv_usec;
};

struct pcap_timeoff {
 __u64 tv_boot;
};

struct pcap_pkthdr {
 union {




  struct pcap_timeval ts;
  struct pcap_timeoff to;
 };
 __u32 caplen;
 __u32 len;
};

struct capture_msg {



 __u8 type; __u8 subtype; __u16 source; __u32 hash;



 struct pcap_pkthdr hdr;
};

static inline __attribute__((always_inline)) void cilium_capture(struct __sk_buff *ctx,
        const __u8 subtype,
        const __u16 rule_id,
        const __u64 tstamp,
        __u64 __cap_len)
{
 __u64 ctx_len = ctx_full_len(ctx);
 __u64 cap_len = (!__cap_len || ctx_len < __cap_len) ?
   ctx_len : __cap_len;



 struct capture_msg msg = {
  .type = CILIUM_NOTIFY_CAPTURE,
  .subtype = subtype,
  .source = rule_id,
  .hdr = {
   .to = {
    .tv_boot = tstamp,
   },
   .caplen = cap_len,
   .len = ctx_len,
  },
 };

 skb_event_output(ctx, &cilium_events, (cap_len << 32) | BPF_F_CURRENT_CPU,
    &msg, sizeof(msg));
}

static inline __attribute__((always_inline)) void __cilium_capture_in(struct __sk_buff *ctx,
      __u16 rule_id, __u32 cap_len)
{




 cilium_capture(ctx, CAPTURE_INGRESS, rule_id,
         ({ __u32 __z = 0; __u64 *__cache = map_lookup_elem(&cilium_ktime_cache, &__z); __u64 __ktime = ktime_get_boot_ns(); if (__builtin_expect(!!(__cache), 1)) *__cache = __ktime; __ktime; }), cap_len);
}

static inline __attribute__((always_inline)) void __cilium_capture_out(struct __sk_buff *ctx,
       __u16 rule_id, __u32 cap_len)
{
 cilium_capture(ctx, CAPTURE_EGRESS, rule_id,
         ({ __u32 __z = 0; __u64 *__cache = map_lookup_elem(&cilium_ktime_cache, &__z); __u64 __ktime = 0; if (__builtin_expect(!!(__cache), 1)) __ktime = *__cache; __ktime; }), cap_len);
}
# 102 "/var/lib/cilium/bpf/lib/pcap.h"
struct capture_cache {
 _Bool rule_seen;
 __u16 rule_id;
 __u16 cap_len;
};

struct bpf_elf_map __attribute__((section("maps"), used)) cilium_capture_cache = {
 .type = BPF_MAP_TYPE_PERCPU_ARRAY,
 .size_key = sizeof(__u32),
 .size_value = sizeof(struct capture_cache),
 .pinning = 2,
 .max_elem = 1,
};

struct capture_rule {
 __u16 rule_id;
 __u16 reserved;
 __u32 cap_len;
};


struct capture4_wcard {
 __be32 saddr;
 __be32 daddr;
 __be16 sport;
 __be16 dport;
 __u8 nexthdr;
 __u8 smask;
 __u8 dmask;
 __u8 flags;
};


struct capture6_wcard {
 union v6addr saddr;
 union v6addr daddr;
 __be16 sport;
 __be16 dport;
 __u8 nexthdr;
 __u8 smask;
 __u8 dmask;
 __u8 flags;
};
# 383 "/var/lib/cilium/bpf/lib/pcap.h"
static inline __attribute__((always_inline)) struct capture_rule *
cilium_capture_classify_wcard(struct __sk_buff *ctx)
{
 struct capture_rule *ret = ((void *)0);
 __u16 proto;

 if (!validate_ethertype(ctx, &proto))
  return ret;
 switch (proto) {
# 402 "/var/lib/cilium/bpf/lib/pcap.h"
 default:
  break;
 }
 return ret;
}

static inline __attribute__((always_inline)) _Bool
cilium_capture_candidate(struct __sk_buff *ctx __attribute__((__unused__)),
    __u16 *rule_id __attribute__((__unused__)),
    __u32 *cap_len __attribute__((__unused__)))
{
 if ((1 == 2)) {
  struct capture_cache *c;
  struct capture_rule *r;
  __u32 zero = 0;

  c = map_lookup_elem(&cilium_capture_cache, &zero);
  if (__builtin_expect(!!(c), 1)) {
   r = cilium_capture_classify_wcard(ctx);
   c->rule_seen = r;
   if (r) {
    c->cap_len = *cap_len = r->cap_len;
    c->rule_id = *rule_id = r->rule_id;
    return true;
   }
  }
 }
 return false;
}

static inline __attribute__((always_inline)) _Bool
cilium_capture_cached(struct __sk_buff *ctx __attribute__((__unused__)),
        __u16 *rule_id __attribute__((__unused__)),
        __u32 *cap_len __attribute__((__unused__)))
{
 if ((1 == 2)) {
  struct capture_cache *c;
  __u32 zero = 0;





  c = map_lookup_elem(&cilium_capture_cache, &zero);
  if (__builtin_expect(!!(c), 1) && c->rule_seen) {
   *cap_len = c->cap_len;
   *rule_id = c->rule_id;
   return true;
  }
 }
 return false;
}

static inline __attribute__((always_inline)) void
cilium_capture_in(struct __sk_buff *ctx __attribute__((__unused__)))
{







}

static inline __attribute__((always_inline)) void
cilium_capture_out(struct __sk_buff *ctx __attribute__((__unused__)))
{
# 481 "/var/lib/cilium/bpf/lib/pcap.h"
}
# 23 "/var/lib/cilium/bpf/lib/nodeport.h" 2
# 1 "/var/lib/cilium/bpf/lib/host_firewall.h" 1
# 24 "/var/lib/cilium/bpf/lib/nodeport.h" 2
# 42 "/var/lib/cilium/bpf/lib/nodeport.h"
static inline __attribute__((always_inline)) __attribute__((__unused__)) void
bpf_skip_nodeport_clear(struct __sk_buff *ctx)
{
 ctx_skip_nodeport_clear(ctx);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) void
bpf_skip_nodeport_set(struct __sk_buff *ctx)
{
 ctx_skip_nodeport_set(ctx);
}

static inline __attribute__((always_inline)) __attribute__((__unused__)) _Bool
bpf_skip_nodeport(struct __sk_buff *ctx)
{
 return ctx_skip_nodeport(ctx);
}



struct bpf_elf_map __attribute__((section("maps"), used)) cilium_nodeport_neigh4 = {
 .type = BPF_MAP_TYPE_LRU_HASH,
 .size_key = sizeof(__be32),
 .size_value = sizeof(union macaddr),
 .pinning = 2,
 .max_elem = 131072,
};
# 91 "/var/lib/cilium/bpf/lib/nodeport.h"
static inline __attribute__((always_inline)) _Bool nodeport_uses_dsr(__u8 nexthdr __attribute__((__unused__)))
{







 return false;

}

static inline __attribute__((always_inline)) _Bool nodeport_lb_hairpin(void)
{
 return 1;
}

static inline __attribute__((always_inline)) _Bool fib_lookup_bypass(void)
{
 return 1;
}

static inline __attribute__((always_inline)) void
bpf_mark_snat_done(struct __sk_buff *ctx __attribute__((__unused__)))
{




 ctx->mark |= 0x1500;

}

static inline __attribute__((always_inline)) _Bool
bpf_skip_recirculation(const struct __sk_buff *ctx __attribute__((__unused__)))
{




 return ctx->tc_index & 8;



}

static inline __attribute__((always_inline)) __u64 ctx_adjust_hroom_dsr_flags(void)
{



 return 0;

}

static inline __attribute__((always_inline)) _Bool dsr_fail_needs_reply(int code __attribute__((__unused__)))
{




 return false;
}

static inline __attribute__((always_inline)) _Bool dsr_is_too_big(struct __sk_buff *ctx __attribute__((__unused__)),
        __u16 expanded_len __attribute__((__unused__)))
{




 return false;
}

static inline __attribute__((always_inline)) int
maybe_add_l2_hdr(struct __sk_buff *ctx __attribute__((__unused__)),
   __u32 ifindex __attribute__((__unused__)),
   _Bool *l2_hdr_required __attribute__((__unused__)))
{
 if (false)



  *l2_hdr_required = false;
 else if (14 == 0) {



  __u16 proto = ctx_get_protocol(ctx);

  if (ctx_change_head(ctx, 14, 0))
   return -134;

  if (eth_store_proto(ctx, proto, 0) < 0)
   return -141;
 }

 return 0;
}
# 1083 "/var/lib/cilium/bpf/lib/nodeport.h"
static inline __attribute__((always_inline)) _Bool nodeport_uses_dsr4(const struct ipv4_ct_tuple *tuple)
{
 return nodeport_uses_dsr(tuple->nexthdr);
}





static inline __attribute__((always_inline)) _Bool snat_v4_needed(struct __sk_buff *ctx, __be32 *addr,
        _Bool *from_endpoint __attribute__((__unused__)))
{
 struct endpoint_info *ep __attribute__((__unused__));
 void *data, *data_end;
 struct iphdr *ip4;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return false;
# 1109 "/var/lib/cilium/bpf/lib/nodeport.h"
 if (1) {
  struct egress_info *info;

  info = egress_lookup4(&cilium_egress_v4, ip4->saddr, ip4->daddr);
  if (info && ctx->ifindex != 17) {
   *addr = info->egress_ip;
   *from_endpoint = true;
   return true;
  }
 }
# 1135 "/var/lib/cilium/bpf/lib/nodeport.h"
 if (3 == (__u32)(__u64)(&(NATIVE_DEV_IFINDEX)) &&
     ip4->saddr == 1717807296) {
  *addr = 1717807296;
  return true;
 }

 if (ip4->saddr == (__u32)(__u64)(&(IPV4_MASQUERADE))) {
  *addr = (__u32)(__u64)(&(IPV4_MASQUERADE));
  return true;
 }
# 1164 "/var/lib/cilium/bpf/lib/nodeport.h"
 if (ipv4_is_in_subnet(ip4->daddr, 0xa,
         24))
  return false;


 ep = __lookup_ip4_endpoint(ip4->saddr);
 if (ep && !(ep->flags & 1)) {
  struct remote_endpoint_info *info;
  *from_endpoint = true;

  info = ipcache_lookup4(&cilium_ipcache, ip4->daddr,
           (sizeof(__u32)*8));
  if (info) {
# 1202 "/var/lib/cilium/bpf/lib/nodeport.h"
   *addr = (__u32)(__u64)(&(IPV4_MASQUERADE));
   return true;
  }
 }


 return false;
}

static inline __attribute__((always_inline)) int nodeport_nat_ipv4_fwd(struct __sk_buff *ctx)
{
 _Bool from_endpoint = false;
 struct ipv4_nat_target target = {
  .min_port = 32768,
  .max_port = 65535,
  .addr = 0,
 };
 int ret = 0;

 if (snat_v4_needed(ctx, &target.addr, &from_endpoint))
  ret = snat_v4_process(ctx, NAT_DIR_EGRESS, &target,
          from_endpoint);
 if (ret == -173)
  ret = 0;

 return ret;
}
# 1594 "/var/lib/cilium/bpf/lib/nodeport.h"
__attribute__((section("2" "/" "15"), used))
int tail_nodeport_nat_ipv4(struct __sk_buff *ctx)
{
 int ret, dir = ctx_load_meta(ctx, CB_NAT46_STATE);
 struct bpf_fib_lookup_padded fib_params = {
  .l = {
   .family = 2,
   .ifindex = 3,
  },
 };
 struct ipv4_nat_target target = {
  .min_port = 32768,
  .max_port = 65535,
  .src_from_world = true,
 };
 union macaddr *dmac = ((void *)0);
 void *data, *data_end;
 struct iphdr *ip4;
 _Bool l2_hdr_required = true;

 target.addr = 1717807296;

 if (dir == NAT_DIR_EGRESS) {
  struct remote_endpoint_info *info;

  if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false)) {
   ret = -134;
   goto drop_err;
  }

  info = ipcache_lookup4(&cilium_ipcache, ip4->daddr, (sizeof(__u32)*8));
  if (info != ((void *)0) && info->tunnel_endpoint != 0) {
   ret = __encap_with_nodeid(ctx, info->tunnel_endpoint,
        (__u32)(__u64)(&(SECLABEL)), 128ULL);
   if (ret)
    goto drop_err;

   target.addr = 0x2a00000a;
   fib_params.l.ifindex = 17;


   if (eth_store_daddr(ctx, fib_params.l.dmac, 0) < 0) {
    ret = -141;
    goto drop_err;
   }
   if (eth_store_saddr(ctx, fib_params.l.smac, 0) < 0) {
    ret = -141;
    goto drop_err;
   }
  }
 }




 ret = snat_v4_process(ctx, dir, &target, false);
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0))) {





  if (dir == NAT_DIR_INGRESS) {
   bpf_skip_nodeport_set(ctx);
   ep_tail_call(ctx, 7);
   ret = -140;
   goto drop_err;
  }
  if (ret != -173)
   goto drop_err;
 }

 bpf_mark_snat_done(ctx);

 if (dir == NAT_DIR_INGRESS) {

  ep_tail_call(ctx, 17);
  ret = -140;
  goto drop_err;
 }

 if (fib_params.l.ifindex == 17)
  goto out_send;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false)) {
  ret = -134;
  goto drop_err;
 }

 ret = maybe_add_l2_hdr(ctx, 3,
          &l2_hdr_required);
 if (ret != 0)
  goto drop_err;
 if (!l2_hdr_required)
  goto out_send;
 else if (!____revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false, 14))

  return -134;

 if (nodeport_lb_hairpin())
  dmac = map_lookup_elem(&cilium_nodeport_neigh4, &ip4->daddr);
 if (dmac) {
  union macaddr mac = ({ union macaddr __mac = {.addr = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0}}; switch (fib_params.l.ifindex) { case 3: {union macaddr __tmp = {.addr = {0x8,0x0,0x27,0x38,0xb5,0x35}}; __mac=__tmp;} break; } __mac; });

  if (eth_store_daddr_aligned(ctx, dmac->addr, 0) < 0) {
   ret = -141;
   goto drop_err;
  }
  if (eth_store_saddr_aligned(ctx, mac.addr, 0) < 0) {
   ret = -141;
   goto drop_err;
  }
 } else {
  fib_params.l.ipv4_src = ip4->saddr;
  fib_params.l.ipv4_dst = ip4->daddr;

  ret = fib_lookup(ctx, &fib_params.l, sizeof(fib_params),
     BPF_FIB_LOOKUP_DIRECT | BPF_FIB_LOOKUP_OUTPUT);
  if (ret != 0) {
   ret = -169;
   goto drop_err;
  }
  if (nodeport_lb_hairpin())
   map_update_elem(&cilium_nodeport_neigh4, &ip4->daddr,
     fib_params.l.dmac, 0);

  if (eth_store_daddr(ctx, fib_params.l.dmac, 0) < 0) {
   ret = -141;
   goto drop_err;
  }
  if (eth_store_saddr(ctx, fib_params.l.smac, 0) < 0) {
   ret = -141;
   goto drop_err;
  }
 }
out_send:
 cilium_capture_out(ctx);
 return ctx_redirect(ctx, fib_params.l.ifindex, 0);
drop_err:
 return send_drop_notify_error(ctx, 0, ret, 2,
          dir == NAT_DIR_INGRESS ?
          1 : 2);
}





static inline __attribute__((always_inline)) int nodeport_lb4(struct __sk_buff *ctx,
     __u32 src_identity)
{
 struct ipv4_ct_tuple tuple = {};
 void *data, *data_end;
 struct iphdr *ip4;
 int ret, l3_off = 14, l4_off;
 struct csum_offset csum_off = {};
 struct lb4_service *svc;
 struct lb4_key key = {};
 struct ct_state ct_state_new = {};
 union macaddr smac, *mac;
 _Bool backend_local;
 __u32 monitor = 0;

 cilium_capture_in(ctx);

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;

 tuple.nexthdr = ip4->protocol;
 tuple.daddr = ip4->daddr;
 tuple.saddr = ip4->saddr;

 l4_off = l3_off + ipv4_hdrlen(ip4);

 ret = lb4_extract_key(ctx, ip4, l4_off, &key, &csum_off, 0);
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0))) {
  if (ret == -158)
   goto skip_service_lookup;
  else if (ret == -142)
   return 0;
  else
   return ret;
 }

 svc = lb4_lookup_service(&key, false);
 if (svc) {
  const _Bool skip_l3_xlate = 0 == 2;

  if (!lb4_src_range_ok(svc, ip4->saddr))
   return -177;

  ret = lb4_local(get_ct_map4(&tuple), ctx, l3_off, l4_off,
    &csum_off, &key, &tuple, svc, &ct_state_new,
    ip4->saddr, ipv4_has_l4_header(ip4),
    skip_l3_xlate);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;
 }

 if (!svc || !lb4_svc_is_routable(svc)) {
  if (svc)
   return -174;





skip_service_lookup:
  ctx_set_xfer(ctx, 1);






  ctx_store_meta(ctx, CB_NAT46_STATE, NAT_DIR_INGRESS);
  ctx_store_meta(ctx, 0, src_identity);
  ep_tail_call(ctx, 15);
  return -140;
 }

 backend_local = __lookup_ip4_endpoint(tuple.daddr);
 if (!backend_local && lb4_svc_is_hostport(svc))
  return -134;




 if (backend_local || !nodeport_uses_dsr4(&tuple)) {
  struct ct_state ct_state = {};

  ret = ct_lookup4(get_ct_map4(&tuple), &tuple, ctx, l4_off,
     0, &ct_state, &monitor);
  switch (ret) {
  case CT_NEW:
redo_all:
   ct_state_new.src_sec_id = (__u32)(__u64)(&(SECLABEL));
   ct_state_new.node_port = 1;
   ct_state_new.ifindex = (__u32)(__u64)(&(NATIVE_DEV_IFINDEX));
   ret = ct_create4(get_ct_map4(&tuple), ((void *)0), &tuple, ctx,
      0, &ct_state_new, false);
   if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
    return ret;
   if (backend_local) {
    ct_flip_tuple_dir4(&tuple);
redo_local:



    ct_state_new.rev_nat_index = 0;
    ret = ct_create4(get_ct_map4(&tuple), ((void *)0),
       &tuple, ctx, 1,
       &ct_state_new, false);
    if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
     return ret;
   }
   break;
  case CT_REOPENED:
  case CT_ESTABLISHED:
  case CT_REPLY:



   if (__builtin_expect(!!(ct_state.rev_nat_index != svc->rev_nat_index), 0))

    goto redo_all;
   if (backend_local) {
    ct_flip_tuple_dir4(&tuple);
    if (!__ct_entry_keep_alive(get_ct_map4(&tuple),
          &tuple)) {
     ct_state_new.src_sec_id = (__u32)(__u64)(&(SECLABEL));
     ct_state_new.node_port = 1;
     ct_state_new.ifindex = (__u32)(__u64)(&(NATIVE_DEV_IFINDEX));
     goto redo_local;
    }
   }
   break;
  default:
   return -163;
  }

  if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
   return -134;
  if (eth_load_saddr(ctx, smac.addr, 0) < 0)
   return -134;

  mac = map_lookup_elem(&cilium_nodeport_neigh4, &ip4->saddr);
  if (!mac || eth_addrcmp(mac, &smac)) {
   ret = map_update_elem(&cilium_nodeport_neigh4, &ip4->saddr,
           &smac, 0);
   if (ret < 0)
    return ret;
  }
 }

 if (!backend_local) {
  edt_set_aggregate(ctx, 0);
  if (nodeport_uses_dsr4(&tuple)) {
# 1900 "/var/lib/cilium/bpf/lib/nodeport.h"
   ep_tail_call(ctx, 20);
  } else {
   ctx_store_meta(ctx, CB_NAT46_STATE, NAT_DIR_EGRESS);
   ep_tail_call(ctx, 15);
  }
  return -140;
 }

 ctx_set_xfer(ctx, 1);

 return 0;
}
# 1921 "/var/lib/cilium/bpf/lib/nodeport.h"
static inline __attribute__((always_inline)) int rev_nodeport_lb4(struct __sk_buff *ctx, int *ifindex)
{
 struct ipv4_ct_tuple tuple = {};
 void *data, *data_end;
 struct iphdr *ip4;
 struct csum_offset csum_off = {};
 int ret, ret2, l3_off = 14, l4_off;
 struct ct_state ct_state = {};
 struct bpf_fib_lookup fib_params = {};
 union macaddr *dmac = ((void *)0);
 __u32 monitor = 0;
 _Bool l2_hdr_required = true;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;

 tuple.nexthdr = ip4->protocol;
 tuple.daddr = ip4->daddr;
 tuple.saddr = ip4->saddr;

 l4_off = l3_off + ipv4_hdrlen(ip4);
 csum_l4_offset_and_flags(tuple.nexthdr, &csum_off);

 ret = ct_lookup4(get_ct_map4(&tuple), &tuple, ctx, l4_off, 1, &ct_state,
    &monitor);

 if (ret == CT_REPLY && ct_state.node_port == 1 && ct_state.rev_nat_index != 0) {
  ret2 = lb4_rev_nat(ctx, l3_off, l4_off, &csum_off,
       &ct_state, &tuple,
       1, ipv4_has_l4_header(ip4));
  if ((__builtin_expect(!!((ret2 < 0) || (ret2 == 2)), 0)))
   return ret2;

  if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
   return -134;

  bpf_mark_snat_done(ctx);

  *ifindex = ct_state.ifindex;

  {
   struct remote_endpoint_info *info;

   info = ipcache_lookup4(&cilium_ipcache, ip4->daddr, (sizeof(__u32)*8));
   if (info != ((void *)0) && info->tunnel_endpoint != 0) {
    ret = __encap_with_nodeid(ctx, info->tunnel_endpoint,
         (__u32)(__u64)(&(SECLABEL)), 128ULL);
    if (ret)
     return ret;

    *ifindex = 17;


    if (eth_store_daddr(ctx, fib_params.dmac, 0) < 0)
     return -141;
    if (eth_store_saddr(ctx, fib_params.smac, 0) < 0)
     return -141;

    return 0;
   }
  }


  ret = maybe_add_l2_hdr(ctx, *ifindex, &l2_hdr_required);
  if (ret != 0)
   return ret;
  if (!l2_hdr_required)
   return 0;
  else if (!____revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false, 14))

   return -134;

  if (fib_lookup_bypass())
   dmac = map_lookup_elem(&cilium_nodeport_neigh4, &ip4->daddr);
  if (dmac) {
   union macaddr mac = ({ union macaddr __mac = {.addr = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0}}; switch (*ifindex) { case 3: {union macaddr __tmp = {.addr = {0x8,0x0,0x27,0x38,0xb5,0x35}}; __mac=__tmp;} break; } __mac; });

   if (eth_store_daddr_aligned(ctx, dmac->addr, 0) < 0)
    return -141;
   if (eth_store_saddr_aligned(ctx, mac.addr, 0) < 0)
    return -141;
  } else {
   fib_params.family = 2;
   fib_params.ifindex = *ifindex;

   fib_params.ipv4_src = ip4->saddr;
   fib_params.ipv4_dst = ip4->daddr;

   ret = fib_lookup(ctx, &fib_params, sizeof(fib_params),
      BPF_FIB_LOOKUP_DIRECT |
      BPF_FIB_LOOKUP_OUTPUT);
   if (ret != 0)
    return -169;

   if (eth_store_daddr(ctx, fib_params.dmac, 0) < 0)
    return -141;
   if (eth_store_saddr(ctx, fib_params.smac, 0) < 0)
    return -141;
  }
 } else {
  if (!bpf_skip_recirculation(ctx)) {
   bpf_skip_nodeport_set(ctx);
   ep_tail_call(ctx, 7);
   return -140;
  }
 }

 return 0;
}

__attribute__((section("2" "/" "17"), used))
int tail_rev_nodeport_lb4(struct __sk_buff *ctx)
{
 int ifindex = 0;
 int ret = 0;
# 2051 "/var/lib/cilium/bpf/lib/nodeport.h"
 ret = rev_nodeport_lb4(ctx, &ifindex);
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
  return send_drop_notify_error(ctx, 0, ret, 2, 2);

 edt_set_aggregate(ctx, 0);
 cilium_capture_out(ctx);

 return ctx_redirect(ctx, ifindex, 0);
}

__attribute__((section("2" "/" "19"), used))





int tail_handle_nat_fwd_ipv4(struct __sk_buff *ctx)
{
 return nodeport_nat_ipv4_fwd(ctx);
}
# 2165 "/var/lib/cilium/bpf/lib/nodeport.h"
static inline __attribute__((always_inline)) int handle_nat_fwd(struct __sk_buff *ctx)
{
 int ret = 0;
 __u16 proto;

 if (!validate_ethertype(ctx, &proto))
  return 0;
 switch (proto) {

 case (__builtin_constant_p(0x0800) ? ((__be16)((__u16)( (((__u16)((0x0800)) & (__u16)0x00ffU) << 8) | (((__u16)((0x0800)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x0800)):
  do { ep_tail_call(ctx, 19); ret = -140; } while (0);






  break;
# 2194 "/var/lib/cilium/bpf/lib/nodeport.h"
 default:
  ((void)sizeof(char[1 - 2*!!(!(32768 < 65535))]));
  ((void)sizeof(char[1 - 2*!!(!(30000 < 32767))]));
  ((void)sizeof(char[1 - 2*!!(!(32767 < 32768))]));
  break;
 }
 return ret;
}
# 59 "/var/lib/cilium/bpf/bpf_host.c" 2



# 1 "/var/lib/cilium/bpf/lib/encrypt.h" 1
# 77 "/var/lib/cilium/bpf/lib/encrypt.h"
static inline __attribute__((always_inline)) int
do_decrypt(struct __sk_buff __attribute__((__unused__)) *ctx, __u16 __attribute__((__unused__)) proto)
{
 return 0;
}
# 63 "/var/lib/cilium/bpf/bpf_host.c" 2


static inline __attribute__((always_inline)) int rewrite_dmac_to_host(struct __sk_buff *ctx,
      __u32 src_identity)
{




 union macaddr cilium_net_mac = { .addr = {0x3e,0x3d,0x0a,0xdc,0x31,0xba}};


 if (eth_store_daddr(ctx, (__u8 *) &cilium_net_mac.addr, 0) < 0)
  return send_drop_notify_error(ctx, src_identity, -141,
           0, 1);

 return 0;
}






static inline __attribute__((always_inline)) _Bool identity_from_ipcache_ok(void)
{
 return (__u32)(__u64)(&(SECCTX_FROM_IPCACHE)) == 2;
}
# 389 "/var/lib/cilium/bpf/bpf_host.c"
static inline __attribute__((always_inline)) __u32
resolve_srcid_ipv4(struct __sk_buff *ctx, __u32 srcid_from_proxy,
     __u32 *sec_label, const _Bool from_host)
{
 __u32 src_id = 2, srcid_from_ipcache = srcid_from_proxy;
 struct remote_endpoint_info *info = ((void *)0);
 void *data, *data_end;
 struct iphdr *ip4;






 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), !from_host))
  return -134;


 if (identity_is_reserved(srcid_from_ipcache)) {
  info = ipcache_lookup4(&cilium_ipcache, ip4->saddr, (sizeof(__u32)*8));
  if (info != ((void *)0)) {
   *sec_label = info->sec_label;

   if (*sec_label) {
# 422 "/var/lib/cilium/bpf/bpf_host.c"
    if (*sec_label != 1)
     srcid_from_ipcache = *sec_label;





   }
  }
  cilium_dbg(ctx, info ? DBG_IP_ID_MAP_SUCCEED4 : DBG_IP_ID_MAP_FAILED4,
      ip4->saddr, srcid_from_ipcache);
 }

 if (from_host)
  src_id = srcid_from_ipcache;



 else if (identity_from_ipcache_ok() &&
   !identity_is_reserved(srcid_from_ipcache))
  src_id = srcid_from_ipcache;
 return src_id;
}

static inline __attribute__((always_inline)) int
handle_ipv4(struct __sk_buff *ctx, __u32 secctx,
     __u32 ipcache_srcid __attribute__((__unused__)), const _Bool from_host)
{
 struct remote_endpoint_info *info = ((void *)0);
 __u32 __attribute__((__unused__)) remoteID = 0;
 struct ipv4_ct_tuple tuple = {};
 _Bool skip_redirect = false;
 struct endpoint_info *ep;
 void *data, *data_end;
 struct iphdr *ip4;
 int ret;

 if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
  return -134;
# 472 "/var/lib/cilium/bpf/bpf_host.c"
 if (!from_host) {
  if (ctx_get_xfer(ctx) != 1 &&
      !bpf_skip_nodeport(ctx)) {
   ret = nodeport_lb4(ctx, secctx);
   if (ret < 0)
    return ret;
  }
# 489 "/var/lib/cilium/bpf/bpf_host.c"
  skip_redirect = true;


  if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
   return -134;
 }
# 511 "/var/lib/cilium/bpf/bpf_host.c"
 if (skip_redirect)
  return 0;

 tuple.nexthdr = ip4->protocol;

 if (from_host) {



  ret = rewrite_dmac_to_host(ctx, secctx);

  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return ret;

  if (!__revalidate_data_pull(ctx, &data, &data_end, (void **)&ip4, sizeof(**&ip4), false))
   return -134;
 }


 ep = lookup_ip4_endpoint(ip4);
 if (ep) {



  if (ep->flags & 1)
   return 0;

  return ipv4_local_delivery(ctx, 14, secctx, ip4, ep,
        1, from_host);
 }




 if (!from_host)
  return 0;


 info = ipcache_lookup4(&cilium_ipcache, ip4->daddr, (sizeof(__u32)*8));
 if (info != ((void *)0) && info->tunnel_endpoint != 0) {
  ret = encap_and_redirect_with_nodeid(ctx, info->tunnel_endpoint,
           info->key, secctx,
           128ULL);

  if (ret == 0)
   return 0;
  else
   return ret;
 } else {

  struct endpoint_key key = {};

  key.ip4 = ip4->daddr & 0xffffff;
  key.family = 1;

  cilium_dbg(ctx, DBG_NETDEV_ENCAP4, key.ip4, secctx);
  ret = encap_and_redirect_netdev(ctx, &key, secctx, 128ULL);
  if (ret == 0)
   return 0;
  else if (ret != -160)
   return ret;
 }


 info = ipcache_lookup4(&cilium_ipcache, ip4->daddr, (sizeof(__u32)*8));
 if (info == ((void *)0) || info->sec_label == 2) {
# 586 "/var/lib/cilium/bpf/bpf_host.c"
  return -151;
 }
# 601 "/var/lib/cilium/bpf/bpf_host.c"
 return 0;
}

static inline __attribute__((always_inline)) int
tail_handle_ipv4(struct __sk_buff *ctx, __u32 ipcache_srcid, const _Bool from_host)
{
 __u32 proxy_identity = ctx_load_meta(ctx, 0);
 int ret;

 ctx_store_meta(ctx, 0, 0);

 ret = handle_ipv4(ctx, proxy_identity, ipcache_srcid, from_host);
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
  return send_drop_notify_error(ctx, proxy_identity,
           ret, 2, 1);
 return ret;
}

__attribute__((section("2" "/" "22"), used))
int tail_handle_ipv4_from_host(struct __sk_buff *ctx)
{
 __u32 ipcache_srcid = 0;






 return tail_handle_ipv4(ctx, ipcache_srcid, true);
}

__attribute__((section("2" "/" "7"), used))
int tail_handle_ipv4_from_netdev(struct __sk_buff *ctx)
{
 return tail_handle_ipv4(ctx, 0, false);
}
# 810 "/var/lib/cilium/bpf/bpf_host.c"
static inline __attribute__((always_inline)) int
do_netdev(struct __sk_buff *ctx, __u16 proto, const _Bool from_host)
{
 __u32 __attribute__((__unused__)) identity = 0;
 __u32 __attribute__((__unused__)) ipcache_srcid = 0;
 int ret;
# 830 "/var/lib/cilium/bpf/bpf_host.c"
 bpf_clear_meta(ctx);

 if (from_host) {
  int trace = TRACE_FROM_HOST;
  _Bool from_proxy;

  from_proxy = inherit_identity_from_host(ctx, &identity);
  if (from_proxy)
   trace = TRACE_FROM_PROXY;
  send_trace_notify(ctx, trace, identity, 0, 0,
      ctx->ingress_ifindex, 0, 128ULL);
 } else {
  bpf_skip_nodeport_clear(ctx);
  send_trace_notify(ctx, TRACE_FROM_NETWORK, 0, 0, 0,
      ctx->ingress_ifindex, 0, 128ULL);
 }

 switch (proto) {

 case (__builtin_constant_p(0x0806) ? ((__be16)((__u16)( (((__u16)((0x0806)) & (__u16)0x00ffU) << 8) | (((__u16)((0x0806)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x0806)):
  ret = 0;
  break;
# 866 "/var/lib/cilium/bpf/bpf_host.c"
 case (__builtin_constant_p(0x0800) ? ((__be16)((__u16)( (((__u16)((0x0800)) & (__u16)0x00ffU) << 8) | (((__u16)((0x0800)) & (__u16)0xff00U) >> 8)))) : __builtin_bswap16(0x0800)):
  identity = resolve_srcid_ipv4(ctx, identity, &ipcache_srcid,
           from_host);
  ctx_store_meta(ctx, 0, identity);
  if (from_host) {







   ep_tail_call(ctx, 22);
  } else {
   ep_tail_call(ctx, 7);
  }






  return send_drop_notify_error(ctx, identity, -140,
           0, 1);

 default:





  ret = 0;

 }

 return ret;
}
# 911 "/var/lib/cilium/bpf/bpf_host.c"
static inline __attribute__((always_inline)) int
handle_netdev(struct __sk_buff *ctx, const _Bool from_host)
{
 __u16 proto;

 if (!validate_ethertype(ctx, &proto)) {






  send_trace_notify(ctx, TRACE_TO_STACK, 1, 0, 0, 0,
      0, 0);

  return 0;

 }

 return do_netdev(ctx, proto, from_host);
}







__attribute__((section("from-netdev"), used))
int from_netdev(struct __sk_buff *ctx)
{
 return handle_netdev(ctx, false);
}





__attribute__((section("from-host"), used))
int from_host(struct __sk_buff *ctx)
{



 edt_set_aggregate(ctx, 0);
 return handle_netdev(ctx, true);
}







__attribute__((section("to-netdev"), used))
int to_netdev(struct __sk_buff *ctx __attribute__((__unused__)))
{
 __u32 __attribute__((__unused__)) src_id = 0;
 __u16 __attribute__((__unused__)) proto = 0;
 int ret = 0;
# 1039 "/var/lib/cilium/bpf/bpf_host.c"
 if ((ctx->mark & 0x1500) != 0x1500) {
  ret = handle_nat_fwd(ctx);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   return send_drop_notify_error(ctx, 0, ret,
            2,
            2);
 }







 send_trace_notify(ctx, TRACE_TO_NETWORK, src_id, 0, 0,
     0, ret, 0);
 return ret;
}





__attribute__((section("to-host"), used))
int to_host(struct __sk_buff *ctx)
{
 __u32 magic = ctx_load_meta(ctx, 0);
 __u16 __attribute__((__unused__)) proto = 0;
 int ret = 0;
 _Bool traced = false;
 __u32 srcID = 0;

 if ((magic & 0x0F00) == 0x0E00) {
  ctx->mark = magic;
  srcID = ctx_load_meta(ctx, CB_IFINDEX);
  set_identity_mark(ctx, srcID);
 } else if ((magic & 0xFFFF) == 0x0200) {

  __be16 port = magic >> 16;

  ctx_store_meta(ctx, 0, CB_SRC_LABEL);
  ret = ctx_redirect_to_proxy_first(ctx, port);
  if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
   goto out;



  traced = true;
 }
# 1098 "/var/lib/cilium/bpf/bpf_host.c"
 if (!traced)
  send_trace_notify(ctx, TRACE_TO_STACK, srcID, 0, 0,
      16, ret, 0);
# 1131 "/var/lib/cilium/bpf/bpf_host.c"
 ret = 0;


out:
 if ((__builtin_expect(!!((ret < 0) || (ret == 2)), 0)))
  return send_drop_notify_error(ctx, srcID, ret, 2,
           1);

 return ret;
}
# 1297 "/var/lib/cilium/bpf/bpf_host.c"
char ____license[] __attribute__((section("license"), used)) = "GPL";
