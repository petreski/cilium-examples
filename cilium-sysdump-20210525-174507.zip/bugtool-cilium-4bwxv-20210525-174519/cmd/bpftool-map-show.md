58: hash  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 8916992B
59: lpm_trie  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 36868096B
61: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 212992B
62: hash  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 7344128B
63: lpm_trie  flags 0x1
	key 12B  value 8B  max_entries 16384  memlock 921600B
64: lru_hash  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 5771264B
65: hash  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 6295552B
66: hash  flags 0x1
	key 2B  value 8B  max_entries 65536  memlock 5246976B
67: hash  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 5246976B
68: perf_event_array  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
69: perf_event_array  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
70: prog_array  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 528384B
	owner_prog_type sched_cls  owner jited
71: lru_hash  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 17829888B
72: lru_hash  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 8916992B
73: lru_hash  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 15732736B
74: lru_hash  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 10489856B
75: lru_hash  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 724992B
76: hash  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 5246976B
77: lru_hash  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6295552B
78: lpm_trie  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 3215360B
81: prog_array  flags 0x0
	key 4B  value 4B  max_entries 25  memlock 4096B
	owner_prog_type sched_cls  owner jited
82: array  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 4096B
84: hash  flags 0x1
	key 8B  value 24B  max_entries 16384  memlock 1576960B
85: hash  flags 0x1
	key 8B  value 24B  max_entries 16384  memlock 1576960B
86: percpu_array  flags 0x0
	key 4B  value 8B  max_entries 1  memlock 4096B
87: prog_array  flags 0x0
	key 4B  value 4B  max_entries 25  memlock 4096B
	owner_prog_type sched_cls  owner jited
88: percpu_array  flags 0x0
	key 4B  value 6B  max_entries 1  memlock 4096B
89: prog_array  flags 0x0
	key 4B  value 4B  max_entries 25  memlock 4096B
	owner_prog_type sched_cls  owner jited
90: prog_array  flags 0x0
	key 4B  value 4B  max_entries 25  memlock 4096B
	owner_prog_type sched_cls  owner jited
91: prog_array  flags 0x0
	key 4B  value 4B  max_entries 25  memlock 4096B
	owner_prog_type sched_cls  owner jited
